# Ben Jehojada — Produktions-Runbook

Ablauf für die zweisprachige Reihe (Hebräisch → Englisch), von der Rohdatei bis
zur satzfertigen Datenbasis. Gilt unverändert für jeden Traktat: Berachot ist
der Referenzlauf, alle weiteren folgen demselben Weg.

**Stand:** September 2026 · Referenzlauf Berachot vollständig durchgelaufen:
680 Einträge, 100 Blätter (2a–64a), Talmud-Mapping 98,7 %, Glossar 82,6 % (bewusst konservativ),
833 Seiten → 2 Bände. Talmudquelle: **Dicta (CC BY-SA)**, Kopfband auf
42 Wörter gekürzt. Das **englische Kopfband bleibt leer** und wird mitübersetzt
(`--band-en empty`) — die Ausgabe enthält damit keine fremde englische
Talmudübersetzung.

---

> **v3.2 05.10.2026 (freigegeben):** Korrekturen für Traktate mit anderer
> Senlake-Auszeichnung als Berakhot (lose Klammern, mehrteilige Lemmata,
> `<small>` im Lemma, Ehrentitel-Zitate, kaputte und maskierte Tags),
> `--glossary`, `--quellkorrektur`, neue Gegenprüfung `by_gegenpruefung.py` als
> Schritt 7 und das Vorgehen für bereits übersetzte Bände. Freigabe nach
> Korpustest über alle 32 Senlake-Traktate mit Dicta-Datei: A–F überall ohne
> Befund. Details: `PATCH_2026-10-05.md`, Abschnitte „Quellkorrekturen“ und
> „Bereits übersetzte Bände“ unten.

> **Reparatur 24.09.2026:** Die Glossarquote ist bewusst niedriger als in älteren
> Läufen. Mehrdeutige Kürzel und Zahlenwerte werden nicht mehr blind geraten.
> Quelleneigene `<small>[...]</small>`-Erklärungen haben Vorrang; Gematria wird
> nur bei unmittelbarem Zahlenkontext gesetzt. Dadurch sinkt die automatische
> Quote, zugleich verschwinden sachlich falsche Fußnoten. Details siehe
> `PATCH_2026-09-24.md`.

## In einem Befehl

```bash
python3 run_pipeline.py \
    --in source/Ben_Yehoyada_on_Shabbat.txt \
    --tractate Shabbat \
    --talmud-he source/talmud/Shabbat_Dicta_haser.txt \
    --band-words 42 \
    --band-en empty \
    --sample-daf 12a \
    --glossary <Projekt-Repository>/glossary_he.json
```

Liegt für den Traktat eine Datei `quellkorrekturen/<Traktat>.json` vor, wird sie
mit `--quellkorrektur quellkorrekturen/<Traktat>.json` angegeben (siehe unten).

Das führt Schritt 1–7 aus und legt alles unter `out/` ab. `--glossary` zeigt auf
die jeweils neueste Abkürzungstabelle im Projekt-Repository; Pfad, Eintragszahl
und Stand stehen im Bericht. Schritt 7 ist die Gegenprüfung jedes erzeugten Bandes
gegen Senlake und Dicta (nur mit `--talmud-he`). Ohne Talmudtext
(`--talmud-he` / `--sefaria-dir` / `--api`) wird Schritt 2 übersprungen; der Rest
läuft trotzdem durch.

Die Übersetzung ist **nicht** Teil der Pipeline — sie setzt hinter Schritt 6 an.

---

## Dateien

```
ben-yehoyada-pipeline/
├── RUNBOOK.md            ← dieses Dokument
├── run_pipeline.py       ← Orchestrator, führt alle Schritte aus
├── by_parse.py           ← Schritt 1: Textdatei → strukturierte Einträge
├── by_sefaria.py         ← Schritt 2: Talmud-Grundstelle zuordnen
├── by_band.py            ← Zuordnung und Ausschnitt des Kopfbands
├── band_overrides.json   ← Handentscheidungen des Lektorats (überleben jeden Lauf)
├── by_validate.py        ← Abnahmeprüfung einer fertigen Banddatei
├── by_glossary.py        ← Schritt 3: Abkürzungen auflösen
├── by_render.py          ← Schritt 5: Buchseiten als HTML
├── by_indesign.py        ← Schritt 6: Banddateien für InDesign
├── glossary_he.json      ← kuratierte Abkürzungstabelle (wächst mit)
├── source/               ← Rohdateien je Traktat
└── out/                  ← Ergebnisse
```

Nur `glossary_he.json` wird von Traktat zu Traktat gepflegt. Der Code bleibt
unverändert.

---

## Voraussetzung: Format der Quelldatei

Die Senlake-Ausgaben folgen einem verlässlichen Muster. Der Parser braucht es so:

```
Daf 4b                                      ← Blattmarke, eigene Zeile
<b>LEMMA</b> Kommentartext …                ← ein Absatz = ein Eintrag
… text <br><b>ודע</b> weiterer Abschnitt    ← Unterabschnitt im selben Eintrag
ABK <small>[Auflösung]</small>              ← Erklärung der Ausgabe
```

**Vor dem Lauf prüfen:** Gibt es `Daf `-Marken? Beginnen die Kommentarabsätze mit
`<b>`? Wenn ein Traktat anders ausgezeichnet ist, muss `by_parse.py` angepasst
werden — alles Weitere bleibt gleich.

---

## Schritt 1 — Parsen

**Macht:** zerlegt die Datei in Einträge. Ein Eintrag = ein Lemma (Dibbur
ha-Matchil) plus sein Kommentar. Erkennt außerdem Abkürzungen (Token mit
Gershajim) und Schriftverweise (Klammerausdrücke, deren erstes Wort ein
Tanach-Buchname ist).

**Ergebnis:** `out/<traktat>.parsed.json`

**Felder je Eintrag:**

| Feld | Inhalt |
|---|---|
| `id` | z. B. `berakhot.4b.2` |
| `daf`, `seq` | Blatt und laufende Nummer darauf |
| `lemma_he` | vokalisiertes Talmud-Zitat aus `<b>…</b>` |
| `commentary_html` | Kommentar mit Originalauszeichnung |
| `commentary_plain` | reiner Lesetext |
| `abbreviations` | erkannte Kürzel (Auflösung folgt in Schritt 3) |
| `scripture_refs` | erkannte Schriftverweise |
| `sefaria_ref` | leer — füllt Schritt 2 |
| `commentary_en` | leer — füllt die Übersetzung |

**Kontrolle:** `entries_freeform` sollte sehr klein sein. Bei Berachot ist es
genau 1 (die einleitende Passage über den Namen des Traktats). Ein hoher Wert
heißt: die Datei ist anders ausgezeichnet als erwartet.

---

## Schritt 2 — Sefaria-Mapping

**Macht:** gleicht jedes Lemma gegen die Segmente seines Daf ab und trägt
`sefaria_ref`, `talmud.he` und `talmud.en` ein. Damit entsteht das Kopfband —
die aramäische Grundstelle plus englische Übersetzung — ohne die ein englischer
Leser den Kommentar nicht einordnen kann.

**Zwei Quellen:**

```bash
# A) Sefaria-Textexporte, empfohlen — genau die Dateien vom Traktat
python3 by_sefaria.py --tractate Berakhot \
    --he-file source/talmud/Berakhot_HE.txt \
    --en-file source/talmud/Berakhot_EN.txt

# B) ganzer Sefaria-Export-Baum (sucht merged.json selbst)
python3 by_sefaria.py --sefaria-dir ~/sefaria-export --tractate Berakhot

# C) über die API
python3 by_sefaria.py --api --tractate Berakhot
```

Das Format wird selbst erkannt. Unterstützt sind:

- **Sefaria-Textexporte** (`Daf 4b` als Zeile) und `merged.json`
- **Dicta „Talmud Bavli with Nikud"** (` *** דף ד: *** `, Punkt = Amud א,
  Doppelpunkt = Amud ב)

### Welche Talmudquelle?

| Quelle | Lizenz | Kommerziell | Treffer | Ø Kopfband |
|---|---|---|---|---|
| Sefaria / Koren-Davidson | CC BY-**NC** | nein | 97,9 % | 329 Z. |
| Dicta, haser, 42 Wörter | CC BY-**SA** | ja, mit Share-alike | 98,1 % | 296 Z. |
| Dicta, maleh, 42 Wörter | CC BY-**SA** | ja, mit Share-alike | 98,2 % | 298 Z. |

**Dicta `haser` ist die Empfehlung.** Die defektive Schreibweise deckt sich mit
der Zitierweise des Ben Jehojada, deshalb landen 325 statt 284 Treffer auf der
verlässlichsten Stufe `contains` statt über die Skelett- oder Fuzzy-Stufe.

### Kopfband kürzen — `--band-words`

Die Quellen gliedern unterschiedlich fein: Sefaria schneidet im Schnitt alle
329 Zeichen, Dicta erst alle 816. Ungekürzt würde das Kopfband die Seite
beherrschen und den Umfang um rund ein Drittel aufblähen (1.008 statt 727
Seiten). `--band-words 42` schneidet ein Fenster um das Lemma heraus: sechs
Wörter Vorlauf, Auslassungen mit `…` markiert.

**42 ist eine Zielgröße, keine Schranke.** Das Fenster endet nie vor dem Ende
der zitierten Passage. Reicht das Lemma weiter, wächst das Band mit — sonst
bricht das Kopfband mitten im Zitat ab. Bei Berachot 20a:4 endete es vor der
Frage nach dem bösen Blick, auf die sich der Kommentar bezieht. Steht die
Passage am Segmentende, füllt das Fenster nach vorn auf, damit der Leser
Anlauf hat. In Band 01 überschreiten 7 von 338 Bändern die 42 Wörter. Damit ist
Dicta in jeder Hinsicht besser als die Koren-Quelle — mehr Treffer, kürzeres
Band, weniger Seiten.

### Englisches Kopfband — `--band-en`

Dicta liefert **kein Englisch**, und eine freie englische Bavli-Übersetzung, die
Berachot abdeckt und kommerziell verwendbar ist, existiert nicht: Rodkinson
(gemeinfrei) lässt Berachot aus und ist stark gekürzt, der urheberrechtliche
Status von Soncino ist wegen URAA ungeklärt, Davidson/Sefaria steht unter
CC BY-NC.

Deshalb wird das englische Kopfband **selbst übersetzt**. `--band-en empty`
schreibt `<band_en></band_en>` in die Banddatei; der Buchmanager exportiert das
leere Feld im Übersetzungsbatch mit, und die Übersetzungsanweisung ab
Fassung 1.1 weist die Übersetzerin an, es zu füllen. Mehraufwand für Berachot:
rund 25.000 aramäische Wörter, etwa 29 % über den Kommentar hinaus.

`--band-en source` (Vorgabe) übernimmt das Englische aus der Talmudquelle —
nur sinnvoll, wenn eine kommerziell nutzbare Quelle vorliegt oder die Ausgabe
nicht verkauft wird.

**Matching: eine Messung, kein Stufenverfahren** (seit 23.09.2026, siehe
`KORREKTUR_2026-09-23.md`).

Das **vollständige** Lemma wird auf die Wortfolge jedes Segments ausgerichtet
(`by_band.align_detail`). Die Ausrichtung liefert drei Größen: Deckung (wie
viel des Lemmas wiederkehrt), Zusammenhang (bilden die Treffer einen Block?)
und Dichte (über wie viele Segmentwörter verteilen sie sich?). Das Segment mit
der besten Bewertung gewinnt — **alle** Kandidaten werden gemessen, keine
Stufe bricht früh ab.

Die alte Stufenlogik nahm in jeder Stufe den *ersten* passenden Treffer. Zwei
Gebete auf Berachot 16b beginnen beide mit „יהי רצון מלפניך ה'"; das erste
gewann, obwohl das Lemma das zweite meint. Dasselbe bei jedem formelhaften
Satzanfang.

Die Methodennamen im Bericht beschreiben jetzt nur noch die *Sicherheit* des
Treffers: `contains` (wörtlich enthalten), `skeleton` (enthalten ohne
Lesemütter), `aligned` (sicher ausgerichtet, Deckung ≥ 0,60), `review`
(zugeordnet, aber wortlautabweichend — ansehen), `override`
(Handentscheidung aus `band_overrides.json`).

**Nicht zugeordnet wird**, wenn keine einzige zusammenhängende Wortfolge
übereinstimmt. Dort bleibt das Lemma selbst im Kopfband — ehrlicher als eine
geratene Talmudstelle. Bei Berachot betrifft das 9 von 680 Einträgen: freie
Paraphrasen des Ben Jehojada und Zitate aus anderen Traktaten.

Vor dem Vergleich fallen Nikud, Tags **und eingeklammerte Schriftverweise** weg:
`שֶׁנֶּאֱמַר (תהילים ד׳:ה׳) רִגְזוּ` würde sonst mitten im Zitat aufgetrennt.
Findet sich auf dem angegebenen Blatt nichts, werden die **Nachbarblätter**
mitdurchsucht — die Blattgrenzen des Ben Jehojada decken sich nicht immer mit
denen von Sefaria. Solche Treffer sind mit `+nachbar` markiert.

**Referenzlauf Berachot mit Dicta haser: 667 von 680 zugeordnet = 98,1 %**
(contains 325 · fuzzy 135 · skeleton 102 · headwords und Nachbarblatt der Rest).

**Die Lektion, die Stufe 2 nötig macht:** Der Ben Jehojada zitiert oft defektiv,
der Talmudtext schreibt plene — `גְּאֻלָּה` gegen `גאולה`. Ein sonst wortwörtlicher
Treffer scheitert an einem einzigen Buchstaben. Das Entfernen der Lesemütter
fängt genau diese Fälle ab. Ohne diese Stufe fällt die Trefferquote spürbar.

**Ohne Netz und ohne Daten prüfbar:**

```bash
python3 by_sefaria.py --selftest
```

**Kontrolle:** Trefferquote, Methodenverteilung und — seit der Korrektur —
die Zeile **„Kopfband ohne die Stelle"**. Sie beantwortet die Frage, die der
Bericht früher nicht gestellt hat: Trägt das ausgegebene Band die zitierte
Passage überhaupt? Steht dort etwas anderes als 0, ist ein Eintrag falsch
zugeordnet. Die Zeile darunter, „Wortlaut weicht ab", ist kein Fehler — der
Ben Jehojada zitiert frei; diese Stellen gehören ins Lektorat.

**Kopfbänder nicht ohne Not neu schneiden:** Läuft die Übersetzung bereits,
den Lauf mit `--keep-bands <verzeichnis>` starten. Schritt 6 übernimmt dann
vorhandene Kopfbänder und ersetzt nur, wo das neue die Stelle nachweislich
besser trägt. Ohne diese Option schneidet ein Neulauf jedes Band neu, und
jedes geänderte `band_he` macht sein bereits übersetztes `band_en`
prüfbedürftig. Ein *niedriger*
Fuzzy-Score ist dabei **kein** Fehlerzeichen: Das Lemma ist oft ein kurzes Zitat
in einem langen Segment, deshalb fällt die Ähnlichkeit rechnerisch, obwohl die
Stelle stimmt. Bei Berachot waren auch die drei schwächsten Fuzzy-Treffer
(Score 0,55) bei Handprüfung korrekt. Einträge ohne Treffer behalten
`sefaria_ref: null`; Renderer und Export fallen dort sauber auf das Lemma zurück.

Die verbleibenden 14 Fehltreffer sind sehr kurze Lemmata („אֵי חָסִיד, אֵי עָנָו")
und aramäische Paraphrasen — Lektoratsarbeit, keine Automatik.

---

## Schritt 3 — Abkürzungen auflösen

**Macht:** trägt zu jedem erkannten Kürzel die hebräische *und* englische
Auflösung ein — die Grundlage des Fußnotenapparats.

**Vier Mechanismen, in dieser Reihenfolge:**

1. **Kuratierte Tabelle** aus `glossary_he.json` — hat immer Vorrang
2. **Präfix-Abtrennung** — `שהקב״ה` → `ש` + `הקב״ה`. Wird nur akzeptiert, wenn
   der Rest ein bekannter Eintrag ist; deshalb ungefährlich
3. **Buchstabennamen** — `אל״ף` → der Buchstabe Alef
4. **Zahlwerte** — `תרי״ג` → 613, nur bei absteigender Buchstabenfolge.
   Die Absteigeregel unterscheidet Zahlen zuverlässig von Akronymen:
   `ב״ה` (aufsteigend) wird korrekt *nicht* als 7 gelesen

**Referenzlauf Berachot:** 2.783 von 3.150 Treffern aufgelöst = **88,3 %**
(kuratiert 1.962 · Präfix 349 · Buchstaben 143 · Zahlwerte 329).

**Erweitern:** Der Bericht listet die häufigsten offenen Kürzel. Diese in
`glossary_he.json` unter `abbreviations` ergänzen — Format:

```json
"פרד\"ס": { "he": "פְּשָׁט רֶמֶז דְּרַשׁ סוֹד", "en": "the four levels of interpretation" }
```

Dann nur Schritt 3 wiederholen. Mehrdeutige Kürzel bekommen zusätzlich ein
`alt`-Feld; die Lektorin entscheidet im Kontext.

**Realistische Erwartung:** Die letzten Prozent sind ein echter Long Tail —
bei Berachot 328 verschiedene Kürzel mit meist ein bis zwei Treffern. Diese
gehören in die Lektoratsschleife, nicht in die Automatik. Die Tabelle wächst
über die Traktate hinweg und wird mit jedem Band wertvoller.

---

## Schritt 4 — Bericht

Schreibt den kompletten Lauf nach `out/<traktat>.report.txt`. Dieser Bericht ist
die Abnahme: Eintragszahl, Trefferquoten, offene Kürzel. Vor dem Übersetzen
durchlesen.

---

## Schritt 5 — Musterseiten

**Macht:** rendert einen schnellen Proof im Maß der KDP-Vorgabe — 7 × 10 Zoll
(177,8 × 254 mm), Bundsteg 19,1 mm.

Der Proof bildet seit Fassung 2 die **gestapelte** Anordnung des InDesign-Satzes
ab: HE-Zone 21–126 mm, EN-Zone 129–234 mm, je volle Satzbreite 144,7 mm,
Kopfband oben in jeder Zone, Fußnoten unten in jeder Zone. Proof und Satz zeigen
damit dasselbe.

Paginiert wird auf **Satzebene**, nicht eintragsweise — ein Eintrag darf über die
Seitengrenze laufen, genau wie im InDesign-Textfluss. Jede Fußnote wird dabei mit
rund 18 Zeichen Grundtext-Äquivalent verrechnet (etwa ein Drittel einer
Notenzeile), sonst rutscht die letzte Zeile unter den Notenblock.

```bash
python3 by_render.py --in out/berakhot.glossed.json --daf 4b --out out/berakhot_4b.html
```

Die HTML-Datei enthält `@page`-Regeln und lässt sich direkt als PDF drucken —
gut für einen schnellen Proof, bevor der Satz in InDesign beginnt.

**Zwei Eigenheiten, die bewusst so sind:**

- **Reservierter Übersetzungsraum.** Solange `commentary_en` leer ist, zeigt die
  englische Spalte keinen weißen Fleck, sondern einen Platzhalter in der Höhe,
  die die Übersetzung real brauchen wird (Zeichenzahl × 1,8). So prüft der
  Testlauf nebenbei die Umfangshochrechnung.
- **Lemma nicht doppelt.** Das Lemma erscheint am Spaltenanfang nur, wenn das
  Kopfband die längere Sefaria-Grundstelle trägt. Fehlt das Mapping noch, steht
  das Lemma allein im Band — sonst stünde derselbe Satz zweimal untereinander.

---

## Schritt 6 — Banddateien für InDesign

**Macht:** plant die Bände und schreibt die Dateien, die der InDesign-Buchmanager
(`Ben_Yehoyada_Bilingual_Book_Manager_v2_0_0.jsx`) einliest.

```bash
python3 by_indesign.py --in out/berakhot.glossed.json --tractate Berakhot --outdir out/indesign
```

**Ergebnis je Traktat:**

```
Ben_Yehoyada_<Traktat>_Band_01_BILINGUAL.txt   ← Banddatei für den Buchmanager
Ben_Yehoyada_<Traktat>_Band_02_BILINGUAL.txt
Ben_Yehoyada_<Traktat>_GLOSSAR.tsv             ← Abkürzungen he/en für die Übersetzung
Ben_Yehoyada_<Traktat>_Bandplan.txt
```

**Segmentformat:**

```xml
<segment id="BYH-0000052" n="2" daf="4b" ref="Berakhot 4b:19">
<band_he>aramäische Grundstelle</band_he>
<band_en></band_en>   <!-- leer: Übersetzungsziel, siehe --band-en -->
<he><lemma>Stichwort</lemma> Kommentar mit <fn>Abk = Auflösung</fn></he>
<en></en>
</segment>
```

Die Fußnoten stehen als `<fn>`-Marken direkt hinter der Abkürzung bzw. dem
Schriftvers, auf den sie sich beziehen. Das JSX wandelt sie beim Formatieren in
echte InDesign-Fußnoten um.

**Bandaufteilung:** Der Planer schätzt erst den Gesamtumfang und teilt ihn dann
gleichmäßig auf die nötige Bandzahl auf, damit kein Band dünn bleibt. Ein Daf
wird nie auseinandergerissen. Kalibrierung: HE 1280 Zeichen/Seite, EN 2420,
Expansion 1,95 — dieselben Werte wie im JSX, beide Seiten müssen zusammenpassen.

**Referenzlauf Berachot:** ca. 833 Seiten → 2 Bände à 427 und 411 Seiten,
3.115 Fußnoten insgesamt.

**Achtung — der Umfang hängt am Kopfband:** ohne Sefaria-Mapping trägt das Band
nur das Lemma und der Traktat kommt auf ~674 Seiten; mit echten Sefaria-Segmenten
auf ~851. Die Bandplanung deshalb immer **nach** dem Mapping rechnen, nie davor.

**Kontrolle:** Bandplan lesen. Liegt ein Band über 588 Textseiten, stimmt die
Kalibrierung nicht mehr — nach den ersten 30 gesetzten Seiten nachziehen.

---

## Danach: Übersetzung

Nicht Teil dieser Pipeline. Übersetzt wird Feld `commentary_en` je Eintrag in
`out/<traktat>.glossed.json` (bzw. `.mapped.json`). Weil die Einträge klein und
in sich geschlossen sind, ist das gut portionierbar und parallelisierbar.

Das Kopfband braucht **keine** eigene Übersetzung — `talmud.en` kommt aus
Sefaria.

Nach der Übersetzung Schritt 5 erneut laufen lassen: Die Platzhalter
verschwinden, und der Umfang lässt sich am realen Satz nachmessen.

---

## Qualitätstore je Traktat

| Tor | Kriterium | Wo prüfen |
|---|---|---|
| Parsen | `entries_freeform` einstellig | Bericht |
| Mapping | Trefferquote; **„Kopfband ohne die Stelle" = 0** | Bericht, `talmud.match` |
| Abnahme | `by_validate.py` meldet 0 FEHLER | `python3 by_validate.py --in <banddatei> --against <vorfassung> --expect <n>` |
| Gegenprüfung | `by_gegenpruefung.py`: A–F ohne Befund (Rückgabe 0) | Bericht `[7/7]`, `out/indesign/*_Gegenpruefung.txt` |
| Lemmata | Liste G (mehrteilige Lemmata) gesichtet | `*_Gegenpruefung.txt` |
| Glossar | offene Kürzel gesichtet und die häufigsten ergänzt | Bericht |
| Satz | Musterdaf gerendert und gelesen | `out/*.html` |
| Umfang | Seitenhochrechnung gegen KDP-Limit 828 | Layoutvorgabe |

---

## Rechte und Lizenzen

- **Grundtext** Ben Jehojada: gemeinfrei (Jossef Chajim † 1909, Ausgabe 1897).
- **Aramäischer Talmudtext** in `<band_he>`: Dicta „Talmud Bavli with Nikud",
  **CC BY-SA 4.0**. Kommerziell nutzbar mit Namensnennung im Impressum:
  „Vocalized Talmud text: Dicta — The Israel Center for Text Analysis,
  CC BY-SA 4.0." Ob die Share-alike-Pflicht durch gekürzte Zitate überhaupt
  ausgelöst wird, ist vor dem ersten Verkauf anwaltlich zu klären.
- **Englischer Text** in `<band_en>` und `<en>`: eigene Übersetzung, eigenes
  Material der Ausgabe. Seit `--band-en empty` wird **keine** fremde englische
  Talmudübersetzung übernommen. Sefaria / William-Davidson (**CC BY-NC**) ist
  für den Verkauf nicht verwendbar.
- **Schriften:** Frank Ruhl Libre steht unter SIL OFL und darf eingebettet
  werden. KDP lehnt PDFs mit nicht eingebetteten Schriften ab.

---

## Bekannte Grenzen

- Der Parser setzt „ein Absatz = ein Eintrag" voraus. Traktate mit abweichender
  Auszeichnung brauchen eine Anpassung in `by_parse.py`.
- Die Schriftvers-Erkennung prüft nur gegen eine Liste von Tanach-Buchnamen.
  Verweise ohne Buchnamen (bloße Kapitel-Vers-Angaben) entgehen ihr.
- Mehrdeutige Kürzel (`ע״ב` = Seite b *oder* der Name mit Zahlwert 72) löst die
  Automatik mit der häufigeren Lesart auf. Das `alt`-Feld macht die Alternative
  sichtbar, entscheiden muss das Lektorat.
- Die Zeichenexpansion 1,95 für die Umfangsschätzung stammt aus einer
  Stichprobe. Nach den ersten 30 gesetzten Seiten am realen Satz nachjustieren.
  Sie gilt für den Kommentar; das selbst übersetzte Kopfband ist darin bereits
  enthalten, weil `he_chars` das hebräische Band mitzählt.

---

## Neuer Traktat — Kurzfassung

1. Rohdatei nach `source/` legen
2. Dicta-haser-Datei des Traktats nach `source/talmud/` legen
3. `python3 run_pipeline.py --in source/<datei>.txt --tractate <Name> --talmud-he source/talmud/<Name>_Dicta_haser.txt --band-words 42 --band-en empty --sample-daf <daf> --glossary <Repo>/glossary_he.json` — dazu `--quellkorrektur quellkorrekturen/<Name>.json`, falls vorhanden
4. Bericht lesen, häufigste offene Kürzel in der `glossary_he.json` des Repositorys ergänzen
5. Pipeline erneut laufen lassen, sie ist schnell
6. Musterdaf ansehen; Stichprobe: jedes Segment hat `<band_en></band_en>`
7. Umfang gegen die KDP-Vorgabe prüfen, Bandaufteilung festlegen
8. `python3 by_validate.py --in out/indesign/Ben_Yehoyada_<Name>_Band_01_BILINGUAL.txt --expect <n>` — 0 FEHLER ist Bedingung
8a. Gegenprüfung je Band (Schritt 7 im Bericht) — A–F ohne Befund ist Bedingung; Liste G ansehen.
    Ein Befund aus einem Auszeichnungsfehler der Quelle wird über eine Quellkorrektur
    behoben (unten), nie durch Bearbeiten der Banddatei.
9. Übersetzung beauftragen — gefüllt werden `<en>` **und** `<band_en>`

**Läuft schon eine Übersetzung?** Dann jeden weiteren Lauf mit
`--keep-bands <verzeichnis der geprüften Banddateien>` starten. Sonst werden
geprüfte Kopfbänder neu geschnitten und die zugehörigen `band_en` wieder
prüfbedürftig.

---

## Bereits übersetzte Bände (v3.2)

Einen übersetzten Band **nie** neu erzeugen: Ein Neulauf ändert `<he>` (Lemma,
Fußnoten), und `--keep-bands` schützt nur das Kopfband. Stattdessen:

1. `python3 by_gegenpruefung.py <Band>_EN_FERTIG.txt <Senlake> <Dicta> --uebersetzt`
2. Ohne Befund in A–F: nichts zu tun.
3. Mit Befunden: Sollzustand mit v3.2 und dem Glossarstand der ursprünglichen
   Erzeugung herstellen (`--glossary`), feldweise vergleichen, nur abweichende
   `<he>` ersetzen, fehlende englische Passagen gezielt nachübersetzen,
   Abnahme mit Gegenprüfung und `by_validate.py --against <bisheriger Master>`.

Referenzfall mit Werkzeugen: Pesachim Band 01, 05.10.2026.

---

## Quellkorrekturen (v3.2)

Manche Auszeichnungsfehler der Senlake-Datei kann keine allgemeine Regel lösen,
etwa ein `<b>`, das erst am Absatzende geschlossen wird (Sukkah 39a: der ganze
Kommentar wäre Lemma). Dafür gibt es je Traktat eine Datei
`quellkorrekturen/<Traktat>.json`:

```json
{"traktat": "Sukkah", "korrekturen": [
  {"daf": "39a", "n": 1, "alt": "…קָאָמַרְתְּ. נראה לי", "neu": "…קָאָמַרְתְּ.</b> נראה לי", "grund": "…"},
  {"daf": "54a", "n": 4, "lemma_ende": "…בְּיָדָךְ.</b>", "grund": "…"}]}
```

- `alt`/`neu`: genaue Ersetzung im Absatz `daf`/`n` (n = Absatz auf dem Blatt).
  Die Pipeline bricht ab, wenn `alt` nicht genau einmal vorkommt oder wenn `neu`
  anderen Text enthält als `alt` — erlaubt ist nur das Verschieben von Tags.
- `lemma_ende`: das Dibbur ha-Matchil endet genau hinter dieser Stelle. Für
  Fälle der Liste G, in denen ein fettes Stichwort des Kommentars am Zitat hängt.
- `grund` erscheint im Bericht (Schritt 1). Den Suchtext aus der Senlake-Datei
  kopieren, nicht abtippen: die Reihenfolge der Vokalzeichen muss stimmen.

Mitgeliefert (Korpustest 05.10.2026): Arakhin, Eruvin, Pesachim, Sanhedrin, Sotah,
Sukkah. Maskierte Tag-Reste der Quelle (`&lt;b&gt;`, Bava Batra, Bava Kamma,
Bava Metzia, Chullin, Arakhin) entfernt die Pipeline selbst.
