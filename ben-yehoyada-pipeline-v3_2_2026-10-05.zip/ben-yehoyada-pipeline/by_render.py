# -*- coding: utf-8 -*-
"""
Schritt 5 — HTML-Proof.

Bildet die GESTAPELTE Anordnung des InDesign-Satzes nach, damit Proof und
gesetzter Band dasselbe zeigen:

    ┌──────────────────────────────┐  177,8 × 254 mm (7 × 10")
    │ Kolumnentitel · Linie        │
    │ ┌──────────────────────────┐ │
    │ │ Talmud-Kopfband (aram.)  │ │  HE-Rahmen, 21,0 – 126,0 mm
    │ │ Hebräischer Kommentar    │ │  volle Satzbreite 144,7 mm
    │ │ hebr. Fussnoten          │ │
    │ └──────────────────────────┘ │
    │        (Trennung 3 mm)       │
    │ ┌──────────────────────────┐ │
    │ │ Talmud-Kopfband (engl.)  │ │  EN-Rahmen, 129,0 – 234,0 mm
    │ │ Englische Übersetzung    │ │
    │ │ engl. Fussnoten          │ │
    │ └──────────────────────────┘ │
    │            Folio             │
    └──────────────────────────────┘

Beide Sprachen bekommen die volle Satzbreite statt einer schmalen Spalte — und
genau das erlaubt dem Buchmanager, die Trennlinie pro Seite zu verschieben, bis
HE und EN beim selben Segment stehen.

Die Seitenfüllung folgt derselben Kalibrierung wie JSX und Export
(HE 1280 Zeichen/Seite, EN 2420, Expansion 1,95). Läuft eine Zone über, wird das
sichtbar markiert — dann stimmt die Kalibrierung nicht mehr und gehört
nachgezogen.

Aufruf:
    python3 by_render.py --in out/berakhot.glossed.json --daf 4b --out out/berakhot_4b.html
"""
import json, os, re, html, argparse

from by_parse import drop_small_brackets

HE_CHARS_PER_PAGE = 1280
EN_CHARS_PER_PAGE = 2420
EN_EXPANSION = 1.95


def esc(s):
    return html.escape(s or '', quote=False)


def clean_inline(s):
    """Nur <b> behalten, <br> zu Absatz, <small>[...]</small> entfernen."""
    s = drop_small_brackets(s)   # Korrektur 2026-10-05, siehe by_parse
    # [^<>]: ein kaputtes '<' (Pesachim: '<b>מַר<, וזה סוד <small>') darf nicht
    # bis zum naechsten Tag laufen und den Text dazwischen mitloeschen.
    s = re.sub(r'<(?!/?b\b|br\b)[^<>]*>', '', s)
    s = re.sub(r'<br\s*/?>', '</p><p class="he-body">', s)
    return s


def plain_len(s):
    return len(re.sub(r'<[^>]+>', '', s or ''))


def entry_notes(e):
    """[(abbr|None, he, en)] — Abkürzungen zuerst, dann Schriftverse."""
    out, seen = [], set()
    for a in e.get('abbreviations', []):
        if not a.get('expansion') or a['abbr'] in seen:
            continue
        seen.add(a['abbr'])
        out.append((a['abbr'], a['expansion'], a.get('expansion_en')))
    for ref in e.get('scripture_refs', []):
        out.append((None, ref, 'scriptural citation'))
    return out


SENT = re.compile(r'(?<=[.:!?׃])\s+')


def split_sentences(html_text):
    """
    Zerlegt einen Kommentar in Sätze, ohne <b>-Auszeichnungen zu zerreißen.
    Getrennt wird nur an Satzzeichen, die außerhalb eines Tags stehen.
    """
    parts, depth, buf = [], 0, []
    i = 0
    while i < len(html_text):
        c = html_text[i]
        buf.append(c)
        if c == '<':
            depth = 1
        elif c == '>':
            depth = 0
        elif depth == 0 and c in '.:!?׃':
            j = i + 1
            while j < len(html_text) and html_text[j] == ' ':
                j += 1
            if j > i + 1 or j >= len(html_text):
                parts.append(''.join(buf))
                buf = []
                i = j - 1
        i += 1
    if buf:
        parts.append(''.join(buf))
    return [p for p in parts if p.strip()]


def paginate_units(entries):
    """
    Baut eine fortlaufende Folge kleiner Einheiten (Kopfband, Satz) und füllt
    damit Seiten bis zur HE-Kalibrierung. Ein Eintrag darf dabei über die
    Seitengrenze laufen — genau wie im InDesign-Textfluss.
    """
    units = []
    for e in entries:
        t = e.get('talmud') or {}
        band_he = t.get('he') or e.get('lemma_he') or ''
        if band_he:
            units.append({'kind': 'band', 'entry': e, 'text': band_he,
                          'len': plain_len(band_he)})
        body = clean_inline(e.get('commentary_html'))
        first = True
        for s in split_sentences(body):
            units.append({'kind': 'sent', 'entry': e, 'text': s,
                          'len': plain_len(s), 'first': first})
            first = False

    # Jede Fussnote kostet Platz in der Zone, den das reine Zeichenbudget nicht
    # kennt. Ohne diesen Abzug laeuft die letzte Zeile unter den Notenblock.
    FN_COST = 18   # ~1/3 Notenzeile (9,5 pt) = ~0,2 Grundtextzeile (16 pt)
    pages, cur, acc, seen = [], [], 0, set()
    for u in units:
        cost = u['len']
        new_notes = 0
        if u['kind'] == 'sent':
            for abbr, he_txt, en_txt in entry_notes(u['entry']):
                key = (u['entry']['id'], he_txt)
                needle = abbr or he_txt
                if key not in seen and needle and needle in u['text']:
                    new_notes += 1
        cost += new_notes * FN_COST
        if cur and acc + cost > HE_CHARS_PER_PAGE:
            pages.append(cur)
            cur, acc, seen = [], 0, set()
            cost = u['len'] + new_notes * FN_COST
        if u['kind'] == 'sent':
            for abbr, he_txt, en_txt in entry_notes(u['entry']):
                needle = abbr or he_txt
                if needle and needle in u['text']:
                    seen.add((u['entry']['id'], he_txt))
        cur.append(u)
        acc += cost
    if cur:
        pages.append(cur)
    return pages


def render_page(units, folio, title, daf_label):
    he_parts, en_parts, notes = [], [], []
    seen_notes = set()
    body_open = False
    he_chars = 0
    entries_on_page = []

    for u in units:
        e = u['entry']
        if e not in entries_on_page:
            entries_on_page.append(e)
        he_chars += u['len']
        if u['kind'] == 'band':
            if body_open:
                he_parts.append('</p>')
                body_open = False
            he_parts.append('<p class="band-he">{}</p>'.format(esc(u['text'])))
            continue
        txt = u['text']
        # Fussnotenziffern nur beim ersten Vorkommen auf dieser Seite
        for abbr, he_txt, en_txt in entry_notes(e):
            key = (e['id'], he_txt)
            if key in seen_notes:
                continue
            needle = abbr or he_txt
            if needle and needle in txt:
                seen_notes.add(key)
                notes.append((abbr, he_txt, en_txt))
                txt = txt.replace(needle, needle + '<sup class="fn">{}</sup>'.format(len(notes)), 1)
        if not body_open:
            lemma = ''
            if u.get('first') and e.get('lemma_he') and (e.get('talmud') or {}).get('he'):
                lemma = '<span class="lemma">{}</span> '.format(esc(e['lemma_he']))
            he_parts.append('<p class="he-body">' + lemma)
            body_open = True
        he_parts.append(txt + ' ')
    if body_open:
        he_parts.append('</p>')

    # Englische Zone: Kopfband je Eintrag, der auf dieser Seite beginnt,
    # plus reservierter Platz im Verhältnis zum hebräischen Text der Seite
    for e in entries_on_page:
        band_en = (e.get('talmud') or {}).get('en') or ''
        if band_en:
            en_parts.append('<p class="band-en">{}</p>'.format(esc(band_en)))
        if e.get('commentary_en'):
            en_parts.append('<p class="en-body">{}</p>'.format(esc(e['commentary_en'])))
    if not any('en-body' in p for p in en_parts):
        lines = max(2, int(he_chars * EN_EXPANSION / 78))
        h = min(70.0, lines * 12.8 * 0.3528)
        en_parts.append('<div class="pending" style="height:{:.1f}mm">'
                        '<span>Übersetzung ausstehend · ca. {} Zeilen für diese Seite</span>'
                        '</div>'.format(h, lines))

    def note_block(idx):
        if not notes:
            return ''
        items = []
        for i, (abbr, he_txt, en_txt) in enumerate(notes, start=1):
            txt = ('<span class="nhe">{}</span> = {}'.format(esc(abbr), esc(he_txt))
                   if idx == 'he' else esc(en_txt or he_txt))
            items.append('<span class="note"><sup>{}</sup> {}</span>'.format(i, txt))
        return '<div class="notes {}">{}</div>'.format(idx, ' '.join(items))

    return ('<div class="sheet">'
            '<div class="runhead"><span>{t}</span><span>{d}</span></div>'
            '<div class="zone he-zone"><div class="flow">{he}</div>{hn}</div>'
            '<div class="divider"></div>'
            '<div class="zone en-zone"><div class="flow">{en}</div>{en_n}</div>'
            '<div class="folio">— {f} —</div>'
            '</div>').format(t=esc(title), d=esc(daf_label), f=folio,
                             he=''.join(he_parts), en=''.join(en_parts),
                             hn=note_block('he'), en_n=note_block('en'))


CSS = """
@page { size: 177.8mm 254mm; margin: 0; }
* { box-sizing: border-box; }
body { margin:0; background:#e8e6e0; font-family:"Spectral",Georgia,serif; color:#111; }
.legend { width:177.8mm; margin:8mm auto 4mm; font-family:"IBM Plex Mono",monospace;
          font-size:8pt; color:#555; line-height:1.5; }
.sheet { position:relative; width:177.8mm; height:254mm; margin:0 auto 8mm; background:#fff;
         box-shadow:0 2px 14px rgba(0,0,0,.18); overflow:hidden; }
.runhead { position:absolute; left:14mm; right:19.1mm; top:11mm; display:flex;
           justify-content:space-between; font-family:"IBM Plex Mono",monospace;
           font-size:7.5pt; letter-spacing:.09em; text-transform:uppercase; color:#666; }
.sheet::before { content:""; position:absolute; left:14mm; right:19.1mm; top:20mm;
                 border-top:.5pt solid #333; }
/* Zonen exakt wie im JSX: HE 21–126 mm, EN 129–234 mm, Satzbreite 144,7 mm */
.zone { position:absolute; left:14mm; width:144.7mm; overflow:hidden;
        display:flex; flex-direction:column; }
.he-zone { top:21mm; height:105mm; direction:rtl; }
.en-zone { top:129mm; height:105mm; direction:ltr; }
.divider { position:absolute; left:14mm; width:144.7mm; top:126mm; height:3mm; }
.flow { flex:1 1 auto; overflow:hidden; }
.band-he { font-family:"Frank Ruhl Libre",serif; font-weight:700; font-size:12pt;
           line-height:17pt; direction:rtl; text-align:right; margin:0 0 1.2mm;
           background:#f0efec; border-top:.8pt solid #222; border-bottom:.4pt solid #222;
           padding:1.4mm 2mm; }
.he-body { font-family:"Frank Ruhl Libre",serif; font-size:11pt; line-height:16pt;
           direction:rtl; text-align:justify; margin:0 0 2mm; }
.lemma { font-weight:700; }
.band-en { font-size:9pt; line-height:12pt; font-style:italic; color:#333; margin:0 0 1.2mm;
           border-top:.8pt solid #222; border-bottom:.4pt solid #222; padding:1.4mm 2mm;
           background:#f6f5f2; }
.en-body { font-size:9.5pt; line-height:12.8pt; text-align:justify; margin:0 0 2mm; hyphens:auto; }
.pending { border:.4pt dashed #9a9a9a; background:repeating-linear-gradient(45deg,
           #fafafa,#fafafa 4px,#f2f2f2 4px,#f2f2f2 8px); display:flex; align-items:center;
           justify-content:center; text-align:center; margin-bottom:2mm; }
.pending span { font-family:"IBM Plex Mono",monospace; font-size:6.5pt; color:#8a8a8a; }
.notes { flex:0 0 auto; border-top:.4pt solid #222; margin-top:1.5mm; padding-top:1.2mm;
         font-size:7.5pt; line-height:9.5pt; color:#333; }
.notes.he { direction:rtl; text-align:right; font-family:"Frank Ruhl Libre",serif; }
.note { margin-inline-end:3mm; white-space:nowrap; }
.note sup { font-family:"IBM Plex Mono",monospace; font-size:6pt; }
.nhe { font-family:"Frank Ruhl Libre",serif; font-weight:500; }
sup.fn { font-family:"IBM Plex Mono",monospace; font-size:6pt; vertical-align:super; color:#555; }
.folio { position:absolute; left:0; right:0; bottom:9mm; text-align:center;
         font-family:"IBM Plex Mono",monospace; font-size:9pt; color:#444; }
@media print { body{background:#fff;} .sheet{margin:0; box-shadow:none; page-break-after:always;}
               .legend{display:none;} }
"""


def render(doc, dafim, title='Ben Yehoyada · Berakhot', start_folio=1):
    entries = [e for e in doc['entries'] if e['daf'] in dafim]
    pages = paginate_units(entries)
    sheets = []
    for i, pg in enumerate(pages):
        d0, d1 = pg[0]['entry']['daf'], pg[-1]['entry']['daf']
        dl = d0 if d0 == d1 else '{}–{}'.format(d0, d1)
        sheets.append(render_page(pg, start_folio + i, title, 'Daf ' + dl))
    meta = doc.get('meta', {})
    mapped = meta.get('sefaria_mapping', {}).get('percent')
    legend = ('<div class="legend">'
              'GESTAPELTE ANORDNUNG · identisch zum InDesign-Satz<br>'
              '7 × 10″ (177,8 × 254 mm) · HE-Rahmen 21–126 mm · EN-Rahmen 129–234 mm · '
              'Satzbreite 144,7 mm · Bundsteg 19,1 mm<br>'
              '{d} · {n} Einträge auf {p} Seiten · Glossar {g}% · Sefaria-Mapping {m}'
              '</div>').format(d=', '.join(dafim), n=len(entries), p=len(pages),
                               g=meta.get('glossary_coverage', {}).get('percent', '—'),
                               m='{}%'.format(mapped) if mapped else 'ausstehend')
    return ('<!doctype html><html lang="he"><head><meta charset="utf-8">'
            '<title>{}</title>'
            '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?'
            'family=Spectral:wght@400;600&family=Frank+Ruhl+Libre:wght@400;500;700'
            '&family=IBM+Plex+Mono:wght@400;500&display=swap">'
            '<style>{}</style></head><body>{}{}</body></html>').format(
        esc(title), CSS, legend, ''.join(sheets))


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--in', dest='src', default='out/berakhot.glossed.json')
    ap.add_argument('--out', dest='dst', default='out/berakhot_daf.html')
    ap.add_argument('--daf', default='4b', help='kommagetrennt, z.B. 4b,5a')
    ap.add_argument('--title', default='Ben Yehoyada · Berakhot')
    a = ap.parse_args()
    doc = json.load(open(a.src, encoding='utf-8'))
    dafim = [d.strip() for d in a.daf.split(',')]
    out = render(doc, dafim, a.title)
    os.makedirs(os.path.dirname(a.dst) or '.', exist_ok=True)
    open(a.dst, 'w', encoding='utf-8').write(out)
    n = sum(1 for e in doc['entries'] if e['daf'] in dafim)
    print('gerendert: {} Eintraege -> {}'.format(n, a.dst))
