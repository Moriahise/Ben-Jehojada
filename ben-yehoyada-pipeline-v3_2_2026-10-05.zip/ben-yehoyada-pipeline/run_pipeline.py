#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Ben-Jehojada-Pipeline — alle Schritte bis vor die Uebersetzung, in einem Befehl.

    python3 run_pipeline.py --in Ben_Yehoyada_on_Shabbat.txt --tractate Shabbat \
                            --sefaria-dir ~/sefaria-export --sample-daf 12a

Ohne --sefaria-dir/--api wird Schritt 2 uebersprungen; alles andere laeuft
trotzdem durch, und der Renderer zeigt ersatzweise das Lemma im Kopfband.

Schritte:
  1 parsen              -> out/<traktat>.parsed.json
  2 Sefaria-Mapping     -> out/<traktat>.mapped.json     (optional)
  3 Abkuerzungen        -> out/<traktat>.glossed.json
  4 Bericht             -> out/<traktat>.report.txt
  5 Musterseiten        -> out/<traktat>_<daf>.html
  6 Banddateien         -> out/indesign/
  7 Gegenpruefung       -> out/indesign/..._Gegenpruefung.txt  (nur mit --talmud-he)
  -- danach: Uebersetzung (nicht Teil dieser Pipeline) --

--glossary PFAD: Abkuerzungstabelle, z.B. die jeweils neueste glossary_he.json
aus dem Projekt-Repository (Vorgabe: glossary_he.json neben diesem Skript).
"""
import argparse, json, os, sys, subprocess, datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import by_parse, by_glossary, by_sefaria, by_render, by_indesign   # noqa: E402
import by_gegenpruefung                                              # noqa: E402
import contextlib, io                                                # noqa: E402

PIPELINE_VERSION = 'v3.2 (2026-10-05)'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--in', dest='src', required=True, help='Quelltextdatei (.txt)')
    ap.add_argument('--tractate', required=True, help='z.B. Shabbat')
    ap.add_argument('--edition', default='Senlake 2019, based on Jerusalem 1897')
    ap.add_argument('--outdir', default=os.path.join(HERE, 'out'))
    ap.add_argument('--sefaria-dir', help='Wurzel eines Sefaria-Export-Baums')
    ap.add_argument('--talmud-he', help='Sefaria-Talmudtext hebr./aram. (.txt oder .json)')
    ap.add_argument('--talmud-en', help='Sefaria-Talmudtext englisch (.txt oder .json)')
    ap.add_argument('--api', action='store_true', help='Sefaria ueber die API')
    ap.add_argument('--band-words', type=int, default=0,
                    help='Kopfband auf N Woerter um das Lemma kuerzen (0 = ungekuerzt)')
    ap.add_argument('--band-en', choices=['source','empty'], default='source',
                    help="'empty': englisches Kopfband bleibt leer und wird mituebersetzt")
    ap.add_argument('--sample-daf', default=None, help='Daf fuer die Musterseiten')
    ap.add_argument('--glossary', metavar='PFAD',
                    help='glossary_he.json, z.B. die neueste Fassung aus dem Projekt-Repository')
    ap.add_argument('--quellkorrektur', metavar='PFAD',
                    help='JSON mit Auszeichnungskorrekturen der Senlake-Datei '
                         '(nur Tags, kein Text; siehe quellkorrekturen/)')
    ap.add_argument('--keep-bands', metavar='VERZEICHNIS',
                    help='vorhandene Banddateien dort einlesen und ein Kopfband nur '
                         'ersetzen, wenn das neue die zitierte Stelle besser traegt '
                         '(zerstoerungsfreier Neulauf bei laufender Uebersetzung)')
    a = ap.parse_args()

    slug = a.tractate.lower()
    os.makedirs(a.outdir, exist_ok=True)
    P = lambda name: os.path.join(a.outdir, name)                      # noqa: E731
    log = []

    def say(s=''):
        print(s)
        log.append(s)

    say('BEN-JEHOJADA-PIPELINE — {}'.format(datetime.datetime.now().strftime('%Y-%m-%d %H:%M')))
    say('Traktat: {}   Quelle: {}'.format(a.tractate, os.path.basename(a.src)))
    say('Pipeline: {}'.format(PIPELINE_VERSION))
    say('=' * 62)

    # ---- 1 parsen
    say('\n[1/7] Parsen')
    doc = by_parse.parse(a.src, a.tractate, a.edition,
                         by_parse.load_source_fixes(a.quellkorrektur))
    json.dump(doc, open(P(slug + '.parsed.json'), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1)
    c = doc['meta']['counts']
    say('      {} Eintraege auf {} Blaettern ({})'.format(c['entries'], c['dafim'],
                                                          doc['meta']['daf_range']))
    say('      mit Lemma: {}   freiform: {}'.format(c['entries_with_lemma'], c['entries_freeform']))
    qk = doc['meta']['quellkorrekturen']
    if a.quellkorrektur:
        say('      Quellkorrekturen: {} aus {}'.format(len(qk), os.path.basename(a.quellkorrektur)))
        for q in qk:
            say('        {}.{}: {}'.format(q['daf'], q['n'], q['grund']))
    if doc['meta']['maskiertes_markup']:
        say('      maskierte Tag-Reste der Quelle entfernt: {}'.format(doc['meta']['maskiertes_markup']))

    # ---- 2 Sefaria
    say('\n[2/7] Sefaria-Mapping')
    he_arr = en_arr = None
    if a.talmud_he:
        he_arr, en_arr = by_sefaria.load_local(a.talmud_he, a.talmud_en)
        say('      Datei: {}{}'.format(os.path.basename(a.talmud_he),
                                       ' + ' + os.path.basename(a.talmud_en) if a.talmud_en else ''))
    elif a.sefaria_dir:
        hf, ef = by_sefaria.find_merged(a.sefaria_dir, a.tractate)
        if hf:
            he_arr, en_arr = by_sefaria.load_local(hf, ef)
            say('      lokal: {}'.format(os.path.relpath(hf, a.sefaria_dir)))
        else:
            say('      ! kein merged.json fuer {} unter {}'.format(a.tractate, a.sefaria_dir))
    if he_arr is not None or a.api:
        st = by_sefaria.run(doc, he_arr, en_arr, use_api=a.api, tractate=a.tractate,
                            band_words=a.band_words)
        say('      zugeordnet: {}/{} ({}%)  Methoden: {}'.format(
            st['matched'], st['total'], st['percent'], st['by_method']))
        # Die Zahl, auf die es ankommt: bei wie vielen Eintraegen traegt das
        # Kopfband die zitierte Stelle NICHT. Fehlte dieser Wert, blieben
        # Fehlzuordnungen bis zur Uebersetzung unbemerkt.
        say('      Kopfband ohne die Stelle : {}{}'.format(
            st.get('band_missing', 0),
            '  -> ' + ', '.join(st.get('band_missing_ids', [])[:12])
            if st.get('band_missing') else ''))
        say('      Wortlaut weicht ab       : {}  (Lektorat, kein Fehler)'
            .format(st.get('band_wording', 0)))
        json.dump(doc, open(P(slug + '.mapped.json'), 'w', encoding='utf-8'),
                  ensure_ascii=False, indent=1)
    else:
        say('      uebersprungen (keine Quelle) — Kopfband faellt auf das Lemma zurueck')

    # ---- 3 Abkuerzungen
    say('\n[3/7] Abkuerzungen aufloesen')
    g = by_glossary.Glossary(a.glossary)
    gmeta = json.load(open(a.glossary or os.path.join(HERE, 'glossary_he.json'),
                           encoding='utf-8')).get('_meta', {})
    say('      Glossar: {} · {} Eintraege · Stand: {}'.format(
        os.path.abspath(a.glossary or os.path.join(HERE, 'glossary_he.json')),
        len(g.raw), ('…' + (gmeta.get('stand') or '-')[-110:]) if len(gmeta.get('stand') or '') > 110 else (gmeta.get('stand') or '-')))
    cov = g.annotate(doc)
    doc['glossary_curated'] = g.raw
    json.dump(doc, open(P(slug + '.glossed.json'), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1)
    say('      {}/{} Treffer aufgeloest ({}%)'.format(
        cov['hits_resolved'], cov['hits_total'], cov['percent']))
    say('      nach Mechanismus: {}'.format(cov['by_source']))
    say('      offen: {} verschiedene Kuerzel'.format(cov['unresolved_distinct']))
    if cov['unresolved_top']:
        top = list(cov['unresolved_top'].items())[:10]
        say('      haeufigste offene: ' + ', '.join('{} ({}x)'.format(k, v) for k, v in top))
        say('      -> diese in glossary_he.json ergaenzen und Schritt 3 wiederholen')

    # ---- 4 Bericht
    say('\n[4/7] Bericht')
    rep = P(slug + '.report.txt')
    open(rep, 'w', encoding='utf-8').write('\n'.join(log) + '\n')
    say('      {}'.format(os.path.basename(rep)))

    # ---- 5 Musterseiten
    say('\n[5/7] Musterseiten rendern')
    daf = a.sample_daf or doc['entries'][0]['daf']
    html_path = P('{}_{}.html'.format(slug, daf))
    out = by_render.render(doc, [daf], title='Ben Yehoyada · {}'.format(a.tractate))
    open(html_path, 'w', encoding='utf-8').write(out)
    n = sum(1 for e in doc['entries'] if e['daf'] == daf)
    say('      Daf {}: {} Eintraege -> {}'.format(daf, n, os.path.basename(html_path)))

    # ---- 6 InDesign-Banddateien
    say('\n[6/7] Banddateien fuer den InDesign-Buchmanager')
    idir = os.path.join(a.outdir, 'indesign')
    os.makedirs(idir, exist_ok=True)
    segs = by_indesign.build_segments(doc, a.tractate, band_en_mode=a.band_en)
    if a.keep_bands:
        import glob as _glob
        prev = sorted(_glob.glob(os.path.join(
            a.keep_bands, 'Ben_Yehoyada_*_Band_*_BILINGUAL.txt')))
        existing = by_indesign.read_existing_bands(prev)
        if existing:
            r = by_indesign.carry_over_bands(segs, existing)
            say('      vorhandene Kopfbaender aus {} Datei(en): {} uebernommen, {} ersetzt'
                .format(len(prev), r['uebernommen'], r['ersetzt']))
        else:
            say('      ! keine Banddateien unter {} gefunden'.format(a.keep_bands))
    volumes, total, n_vol = by_indesign.plan_volumes(segs)
    tag = a.tractate.replace(' ', '_')
    plan = ['BEN JEHOJADA · {} · BANDPLAN'.format(a.tractate.upper()),
            'Segmente: {}   geschaetzter Gesamtumfang: {:.0f} Seiten'.format(len(segs), total),
            'Kalibrierung: HE {} Z./S. · EN {} Z./S. · Expansion {}'.format(
                by_indesign.HE_CHARS_PER_PAGE, by_indesign.EN_CHARS_PER_PAGE,
                by_indesign.EN_EXPANSION),
            'Grenze je Band: {} Seiten Text (+{} Reserve) = {} gesamt'.format(
                by_indesign.BODY_MAX, by_indesign.RESERVED_PAGES, by_indesign.MAX_PAGES),
            'Englisches Kopfband: {}'.format(
                'leer, wird mituebersetzt' if a.band_en == 'empty' else 'aus der Talmudquelle'),
            '']
    for i, v in enumerate(volumes, start=1):
        pgs = sum(s['pages'] for s in v) + (by_indesign.FRONT_MATTER if i == 1 else 4)
        f = os.path.join(idir, 'Ben_Yehoyada_{}_Band_{:02d}_BILINGUAL.txt'.format(tag, i))
        by_indesign.write_volume(f, i, v, a.tractate)
        plan.append(('Band {:02d}: ca. {:.0f} Seiten · {} Segmente · {} bis {} · '
                     'Daf {} bis {} · {} Fussnoten').format(
            i, pgs, len(v), v[0]['id'], v[-1]['id'], v[0]['daf'], v[-1]['daf'],
            sum(s['footnotes'] for s in v)))
        say('      Band {:02d}: ca. {:.0f} S. · {} Segmente · Daf {}-{} · {} Fussnoten'.format(
            i, pgs, len(v), v[0]['daf'], v[-1]['daf'], sum(s['footnotes'] for s in v)))
    by_indesign.write_glossary(os.path.join(idir, 'Ben_Yehoyada_{}_GLOSSAR.tsv'.format(tag)), doc)
    open(os.path.join(idir, 'Ben_Yehoyada_{}_Bandplan.txt'.format(tag)),
         'w', encoding='utf-8', newline='').write('\r\n'.join(plan))
    if a.band_en == 'empty':
        say('      englisches Kopfband bleibt leer -> wird mituebersetzt')
    say('      Gesamtumfang ca. {:.0f} Seiten -> {} Bände'.format(total, n_vol))

    # ---- 7 Gegenpruefung gegen die beiden Rohdateien
    say('\n[7/7] Gegenpruefung gegen Senlake und Dicta')
    if a.talmud_he:
        for i in range(1, len(volumes) + 1):
            f = os.path.join(idir, 'Ben_Yehoyada_{}_Band_{:02d}_BILINGUAL.txt'.format(tag, i))
            stem = f[:-len('_BILINGUAL.txt')]
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                rc = by_gegenpruefung.main(f, a.src, a.talmud_he, stem + '_Gegenpruefung.json')
            open(stem + '_Gegenpruefung.txt', 'w', encoding='utf-8').write(buf.getvalue())
            gp = json.load(open(stem + '_Gegenpruefung.json', encoding='utf-8'))
            bef = gp['befunde']
            say('      Band {:02d}: {} · hebr. wortgleich {}/{} · {} · mehrteilige Lemmata {} (ansehen)'.format(
                i, 'OK' if rc == 0 else 'BEFUNDE', gp['stats'].get('he_wortgleich'),
                gp['stats'].get('segmente'),
                ' '.join('{}={}'.format(k, len(bef[k])) for k in 'ABCDEF'),
                len(bef.get('G', []))))
        if gp['stats'].get('senlake_kaputte_tags'):
            say('      ! Senlake-Quelle enthaelt {} kaputte Tag(s) — Stelle pruefen{}'.format(
                gp['stats']['senlake_kaputte_tags'],
                '' if a.quellkorrektur else ' (Quellkorrektur? siehe quellkorrekturen/)'))
    else:
        say('      uebersprungen (nur mit --talmud-he)')

    say('\n' + '=' * 62)
    say('FERTIG. Naechster Schritt (nicht Teil der Pipeline): Uebersetzung.')
    say('Im InDesign-Buchmanager die Banddatei waehlen und Batches exportieren;')
    if a.band_en == 'empty':
        say('gefuellt werden die <en>-Felder UND die leeren <band_en>-Felder.')
    else:
        say('gefuellt werden nur die <en>-Felder.')
    open(rep, 'w', encoding='utf-8').write('\n'.join(log) + '\n')


if __name__ == '__main__':
    main()
