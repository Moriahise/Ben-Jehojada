# -*- coding: utf-8 -*-
import os, re, tempfile, unittest

import by_glossary
import by_indesign
import by_validate


class PipelineRegressionTests(unittest.TestCase):
    def setUp(self):
        self.g = by_glossary.Glossary()

    def test_lexical_abbreviations_are_not_gematria(self):
        self.assertIn('נְבִיאִים', self.g.resolve('תנ"ך', context='מפרשי התנ"ך')['he'])
        self.assertIn('מֵאִיר', self.g.resolve('ר"מ', context='אמר ר"מ')['he'])
        self.assertIn('פָּפָא', self.g.resolve('ר"פ', context='ר"פ אמר')['he'])

    def test_inline_numeric_beats_lexical_default(self):
        r = self.g.resolve('ת"ל', context='שעולה מספרם ת"ל', inline_expansion='430')
        self.assertEqual(r['he'], 'מִסְפָּר 430')

    def test_strong_gematria_context_beats_talmud_lomar(self):
        r = self.g.resolve('ת"ל', context='חמשה שמות אלהים שעולה מספרם ת"ל והם רמוזים')
        self.assertEqual(r['he'], 'מִסְפָּר 430')

    def test_yod_and_ab_context(self):
        self.assertIn('הָאוֹת', self.g.resolve('יו"ד', context='קוצו של יו"ד והיו"ד עצמה')['he'])
        self.assertIn('ע"ב', self.g.resolve('ע"ב', context='שם הוי"ה במילוי יודי"ן ע"ב')['he'])
        self.assertIn('עַמּוּד', self.g.resolve('ע"ב', context='סנהדרין דף ע"ב')['he'])

    def test_unmapped_entry_keeps_lemma(self):
        doc = {'entries': [{
            'seq': 1, 'daf': '30b', 'lemma_he': 'לֶמָּה',
            'commentary_html': 'פירוש', 'abbreviations': [], 'scripture_refs': [],
            'talmud': None, 'sefaria_ref': None,
        }]}
        seg = by_indesign.build_segments(doc, 'Berakhot', band_en_mode='empty')[0]
        self.assertIn('<lemma>לֶמָּה</lemma>', seg['he'])
        self.assertEqual(seg['band_he'], 'לֶמָּה')

    def test_longest_token_footnote_does_not_nest(self):
        text = 'בס"ד דבר ראשון; אחר כך ס"ד.'
        entry = {'abbreviations': [
            {'abbr': 'בס"ד', 'expansion': 'בְּסִיַּעְתָּא דִּשְׁמַיָּא'},
            {'abbr': 'ס"ד', 'expansion': 'סָלְקָא דַּעְתָּךְ'},
        ], 'scripture_refs': []}
        out, n = by_indesign.insert_footnotes(text, entry)
        self.assertEqual(n, 2)
        self.assertRegex(out, r'בס"ד<fn>בס"ד = .*?</fn>')
        self.assertRegex(out, r' ס"ד<fn>ס"ד = .*?</fn>')

    # --- Korrektur 2026-10-05 (Yoma) -------------------------------------
    def test_loose_small_bracket_keeps_commentary(self):
        import by_parse
        src = 'שם <small>[27] </small>כמנין הוי"ה ועוד <small>[342]</small> סוף'
        out = by_indesign.clean_body(src)
        self.assertIn('כמנין הוי"ה ועוד', out)
        self.assertNotIn('27', out)
        self.assertNotIn('342', out)
        self.assertEqual(by_parse.drop_small_brackets('צדיקים <small>[101].</small><br>'), 'צדיקים.<br>')

    def test_inline_expansion_does_not_span_brackets(self):
        import by_parse
        a = by_parse.find_abbrs('כ"ז <small>[27] </small>כמנין שם <small>[342]</small>')
        self.assertEqual(a[0]['inline_expansion'], '27')
        a = by_parse.find_abbrs('מוהרי"ש <small>[יוסף שאול נתנזון] </small>ז"ל')
        self.assertEqual(a[0]['inline_expansion'], 'יוסף שאול נתנזון')

    def test_multi_chunk_lemma_and_stray_close(self):
        import by_parse
        lem, body = by_parse.split_lemma(
            '<b>שָׁאֲלוּ אֶת רַבִּי אֶלְעָזָר</b>:<b> רִאשׁוֹנִים גְּדוֹלִים</b>, '
            '<b>אוֹ אַחֲרוֹנִים?.</b> יש להקשות')
        self.assertEqual(by_parse.strip_tags(lem), 'שָׁאֲלוּ אֶת רַבִּי אֶלְעָזָר: רִאשׁוֹנִים גְּדוֹלִים, אוֹ אַחֲרוֹנִים?.')
        self.assertTrue(body.startswith('יש להקשות'))
        lem, body = by_parse.split_lemma("<b>בָּנָה עֲנָת</b> וְכוּ'.</b> קשה")
        self.assertEqual(by_parse.strip_tags(lem), "בָּנָה עֲנָת וְכוּ'.")
        self.assertNotIn('</b>', body)

    def test_unvocalized_bold_commentary_is_not_lemma(self):
        import by_parse
        lem, body = by_parse.split_lemma("<b>בָּרוּךְ ה' וְגוֹ'.</b> <b>הקשא המהרש\"א</b> ז\"ל")
        self.assertEqual(by_parse.strip_tags(lem), "בָּרוּךְ ה' וְגוֹ'.")
        self.assertTrue(body.startswith('<b>הקשא'))

    def test_scripture_small_tags_removed_from_lemma(self):
        import by_parse
        lem, _ = by_parse.split_lemma('<b>שֶׁנֶּאֱמַר: <small>(דברי הימים א\' כט, יט)</small> "הַבִּירָה".</b> נראה')
        self.assertNotIn('small', by_parse.strip_tags(lem))
        self.assertIn('(דברי הימים א\' כט, יט)', by_parse.strip_tags(lem))

    def test_honorific_is_not_explained_by_following_quote(self):
        r = self.g.resolve('ז"ל', inline_expansion='אלא כל אחד ואחד מתפלל על עצמו')
        self.assertEqual(r['source'], 'curated')
        self.assertIn('לִבְרָכָה', r['he'])

    def test_validator_accepts_bare_fields_and_blocks_missing_lemma(self):
        raw = '''<book>\n<section>\n<he_title>דף א</he_title>\n<en_title>Daf 1a</en_title>\n</section>\n<segment id="BYH-0000001" n="1" daf="1a">\n<band_he>טקסט</band_he>\n<band_en></band_en>\n<he>פירוש</he>\n<en></en>\n</segment>\n</book>\n'''
        with tempfile.NamedTemporaryFile('w', suffix='.txt', encoding='utf-8', delete=False) as f:
            f.write(raw); path=f.name
        try:
            findings, stats, n = by_validate.validate(path, expect=1)
            self.assertEqual(n, 1)
            self.assertTrue(any(x['code'] == 'band_ohne_lemma' and x['level'] == 'FEHLER' for x in findings))
        finally:
            os.unlink(path)


if __name__ == '__main__':
    unittest.main()
