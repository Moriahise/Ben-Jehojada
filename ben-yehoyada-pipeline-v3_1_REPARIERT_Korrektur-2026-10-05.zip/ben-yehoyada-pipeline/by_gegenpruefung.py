# -*- coding: utf-8 -*-
"""
Unabhaengige Gegenpruefung einer Ben-Yehoyada-Banddatei gegen die beiden
Quelldateien (Senlake-Rohdatei und Dicta haser). Nutzt bewusst NICHT die
Pipeline-Funktionen, sondern liest beide Rohdateien selbst ein.

  A  Struktur      IDs lueckenlos, n/daf je Absatz wie in Senlake, Daf-Titel
  B  Hebraeisch    <he> (ohne <fn>, ohne Tags) == Senlake-Absatz (ohne
                   <small>[...]</small>-Erklaerungen, ohne Tags)
  C  Kopfband      <band_he> ist ein zusammenhaengender Wortausschnitt genau
                   des Dicta-Segments, das ref nennt; ohne ref == Lemma
  D  Fussnoten     kein Markup im <fn>, Kuerzel steht unmittelbar davor
  E  Leerfelder    <band_en> und <en> leer
  F  Tags          <b>/</b> im <he> ausgeglichen

    python3 by_gegenpruefung.py BAND.txt SENLAKE.txt DICTA.txt [--json out.json]

Entstanden beim Yoma-Lauf 2026-10-05; gilt fuer jeden Traktat. Bei einem
Mehrbandtraktat die Absaetze des jeweiligen Bandes beachten (Pruefung A/B
vergleicht ab dem ersten Senlake-Absatz).
"""
import html, json, re, sys

SEG = re.compile(r'<segment\s+([^>]*)>\s*\r?\n(.*?)\r?\n</segment>', re.S)
ATTR = re.compile(r'(\w+)="([^"]*)"')
SECTION = re.compile(r'<he_title>(.*?)</he_title>\s*\r?\n<en_title>(.*?)</en_title>')
NIKUD = re.compile(r'[֑-ׇ]')
HEB_VAL = {'א': 1, 'ב': 2, 'ג': 3, 'ד': 4, 'ה': 5, 'ו': 6, 'ז': 7, 'ח': 8, 'ט': 9,
           'י': 10, 'כ': 20, 'ל': 30, 'מ': 40, 'נ': 50, 'ס': 60, 'ע': 70, 'פ': 80,
           'צ': 90, 'ק': 100, 'ר': 200, 'ש': 300, 'ת': 400}


def field(body, k):
    m = re.search(r'<%s>(?:<!\[CDATA\[(.*?)\]\]>|(.*?))</%s>' % (k, k), body, re.S)
    if not m:
        return None
    return m.group(1) if m.group(1) is not None else m.group(2)


def chars(s):
    """Vergleichsform: nur sichtbare Zeichen, ohne jeden Leerraum."""
    return re.sub(r'\s+', '', s or '')


def senlake_paragraphs(path):
    out, cur, seq = [], None, 0
    for line in open(path, encoding='utf-8'):
        line = line.rstrip('\r\n')
        m = re.match(r'^Daf\s+(\S+)\s*$', line)
        if m:
            cur, seq = m.group(1), 0
            continue
        if cur is None or not line.strip():
            continue
        seq += 1
        out.append((cur, seq, line.strip()))
    return out


def senlake_text(para):
    # Senlake-Erklaerungen [..] sind Zusatz der Ausgabe, nicht Ben-Yehoyada-Text.
    s = re.sub(r'<small>\[(?:(?!</small>)[^\]])*\]\s*([.,:;]?)\s*</small>', r'\1', para)
    s = re.sub(r'<[^>]+>', '', s)
    return s


def dicta(path):
    out, cur = {}, None
    rx = re.compile(r'^\s*\*{2,}\s*דף\s+([א-ת"״׳\']+?)\s*([.:])\s*\*{2,}\s*$')
    for line in open(path, encoding='utf-8'):
        line = line.rstrip('\r\n')
        m = rx.match(line)
        if m:
            n = sum(HEB_VAL.get(c, 0) for c in m.group(1))
            cur = '%d%s' % (n, 'a' if m.group(2) == '.' else 'b')
            out.setdefault(cur, [])
            continue
        t = line.strip()
        if cur is None or not t or t in {"גמ'", 'גמ׳', "מתני'", 'מתני׳', 'הדרן', 'מתניתין', 'גמרא'}:
            continue
        out[cur].append(re.sub(r'<[^>]+>', '', t))
    return out


def daf_title_he(daf):
    m = re.match(r'^(\d+)([ab])$', daf)
    n, out = int(m.group(1)), ''
    for v, c in sorted(((v, c) for c, v in HEB_VAL.items()), reverse=True):
        while n >= v:
            out += c
            n -= v
    out = out.replace('יה', 'טו').replace('יו', 'טז')
    return 'דף {} {}'.format(out, 'ע"א' if m.group(2) == 'a' else 'ע"ב')


def main(band, senlake, dicta_path, json_out=None):
    raw = open(band, encoding='utf-8-sig').read()
    segs = [(dict(ATTR.findall(m.group(1))), m.group(2)) for m in SEG.finditer(raw)]
    paras = senlake_paragraphs(senlake)
    tal = dicta(dicta_path)
    res = {k: [] for k in 'ABCDEF'}
    stats = {'segmente': len(segs), 'senlake_absaetze': len(paras)}

    # A Struktur
    if len(segs) != len(paras):
        res['A'].append('Segmentzahl {} != Senlake-Absaetze {}'.format(len(segs), len(paras)))
    for i, ((a, _b), (daf, seq, _p)) in enumerate(zip(segs, paras), start=1):
        if a.get('id') != 'BYH-{:07d}'.format(i):
            res['A'].append('{}: ID statt BYH-{:07d}'.format(a.get('id'), i))
        if a.get('daf') != daf or a.get('n') != str(seq):
            res['A'].append('{}: daf/n {} {} statt {} {}'.format(a.get('id'), a.get('daf'), a.get('n'), daf, seq))
    titles = SECTION.findall(raw)
    dafs_used = []
    for _d, _s, _p in paras:
        if not dafs_used or dafs_used[-1] != _d:
            dafs_used.append(_d)
    want = [(daf_title_he(d), 'Daf ' + d) for d in dafs_used]
    if titles != want:
        res['A'].append('Daf-Titel weichen ab ({} statt {})'.format(len(titles), len(want)))
    stats['dafim'] = len(titles)

    # B Hebraeisch vollstaendig
    exact = 0
    for (a, b), (_d, _s, p) in zip(segs, paras):
        he = field(b, 'he') or ''
        he_txt = html.unescape(re.sub(r'<[^>]+>', '', re.sub(r'<fn>.*?</fn>', '', he)))
        src = senlake_text(p)
        if chars(he_txt) == chars(src):
            exact += 1
        else:
            x, y = chars(he_txt), chars(src)
            k = 0
            while k < min(len(x), len(y)) and x[k] == y[k]:
                k += 1
            res['B'].append({'id': a.get('id'), 'pos': k,
                             'band': x[max(0, k - 25):k + 25], 'senlake': y[max(0, k - 25):k + 25],
                             'len_band': len(x), 'len_senlake': len(y)})
    stats['he_wortgleich'] = exact

    # C Kopfband aus Dicta
    ok_c, fallback = 0, 0
    for a, b in segs:
        bh = (field(b, 'band_he') or '').strip()
        ref = a.get('ref', '')
        if not ref:
            lm = re.search(r'<lemma>(.*?)</lemma>', field(b, 'he') or '', re.S)
            if lm and chars(html.unescape(lm.group(1))) == chars(bh):
                fallback += 1
            else:
                res['C'].append('{}: ohne ref, Kopfband != Lemma'.format(a.get('id')))
            continue
        m = re.match(r'^.+ (\d+[ab]):(\d+)$', ref)
        if not m or m.group(1) not in tal or int(m.group(2)) > len(tal[m.group(1)]):
            res['C'].append('{}: ref {} nicht in Dicta'.format(a.get('id'), ref))
            continue
        segw = tal[m.group(1)][int(m.group(2)) - 1].split()
        bw = [w for w in bh.split() if w != '…']
        n = len(bw)
        hit = any(segw[j:j + n] == bw for j in range(0, len(segw) - n + 1))
        if hit:
            ok_c += 1
        else:
            res['C'].append('{}: Kopfband kein Wortausschnitt aus {}'.format(a.get('id'), ref))
        if m.group(1) != a.get('daf'):
            stats.setdefault('ref_nachbarblatt', []).append('{} daf={} ref={}'.format(a.get('id'), a.get('daf'), ref))
    stats['kopfband_aus_dicta'] = ok_c
    stats['kopfband_lemma_rueckfall'] = fallback

    # D Fussnoten
    nfn = 0
    for a, b in segs:
        he = field(b, 'he') or ''
        for m in re.finditer(r'<fn>(.*?)</fn>', he, re.S):
            nfn += 1
            note = m.group(1)
            if '&lt;' in note or '<' in note or ']' in note:
                res['D'].append('{}: Markup im <fn>: {}'.format(a.get('id'), note[:60]))
            if ' = ' in note:
                tok = html.unescape(note.split(' = ', 1)[0])
                before = html.unescape(re.sub(r'<[^>]+>', '', he[:m.start()]))
                if not before.endswith(tok):
                    res['D'].append('{}: <fn> {} steht nicht hinter dem Kuerzel'.format(a.get('id'), tok))
        if '<fn>' in re.sub(r'<fn>.*?</fn>', '', he, flags=re.S):
            res['D'].append('{}: verschachtelte <fn>'.format(a.get('id')))
    stats['fussnoten'] = nfn

    # E Leerfelder
    for a, b in segs:
        for k in ('band_en', 'en'):
            v = field(b, k)
            if v is None or v.strip():
                res['E'].append('{}: <{}> nicht leer/fehlt'.format(a.get('id'), k))

    # F Tags
    for a, b in segs:
        he = field(b, 'he') or ''
        if he.count('<b>') != he.count('</b>') or he.count('<lemma>') != 1:
            res['F'].append('{}: <b> {} / </b> {} / <lemma> {}'.format(
                a.get('id'), he.count('<b>'), he.count('</b>'), he.count('<lemma>')))

    names = {'A': 'Struktur', 'B': 'Hebraeischer Text vollstaendig', 'C': 'Kopfband aus Dicta',
             'D': 'Fussnoten', 'E': 'Leere Uebersetzungsfelder', 'F': 'Tag-Ausgleich'}
    print('== GEGENPRUEFUNG ==', band)
    for k, v in stats.items():
        if isinstance(v, list):
            print('{:26s}: {}'.format(k, len(v)))
            for x in v:
                print('      ' + x)
        else:
            print('{:26s}: {}'.format(k, v))
    for k in 'ABCDEF':
        print('{} {:32s}: {}'.format(k, names[k], 'OK' if not res[k] else '{} Befund(e)'.format(len(res[k]))))
        for x in res[k][:40]:
            print('      ', x)
    if json_out:
        json.dump({'stats': stats, 'befunde': res}, open(json_out, 'w', encoding='utf-8'),
                  ensure_ascii=False, indent=1)
    return 0 if not any(res[k] for k in 'ACDE') else 1


if __name__ == '__main__':
    a = sys.argv[1:]
    j = None
    if '--json' in a:
        j = a[a.index('--json') + 1]
        a = a[:a.index('--json')]
    sys.exit(main(a[0], a[1], a[2], j))
