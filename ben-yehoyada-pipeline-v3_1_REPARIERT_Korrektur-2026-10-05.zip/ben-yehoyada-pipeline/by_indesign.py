# -*- coding: utf-8 -*-
"""
Schritt 6 — Export fuer den InDesign-Buchmanager.

Erzeugt aus dem JSON der Pipeline die Banddateien, die
Ben_Yehoyada_Bilingual_Book_Manager_v2_0_0.jsx erwartet:

    Ben_Yehoyada_<Traktat>_Band_01_BILINGUAL.txt
    Ben_Yehoyada_<Traktat>_Band_01_GLOSSAR.tsv      (Uebersetzerhilfe)
    Ben_Yehoyada_<Traktat>_Bandplan.txt

Dateiformat je Segment:

    <segment id="BYH-0000001" n="1" daf="4b" ref="Berakhot 4b:19">
    <band_he>aramaeische Grundstelle</band_he>
    <band_en>englische Talmuduebersetzung</band_en>
    <he><lemma>Stichwort</lemma> Kommentar mit <fn>Abk = Aufloesung</fn></he>
    <en></en>
    </segment>

Die Bandplanung nutzt dieselbe Kalibrierung wie das JSX und teilt gleichmaessig
auf: erst Gesamtumfang schaetzen, dann durch die noetige Bandzahl teilen, damit
kein Band duenn bleibt. Ein Daf wird nie auseinandergerissen.

Aufruf:
    python3 by_indesign.py --in out/berakhot.glossed.json --tractate Berakhot \
                           --outdir out/indesign
"""
import json, os, re, argparse, math

from by_parse import drop_small_brackets

# --- Kalibrierung, identisch mit dem JSX -------------------------------------
HE_CHARS_PER_PAGE = 1280
EN_CHARS_PER_PAGE = 2420
EN_EXPANSION = 1.95
MAX_PAGES = 600
RESERVED_PAGES = 12
BODY_MAX = MAX_PAGES - RESERVED_PAGES
FRONT_MATTER = 16

HEB_NUM = {1: 'א', 2: 'ב', 3: 'ג', 4: 'ד', 5: 'ה', 6: 'ו', 7: 'ז', 8: 'ח', 9: 'ט',
           10: 'י', 20: 'כ', 30: 'ל', 40: 'מ', 50: 'נ', 60: 'ס', 70: 'ע', 80: 'פ', 90: 'צ',
           100: 'ק', 200: 'ר', 300: 'ש', 400: 'ת'}


def heb_number(n):
    out, rest = '', n
    for v in sorted(HEB_NUM.keys(), reverse=True):
        while rest >= v:
            out += HEB_NUM[v]
            rest -= v
    return out.replace('יה', 'טו').replace('יו', 'טז')


def daf_title_he(daf):
    m = re.match(r'^(\d+)([ab])$', daf)
    if not m:
        return daf
    return 'דף {} {}'.format(heb_number(int(m.group(1))),
                             'ע"א' if m.group(2) == 'a' else 'ע"ב')


def esc(s):
    return (s or '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def clean_body(s):
    """Nur <b> und <br> behalten; die <small>[...]</small>-Klammern entfernen."""
    # Korrektur 2026-10-05: by_parse.drop_small_brackets statt
    # <small>\[.*?\]</small> — das alte Muster loeschte bei <small>[27] </small>
    # den Kommentartext bis zur naechsten buendigen Klammer.
    s = drop_small_brackets(s)
    s = re.sub(r'<(?!/?b\b|br\b)[^>]*>', '', s)
    return re.sub(r'[ \t]+', ' ', s).strip()


def _first_token_span(text, token, occupied):
    """Erstes eigenstaendiges Vorkommen von *token*, ohne Ueberlappung."""
    # Keine kuerzere Abkuerzung innerhalb einer laengeren markieren.
    pat = re.compile(r'(?<![א-ת"״])' + re.escape(token) + r'(?![א-ת"״])')
    for m in pat.finditer(text):
        span = (m.start(), m.end())
        if any(not (span[1] <= a or span[0] >= b) for a, b in occupied):
            continue
        return span
    return None


def insert_footnotes(text, entry):
    """
    Setzt Fussnoten positionssicher hinter echte Token.

    Abkuerzungen werden laengste-zuerst verarbeitet. Dadurch kann z.B. ``ס"ד``
    nicht versehentlich im frueher stehenden ``בס"ד`` landen. Unaufgeloeste
    oder bewusst mehrdeutige Kuerzel erhalten keine automatische Fussnote.
    """
    marks, occupied = [], []
    abbrs = [a for a in entry.get('abbreviations', []) if a.get('expansion')]
    abbrs.sort(key=lambda a: len(a.get('abbr') or ''), reverse=True)
    for a in abbrs:
        token = a.get('abbr') or ''
        if not token:
            continue
        span = _first_token_span(text, token, occupied)
        if not span:
            continue
        occupied.append(span)
        marks.append((span[1], '{} = {}'.format(token, a['expansion'])))
    for ref in entry.get('scripture_refs', []):
        pos = text.find(ref)
        if pos >= 0:
            marks.append((pos + len(ref), ref.strip('()')))
    marks.sort(key=lambda m: m[0])
    seen, uniq = set(), []
    for pos, note in marks:
        if note in seen:
            continue
        seen.add(note)
        uniq.append((pos, note))
    for pos, note in sorted(uniq, key=lambda m: m[0], reverse=True):
        text = text[:pos] + '<fn>' + esc(note) + '</fn>' + text[pos:]
    return text, len(uniq)


def build_segments(doc, tractate, band_en_mode='source'):
    """
    band_en_mode:
      'source' — englisches Kopfband aus der Talmudquelle uebernehmen
      'empty'  — leer lassen; die Uebersetzerin fuellt es mit
                 (Eigenweg: keine fremde Lizenz im Buch)
    """
    segs = []
    for i, e in enumerate(doc['entries'], start=1):
        t = e.get('talmud') or {}
        band_he = t.get('he') or e.get('lemma_he') or ''
        band_en = '' if band_en_mode == 'empty' else (t.get('en') or '')
        body = clean_body(e.get('commentary_html'))
        body, n_fn = insert_footnotes(body, e)
        # Das Dibbur-ha-Matchil ist Teil des Ben-Yehoyada-Quelltexts und muss
        # unabhaengig vom Erfolg des Talmud-Mappings erhalten bleiben. Ohne
        # Mapping kann <band_he> auf dasselbe Zitat zurueckfallen; die semantische
        # <lemma>-Markierung im Kommentar darf deswegen trotzdem nie verschwinden.
        he = ''
        if e.get('lemma_he'):
            he += '<lemma>' + esc(e['lemma_he']) + '</lemma> '
        he += body
        he_chars = len(re.sub(r'<[^>]+>', '', he))
        segs.append({
            'id': 'BYH-{:07d}'.format(i),
            'n': e['seq'],
            'daf': e['daf'],
            'ref': e.get('sefaria_ref') or '',
            'band_he': band_he,
            'band_en': band_en,
            'he': he,
            'he_chars': he_chars + len(re.sub(r'<[^>]+>', '', band_he)),
            'footnotes': n_fn,
            'section_he': daf_title_he(e['daf']),
            'section_en': 'Daf ' + e['daf'],
        })
    return segs


def plan_volumes(segs):
    """Gleichmaessige Aufteilung, Schnitt nur an Daf-Grenzen."""
    for s in segs:
        he_p = s['he_chars'] / float(HE_CHARS_PER_PAGE)
        en_p = (s['he_chars'] * EN_EXPANSION) / float(EN_CHARS_PER_PAGE)
        s['pages'] = max(he_p, en_p)
    total = sum(s['pages'] for s in segs) + FRONT_MATTER
    n_vol = max(1, int(math.ceil(total / float(BODY_MAX))))
    target = total / float(n_vol)

    # Dafim als unteilbare Gruppen
    groups, cur, cur_daf = [], [], None
    for s in segs:
        if s['daf'] != cur_daf:
            if cur:
                groups.append(cur)
            cur, cur_daf = [], s['daf']
        cur.append(s)
    if cur:
        groups.append(cur)

    volumes, vol, acc = [], [], 0.0
    for g in groups:
        gp = sum(s['pages'] for s in g)
        if vol and acc + gp > target and len(volumes) < n_vol - 1:
            volumes.append(vol)
            vol, acc = [], 0.0
        vol.extend(g)
        acc += gp
    if vol:
        volumes.append(vol)
    return volumes, total, n_vol


SEG_RE = re.compile(r'<segment\s+([^>]*)>\s*\n(.*?)\n</segment>', re.S)
ATTR_RE = re.compile(r'(\w+)="([^"]*)"')
BAND_RE = re.compile(r'<band_he>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</band_he>', re.S)
LEMMA_RE = re.compile(r'<lemma>(.*?)</lemma>', re.S)
HE_RE = re.compile(r'<he>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</he>', re.S)


def read_existing_bands(paths):
    """Liest <band_he> und das ref-Attribut je Segment-ID aus vorhandenen Banddateien."""
    out = {}
    for p in paths:
        if not p or not os.path.exists(p):
            continue
        raw = open(p, encoding='utf-8-sig').read()
        for m in SEG_RE.finditer(raw):
            attrs = dict(ATTR_RE.findall(m.group(1)))
            bm = BAND_RE.search(m.group(2))
            if attrs.get('id') and bm:
                out[attrs['id']] = {'band_he': bm.group(1), 'ref': attrs.get('ref')}
    return out


def carry_over_bands(segs, existing, margin=0.05):
    """
    Uebernimmt ein vorhandenes Kopfband, wenn es die zitierte Stelle
    mindestens so gut traegt wie das neu berechnete.

    Warum das noetig ist: zu einem Grossteil der Segmente liegt bereits eine
    Uebersetzung vor — auch des Kopfbands. Jede Aenderung an <band_he> macht
    die zugehoerige Uebersetzung pruefbeduerftig. Ein Neulauf darf deshalb
    nicht jede Formulierung neu zuschneiden, nur weil die Automatik heute
    anders schneiden wuerde. Er ersetzt ein Band nur dort, wo das neue die
    Stelle nachweislich besser traegt. Damit ist die Neuerzeugung
    wiederholbar und zerstoerungsfrei.

    Gemessen wird mit derselben Ausrichtung wie bei der Zuordnung.
    """
    import by_band as BB
    kept = replaced = 0
    for s in segs:
        prev = existing.get(s['id'])
        if prev is None:
            continue
        if not (prev.get('ref') or '').strip():
            # Nie zugeordnet gewesen: das alte Band ist der Rueckfall auf das
            # Lemma und wuerde gegen sich selbst Deckung 1,0 erreichen. Liegt
            # jetzt eine echte Talmudstelle vor, ersetzt sie es.
            replaced += 1
            continue
        lm = LEMMA_RE.search(s.get('he') or '')
        if not lm:
            continue
        lemma = lm.group(1)
        _, cov_old = BB.band_contains_lemma(prev['band_he'], lemma)
        _, cov_new = BB.band_contains_lemma(s['band_he'], lemma)
        if cov_new < cov_old + margin:
            s['band_he'] = prev['band_he']
            # Die Fundstelle gehoert zum Band: wird das alte Band behalten,
            # bleibt auch seine Referenz stehen. Sonst zeigte das ref-Attribut
            # auf ein Segment, aus dem der Text gar nicht stammt.
            if prev.get('ref'):
                s['ref'] = prev['ref']
            kept += 1
        else:
            replaced += 1
    return {'uebernommen': kept, 'ersetzt': replaced}


def cdata(s):
    """
    Feldinhalte in CDATA legen — so, wie der Buchmanager sie zurueckschreibt.

    Der Grund ist Rundlauffaehigkeit: das JSX schreibt beim Zusammenfuehren
    der Uebersetzungsbatches CDATA (protectCdata). Schrieb die Pipeline die
    Felder nackt, unterschieden sich frisch erzeugte und zurueckgeschriebene
    Banddateien in der Form, und ein Vergleich der beiden zeigte Aenderungen,
    wo keine waren. Ein ']]>' im Text wird wie im JSX aufgeteilt.
    """
    return '<![CDATA[' + str(s or '').replace(']]>', ']]]]><![CDATA[>') + ']]>'


def write_volume(path, vol_no, segs, tractate):
    out = ['<book project="Ben Yehoyada" tractate="{}" volume="{:02d}" max_pages="{}">'.format(
        tractate, vol_no, MAX_PAGES)]
    last = None
    for s in segs:
        key = (s['section_he'], s['section_en'])
        if key != last:
            out += ['', '<section>',
                    '<he_title>' + esc(s['section_he']) + '</he_title>',
                    '<en_title>' + esc(s['section_en']) + '</en_title>',
                    '</section>']
            last = key
        attrs = 'id="{}" n="{}" daf="{}"'.format(s['id'], s['n'], esc(s['daf']))
        if s['ref']:
            attrs += ' ref="{}"'.format(esc(s['ref']))
        out += ['', '<segment {}>'.format(attrs),
                '<band_he>' + cdata(s['band_he']) + '</band_he>',
                '<band_en>' + cdata(s['band_en']) + '</band_en>',
                '<he>' + cdata(s['he']) + '</he>',
                '<en>' + cdata('') + '</en>',
                '</segment>']
    out += ['', '</book>']
    # utf-8-sig + CRLF: genau die Form, die der Buchmanager selbst schreibt.
    # Sonst unterscheiden sich frisch erzeugte und zurueckgeschriebene
    # Banddateien schon im ersten Byte.
    open(path, 'w', encoding='utf-8-sig', newline='').write('\r\n'.join(out))


def write_glossary(path, doc):
    rows = ['abbr\thebrew\tenglish']
    for k, v in sorted((doc.get('glossary_curated') or {}).items()):
        rows.append('{}\t{}\t{}'.format(k, v.get('he', ''), v.get('en', '')))
    open(path, 'w', encoding='utf-8', newline='').write('\r\n'.join(rows))


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--in', dest='src', default='out/berakhot.glossed.json')
    ap.add_argument('--tractate', default='Berakhot')
    ap.add_argument('--outdir', default='out/indesign')
    ap.add_argument('--band-en', choices=['source','empty'], default='source',
                    help="'empty' laesst das englische Kopfband leer; die "
                         "Uebersetzerin fuellt es mit (lizenzfreier Eigenweg)")
    a = ap.parse_args()

    doc = json.load(open(a.src, encoding='utf-8'))
    os.makedirs(a.outdir, exist_ok=True)

    # Stolperfalle: .mapped.json kennt die Abkuerzungsaufloesungen noch nicht,
    # nur .glossed.json. Ohne sie entstehen fast keine Fussnoten - und das faellt
    # sonst erst im gesetzten Band auf.
    resolved = sum(1 for e in doc['entries'] for x in e.get('abbreviations', [])
                   if x.get('expansion'))
    if resolved == 0:
        print('WARNUNG: keine aufgeloesten Abkuerzungen in dieser Datei.')
        print('         Vermutlich wurde .mapped.json statt .glossed.json uebergeben.')
        print('         Der Export laeuft weiter, enthaelt aber kaum Fussnoten.\n')
    segs = build_segments(doc, a.tractate, band_en_mode=a.band_en)
    volumes, total, n_vol = plan_volumes(segs)

    plan = ['BEN JEHOJADA · {} · BANDPLAN'.format(a.tractate.upper()),
            'Segmente: {}   geschaetzter Gesamtumfang: {:.0f} Seiten'.format(len(segs), total),
            'Kalibrierung: HE {} Z./S. · EN {} Z./S. · Expansion {}'.format(
                HE_CHARS_PER_PAGE, EN_CHARS_PER_PAGE, EN_EXPANSION),
            'Grenze je Band: {} Seiten Text (+{} Reserve) = {} gesamt'.format(
                BODY_MAX, RESERVED_PAGES, MAX_PAGES), '']
    tag = a.tractate.replace(' ', '_')
    for i, v in enumerate(volumes, start=1):
        p = sum(s['pages'] for s in v) + (FRONT_MATTER if i == 1 else 4)
        f = os.path.join(a.outdir, 'Ben_Yehoyada_{}_Band_{:02d}_BILINGUAL.txt'.format(tag, i))
        write_volume(f, i, v, a.tractate)
        line = ('Band {:02d}: ca. {:.0f} Seiten · {} Segmente · {} bis {} · '
                'Daf {} bis {} · {} Fussnoten').format(
            i, p, len(v), v[0]['id'], v[-1]['id'], v[0]['daf'], v[-1]['daf'],
            sum(s['footnotes'] for s in v))
        plan.append(line)
        print(line)
    write_glossary(os.path.join(a.outdir, 'Ben_Yehoyada_{}_GLOSSAR.tsv'.format(tag)), doc)
    open(os.path.join(a.outdir, 'Ben_Yehoyada_{}_Bandplan.txt'.format(tag)),
         'w', encoding='utf-8', newline='').write('\r\n'.join(plan))
    print('\nGesamt {:.0f} Seiten -> {} Bände'.format(total, n_vol))
    print('->', a.outdir)
