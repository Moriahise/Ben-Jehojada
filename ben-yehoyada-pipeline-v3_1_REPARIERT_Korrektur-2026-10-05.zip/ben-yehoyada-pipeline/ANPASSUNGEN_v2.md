# Ben Jehojada · Buchmanager v2.0.0 — was gegenüber v1.0.17 geändert wurde

Abgeleitet vom `Ben_Ish_Chai_Bilingual_Book_Manager_v1_0_17.jsx`.
Die gesamte erprobte Mechanik ist **unverändert** übernommen: Rahmenverkettung,
Reparatur, Übersatz-Erweiterung, Batch-Queue, Bulk-Merge, Layout-Snapshots,
Seitensperren, Backups und die Divider-Balancing-Engine.

---

## Die eine Entwurfsentscheidung, die alles andere trägt

Der volle Apparat — Talmud-Kopfband *und* Fußnoten — hätte pro Seite vier
Textzonen statt zwei bedeutet, und die Divider-Optimierung hätte von zwei auf
vier Zonen umgebaut werden müssen. Das ist der komplexeste und empfindlichste
Teil deines Skripts.

Stattdessen liegen beide neuen Elemente **innerhalb der bestehenden zwei
Textflüsse**:

- Das **Kopfband** ist ein Absatzstil am Kopf jedes Segments — im hebräischen
  Fluss die aramäische Grundstelle, im englischen ihre Übersetzung. Da der
  hebräische Rahmen ohnehin die volle Satzbreite hat, wirkt der Bandabsatz
  optisch wie ein durchlaufendes Band.
- Die **Fußnoten** werden beim Formatieren aus `<fn>…</fn>`-Marken in echte
  InDesign-Fußnoten umgewandelt. InDesign platziert sie selbst am Fuß des
  jeweiligen Rahmens: hebräische Noten unter dem hebräischen Rahmen, englische
  unter dem englischen.

Ergebnis: Die Balancing-Engine bleibt zweizonig und muss vom Apparat nichts
wissen. Kein Eingriff in `optimizeOnePageDivider*`, `evaluatePageAnchor`,
`buildStorySegmentRanges` oder `applyBatchLayoutBalance`.

---

## Geändert

### 1. Seitenformat — 7 × 10 Zoll statt A5

| | v1.0.17 (Ben Ish Chai) | v2.0.0 (Ben Jehojada) |
|---|---|---|
| Seite | 148 × 210 mm | 177,8 × 254 mm |
| Stege | 12,7 mm umlaufend | innen 19,1 · außen 14 · oben 16 · unten 20 |
| HE-Rahmen | [16,82 · 15,90 · 103,24 · 128,57] | [21,00 · 14,00 · 126,00 · 158,70] |
| EN-Rahmen | [106,24 · 15,90 · 189,89 · 128,57] | [129,00 · 14,00 · 234,00 · 158,70] |
| Nominale Trennung | 103,24 mm | 126,00 mm |
| Mindesthöhe je Rahmen | 55 mm | 65 mm |

`setPageMargins()` setzt jetzt **asymmetrische** Stege und spiegelt innen/außen
je Seitenseite. Der Bundsteg von 19,1 mm ist KDP-Pflicht für Bände von 501–700
Seiten — darunter wird die Datei abgelehnt.

### 2. Schriften

| | v1.0.17 | v2.0.0 |
|---|---|---|
| Hebräisch | Keter YG Medium 10/12 | **Frank Ruhl Libre** Regular 11/16 |
| Englisch | Cambria Regular 9/10.8 | **Minion Pro** Regular 9,5/12,8 |

Frank Ruhl Libre steht unter SIL OFL und darf eingebettet werden — KDP lehnt
PDFs mit nicht eingebetteten Schriften ab. **Wenn du bei Keter YG bleiben
willst, prüfe zuerst dessen Einbettungslizenz** und ändere `HE_FONT` /
`HE_FONT_STYLE` oben im Skript.

### 3. Neue Stile

`BY · Talmud · Hebräisch`, `BY · Talmud · English`, `BY · Fussnote · Hebräisch`,
`BY · Fussnote · English`, Zeichenformat `BY · Lemma`.

Das Kopfband bekommt Linien oben (0,8 pt) und unten (0,4 pt) und 8 % Schwarz
als Hinterlegung — in Graustufen gedruckt, ohne Farbe.

### 4. Datenformat

```xml
<segment id="BYH-0000052" n="2" daf="4b" ref="Berakhot 4b:19">
<band_he>אֵיזֶהוּ בֶּן עוֹלָם הַבָּא? …</band_he>
<band_en>Who is a member of the World to Come? …</band_en>
<he><lemma>…</lemma> Kommentar mit <fn>בס"ד = בְּסִיַּעְתָּא דִּשְׁמַיָּא</fn></he>
<en></en>
</segment>
```

Neu: `band_he`, `band_en`, die Attribute `daf` und `ref`, sowie die Tags
`<lemma>` und `<fn>` im Fließtext.

`parseBilingualFile()` liest Segmente jetzt blockweise und die Felder einzeln
statt mit einer langen Regex — ein fehlendes optionales Feld zerlegt damit nicht
mehr den ganzen Treffer.

### 5. Übersetzungs-Batches

Die Batchdateien führen `band_he` und `band_en` als **Kontext** mit. Der
Übersetzer sieht die Talmudstelle, zu der der Kommentar gehört — ohne sie ist
der Text über weite Strecken nicht übersetzbar. Beide Felder bleiben
unverändert; `mergeBatch()` übernimmt weiterhin ausschließlich `<en>`.

### 6. Kalibrierung und Bandaufteilung

| | v1.0.17 | v2.0.0 |
|---|---|---|
| HE Zeichen/Seite | 1050 | 1280 |
| EN Zeichen/Seite | 2000 | 2420 |
| Expansion HE→EN | 1.95 | 1.95 *(unverändert übernommen)* |

Die neuen Werte sind deine A5-Zahlen, skaliert mit der Rahmenfläche und dann um
den Platz reduziert, den Kopfband und Fußnoten fressen (HE ×0,78 · EN ×0,75).

`BALANCE_VOLUMES` ist neu: Der Planer schätzt erst den Gesamtumfang und teilt
ihn dann gleichmäßig auf die nötige Bandzahl auf, statt jeden Band bis zum Ziel
zu füllen und den letzten dünn zu lassen.

**Berachot ergibt damit: ca. 674 Seiten → 2 Bände à 348 und 330 Seiten.**

---

## Was du vor dem ersten Lauf prüfen musst

1. **Schriften installiert?** Frank Ruhl Libre und Minion Pro müssen in InDesign
   verfügbar sein, sonst greift `safeFont()` auf eine Ersatzschrift zurück und
   die Kalibrierung stimmt nicht mehr.
2. **An einer Kopie testen.** Die Fußnoten-Umwandlung verändert die Story
   unwiderruflich — `<fn>`-Marken verschwinden und werden zu echten Fußnoten.
   Einmal gelaufen, lässt sie sich nicht per Rückgängig zurückdrehen.
3. **Erste 30 Seiten nachmessen.** Dann `HE_CHARS_PER_PAGE` und
   `EN_CHARS_PER_PAGE` an der realen Satzdichte nachziehen und die Bandplanung
   einmal neu laufen lassen.
4. **Fußnotenmenge.** Band 01 bringt rund 1.650, Band 02 rund 1.450 Fußnoten
   mit. Die Umwandlung läuft rückwärts durch die Story und braucht trotzdem
   spürbar Zeit — der Statusbalken zeigt den Fortschritt.
5. **Leserichtung.** Das Dokument bleibt auf `LEFT_TO_RIGHT` gebunden, passend
   zur Empfehlung, den Band bei KDP als englisches Buch anzumelden.

---

## Unverändert geblieben

Rahmenverkettung und -reparatur · automatische Seitenerweiterung bei Übersatz ·
Batch-Export, -Queue und -Merge über stabile IDs · Bulk-Ablauf · Layout-Snapshots
und Wiederherstellung · Seitensperren · INDD-Backups · Validierung · die
komplette Palette-Oberfläche mit ihrer Farbkodierung.
