# Kopfband-Zuordnung — Korrektur vom 23. September 2026

Betrifft Schritt 2 der Pipeline und damit jedes `<band_he>` in jeder Banddatei.
Ausloeser waren sieben gemeldete Fehlstellen in Berachot Band 01
(BYH-0000260, -0000283, -0000299, -0000300, -0000321, -0000325, -0000328).
Sie waren Beispiele, keine Liste: die Ursachen waren systematisch und haben
insgesamt 30 Kopfbaender in Band 01 betroffen.

---

## Was falsch war

Drei voneinander unabhaengige Ursachen, alle in der alten `by_sefaria.py`.

### 1 · Die Segmentwahl nahm den ersten, nicht den besten Treffer

`match_lemma` arbeitete in vier Stufen — `contains`, `skeleton`, `headwords`,
`fuzzy` — und nahm in jeder Stufe das **erste** Segment, das die Bedingung
erfuellte. Die Stufe `headwords` prueft nur die ersten vier Woerter.

Auf Berachot 16b stehen zwei Gebete, die beide mit
„יהי רצון מלפניך ה'" beginnen: das des R. Elasar (16b:9) und das des Rabbi
(16b:12). Das Lemma von BYH-0000283 meint das zweite, bekam aber das erste,
weil es frueher in der Liste steht. Dasselbe Muster trifft jeden formelhaften
Satzanfang: „עליו הכתוב אומר", „אמר ליה", „תנו רבנן".

### 2 · Der Ausschnitt ankerte auf drei Woertern, am ersten Vorkommen

`trim_band` suchte die ersten drei Lemma-Woerter im Segment und schnitt ab
dort 42 Woerter. Kommt die Wendung im Segment zweimal vor, ankerte das
Fenster an der falschen Stelle.

Berachot 20a:4 enthaelt „לא קא מסתפי מר **מיצר הרע**" und spaeter
„לא קא מסתפי מר **מעינא בישא**". BYH-0000321 zitiert die zweite Frage; das
Kopfband zeigte die erste. Der Kommentar spricht ueber den boesen Blick, das
Band ueber den boesen Trieb.

Scheiterten die drei Woerter ganz — etwa weil der Ben Jehojada aramaeisch
paraphrasiert („והלין בני מתא מחסיא" gegen „בני מתא מחסיא") — fiel die
Funktion **stillschweigend** auf die ersten 42 Woerter des Segments zurueck.
So entstand BYH-0000300.

### 3 · Niemand prueft, ob das Kopfband die Stelle ueberhaupt enthaelt

Der Bericht meldete Trefferquote und Methodenverteilung. Ob das ausgegebene
Band die zitierte Passage wirklich traegt, wurde nie gemessen. Deshalb fielen
die Fehler erst beim Uebersetzen auf — Segment fuer Segment, von Hand.

---

## Was jetzt gilt

Beide Fragen — welches Segment, welcher Ausschnitt — beantwortet **eine**
Messung: die Ausrichtung des **vollstaendigen** Lemmas auf die Wortfolge des
Segments (`by_band.align_detail`). Sie liefert Deckung, Anfang und Ende der
zitierten Passage.

| | alt | neu |
|---|---|---|
| Segmentwahl | erste Stufe, die zieht | hoechste Deckung des ganzen Lemmas |
| Anker | erste drei Lemma-Woerter | beste Uebereinstimmung im Segment |
| Wortgrenze | harter Schnitt bei 42 | 42 als Zielgroesse; waechst, bis die Passage vollstaendig ist |
| Blattwechsel | sobald das eigene Blatt nichts liefert | nur bei deutlichem Vorsprung (0,15 Deckung) |
| Fehlschlag | stillschweigend Segmentkopf | keine Zuordnung, Lemma bleibt im Band |
| Prueffrage | keine | „steckt das Lemma im Kopfband?" im Bericht und im Validator |

Dazu vier Angleichungen an der Vergleichsebene, jede aus einem echten Fall:

* **Endbuchstaben** — ם/ן am Wortende werden gleichgesetzt. „צנועים באכילתם"
  gegen „צנועין באכילתן" ist derselbe Wortlaut; ohne die Angleichung fiel die
  Deckung von BYH-0000192 auf null.
* **Auslautendes He/Alef** — אכסדרה gegen אכסדרא. An diesem einen Buchstaben
  scheiterte Berachot 10b:5.
* **Kuerzel** — im Lemma werden sie versuchsweise aufgeloest, und zwar in
  beiden Lesarten mehrdeutiger Kuerzel. „למ״ד" ist der Buchstabe Lamed *und*
  die Kurzform von „למאן דאמר"; verglichen wird gegen beides, die bessere
  Ausrichtung gilt. Die Aufloesung kann so nur helfen, nie schaden.
* **Dichte und Zusammenhang** — ein vierwoertiges Lemma, dessen Woerter sich
  ueber 600 Woerter eines Dicta-Segments verteilen, ist kein Treffer.
  Berachot 7a:1 gewann so gegen 6a:6. Eine Zuordnung ohne **eine einzige**
  zusammenhaengende Wortfolge wird gar nicht erst getroffen; dort bleibt das
  Lemma im Kopfband stehen, was ehrlicher ist als eine falsche Talmudstelle.

---

## Handentscheidungen: `band_overrides.json`

Manche Stellen kann keine Automatik entscheiden. BYH-0000260 zitiert
„אמר ליה במה קאמרת" — vier Woerter, davon zwei Allerweltswoerter, und der
Talmud schreibt „אמרו לו במה אמרת". Welche der beiden Stellen auf Berachot 14a
gemeint ist, sagt erst der Kommentar selbst.

Solche Faelle gehoeren in `band_overrides.json`. Die Tabelle wird bei **jedem**
Lauf gelesen und geht der Automatik vor. Das ist der Punkt, an dem die
urspruengliche Meldung recht hatte: eine Korrektur in der TXT-Datei allein
waere beim naechsten Lauf wieder ueberschrieben worden.

Format je Eintrag: Segment-ID, `entry_id` aus Schritt 1, Blatt, Segmentnummer,
**Begruendung** und Pruefdatum. Die Begruendung ist Pflicht — sie ist der
Unterschied zwischen einer Entscheidung und einem Eingriff.

Systematische Fehler gehoeren **nicht** hierher, sondern nach `by_band.py`.

---

## Zerstoerungsfreier Neulauf: `--keep-bands`

Zu einem grossen Teil der Segmente liegt bereits eine Uebersetzung vor, auch
des Kopfbands. Jede Aenderung an `<band_he>` macht die zugehoerige
Uebersetzung pruefbeduerftig. Ein Neulauf darf deshalb nicht jedes Band neu
zuschneiden, nur weil die Automatik es heute anders schneiden wuerde.

```bash
python3 run_pipeline.py --in source/Ben_Yehoyada_on_Berakhot.txt \
    --tractate Berakhot \
    --talmud-he source/talmud/Berakhot_Dicta_haser.txt \
    --band-words 42 --band-en empty \
    --keep-bands /pfad/zu/den/geprueften/banddateien
```

Mit `--keep-bands` liest Schritt 6 die vorhandenen Banddateien und behaelt ein
Kopfband, wenn es die zitierte Stelle mindestens so gut traegt wie das neu
berechnete. Ersetzt wird nur, wo das neue nachweislich besser ist. Die
Fundstelle (`ref`) wandert dabei mit dem Band — sonst zeigte sie auf ein
Segment, aus dem der Text gar nicht stammt.

Eine Ausnahme: war ein Segment nie zugeordnet, steht in seinem Band der
Rueckfall auf das Lemma selbst. Gegen das eigene Lemma gemessen erreicht das
Deckung 1,0 und wuerde jede echte Talmudstelle blockieren. Liegt jetzt eine
Zuordnung vor, gewinnt sie.

**Geprueft:** Ein Lauf mit `--keep-bands` gegen die korrigierte Fassung von
Band 01 erzeugt sie exakt wieder — 0 Abweichungen in `band_he`, 0 in `ref`.

---

## Abnahmeprüfung: `by_validate.py`

Das Tor vor jedem neuen Uebersetzungsbatch.

```bash
python3 by_validate.py --in Band_01_BILINGUAL.txt \
                       --against Band_01_BILINGUAL.vorher.txt \
                       --expect 338 --json abnahme.json
```

Geprueft wird in vier Stufen:

1. **Struktur** — Segmentzahl, eindeutige und aufsteigende IDs, alle fuenf
   Felder vorhanden, CDATA sauber geschlossen, Attribute `n` und `daf` da.
2. **Geschuetzte Felder** — `<he>`, `<en>`, `<band_en>`, IDs, `n`, `daf` und
   die Abschnittsueberschriften sind gegenueber der Vergleichsfassung
   unveraendert.
3. **Kopfband** — steckt das Lemma darin? Unter 0,34 Deckung ist es ein
   FEHLER, zwischen 0,34 und 0,85 ein PRUEFEN.
4. **Uebersetzungsfolgen** — zu jedem geaenderten `band_he` mit bereits
   uebersetztem `band_en` ein PRUEFEN.

Rueckgabe-Code 1, sobald ein FEHLER vorliegt. PRUEFEN und HINWEIS blockieren
nicht.

---

## Geaenderte Dateien

| Datei | Aenderung |
|---|---|
| `by_band.py` | **neu** — Ausrichtung, Segmentwahl, Ausschnitt, Kopfbandpruefung, Selbsttest |
| `by_validate.py` | **neu** — Abnahmeprüfung einer Banddatei |
| `band_overrides.json` | **neu** — Handentscheidungen, ueberleben jeden Lauf |
| `by_sefaria.py` | `match_lemma` und `trim_band` delegieren an `by_band`; Blattvorzug; Overrides; Kopfbandpruefung im Bericht |
| `by_indesign.py` | `--keep-bands`-Mechanik; Felder in CDATA; BOM wie beim Buchmanager |
| `run_pipeline.py` | `--keep-bands`; zwei neue Berichtszeilen |
| `glossary_he.json` | `למ״ד` kuratiert mit `alt`-Lesart |

## Referenzlauf Berachot, vorher und nachher

| | vorher | nachher |
|---|---|---|
| zugeordnet | 667 / 680 (98,1 %) | 671 / 680 (98,7 %) |
| Kopfband ohne die Stelle | ungemessen (12 allein in Band 01) | 0 |
| Wortlaut weicht ab | ungemessen | 106 (Lektorat) |
| Band 01 | 338 Segmente | 338 Segmente, IDs unveraendert |
