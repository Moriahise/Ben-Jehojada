# -*- coding: utf-8 -*-
"""
Schritt 1 — Parsen.

Zerlegt eine Senlake-/Sefaria-Textdatei des Ben Jehojada in strukturierte
Eintraege. Funktioniert fuer jeden Traktat, solange die Datei dem Muster folgt:

    Daf 4b                     <- Blattmarke, eigene Zeile
    <b>LEMMA</b> Kommentar...  <- ein Absatz = ein Eintrag
    ...<br><b>ודע</b>...       <- Unterabschnitt innerhalb eines Eintrags
    ABK <small>[Aufloesung]</small>   <- von der Ausgabe mitgelieferte Erklaerung

Aufruf:
    python3 by_parse.py --in ben_yehoyada_berakhot.txt --tractate Berakhot \
                        --out out/berakhot.parsed.json
"""
import re, json, os, argparse, collections

NIKUD = re.compile(r'[֑-ׇ]')
ABBR_TOK = re.compile(r'[א-ת֑-ׇ]+["״][א-ת֑-ׇ]+(?:["״][א-ת֑-ׇ]+)*')
SCRIPT_RE = re.compile(r'\(([^)]{2,40}?,[^)]{1,20}?)\)')
# Korrektur 2026-10-05 (Yoma): Senlake schliesst die Erklaerungsklammer nicht
# immer buendig. Neben <small>[48]</small> stehen <small>[27] </small> und
# <small>[101].</small>. Das alte Muster <small>\[.*?\]</small> lief dann bis
# zum NAECHSTEN ']</small>' weiter: im Kommentar verschwand der Text dazwischen,
# in der Fussnote stand er stattdessen. Die Klammer darf jetzt weder ']' noch
# '</small>' ueberspringen; Leerraum und ein Satzzeichen vor '</small>' gehoeren
# noch zu ihr.
SMALL_BRACKET = r'<small>\[((?:(?!</small>)[^\]])*)\](\s*)([.,:;]?)(\s*)</small>'
SMALL_BRACKET_RE = re.compile(r'(\s*)' + SMALL_BRACKET)
PAIR_RE = re.compile(r'(\S+?)\s*' + SMALL_BRACKET)
LEMMA_RE = re.compile(r'^\s*<b>(.*?)</b>(.*)$', re.S)
DAF_RE = re.compile(r'^Daf\s+(\S+)\s*$')


def drop_small_brackets(s):
    """
    Entfernt Senlake-Erklaerungen <small>[...]</small> und nur diese.

    Bei buendiger Klammer bleibt das Ergebnis wie bisher (leer); stand vor
    '</small>' Leerraum, bleibt ein Leerzeichen, damit Woerter nicht
    zusammenwachsen; ein Satzzeichen in der Klammer bleibt am Text stehen.
    """
    def repl(m):
        lead, ws1, punct, ws2 = m.group(1), m.group(3), m.group(4), m.group(5)
        if punct:
            return punct + (' ' if ws2 else '')
        return lead or (' ' if (ws1 or ws2) else '')
    return SMALL_BRACKET_RE.sub(repl, s or '')


# Bestandteile eines Absatzanfangs fuer split_lemma.
_LEM_TOK = re.compile(r'<b>|</b>|<br>|<small>\((?:(?!</small>).)*?</small>|<small>\[|'
                      r'<small>|</small>|[^<]+|<', re.S)
_HEB = re.compile(r'[א-ת]')
# Ein ueberzaehliges </b> markiert in Senlake-Yoma das Ende des Dibbur
# ha-Matchil. Liegt zwischen fettem Lauf und dieser Marke nur ein kurzes
# Stueck ungefetteten Talmudtexts (z.B. "וְכוּ'."), gehoert es noch dazu.
STRAY_MAX_WORDS = 8
# "וכו'" vor der Schlussmarke gehoert zum Zitat, auch unvokalisiert (Yoma 77a).
_ETC = re.compile(r"[\s.,:;]*(?:וכו|וגו|וְכוּ|וְגוֹ)['׳][\s.,:;]*")


def _talmud_text(t):
    """Talmudzitat oder blosse Interpunktion? Senlake vokalisiert das Zitat,
    nicht den Kommentar. Ein fettes Stueck ohne Nikud (z.B. Berakhot 54a:
    '<b>הקשא המהרש"א</b>') ist Kommentar und gehoert nicht zum Lemma."""
    t = re.sub(r'<[^>]+>', '', t)
    return not _HEB.search(t) or bool(NIKUD.search(t))


def split_lemma(para):
    """
    Trennt das Dibbur ha-Matchil vom Kommentar -> (lemma_html, body_html).

    Korrektur 2026-10-05 (Yoma): Berakhot setzt das Lemma als EIN fettes Stueck.
    Andere Senlake-Traktate zerlegen dasselbe Zitat an jedem Satzzeichen in
    mehrere <b>-Stuecke und schliessen es mit einem ueberzaehligen </b>:

        <b>שָׁאֲלוּ אֶת רַבִּי אֶלְעָזָר</b>:<b> רִאשׁוֹנִים גְּדוֹלִים</b>, <b>אוֹ אַחֲרוֹנִים?.</b> יש להקשות

    Das alte Muster nahm nur das erste Stueck; der Rest des Zitats rutschte
    mitsamt dem losen </b> in den Kommentar. Jetzt gilt als Lemma der ganze
    fette Lauf am Absatzanfang. Zwischen zwei Stuecken duerfen nur Leerraum,
    Satz- und Anfuehrungszeichen und eingeklammerte Schriftverweise
    <small>(...)</small> stehen. Der Lauf endet am ersten ungefetteten
    hebraeischen Buchstaben, an <br> oder an einer Erklaerung <small>[...].
    """
    s = (para or '').strip()
    if not s.startswith('<b>'):
        return None, s
    bold, end, seen = False, len(s), False
    for m in _LEM_TOK.finditer(s):
        t = m.group(0)
        if t == '<b>':
            if seen:
                nxt = re.match(r'((?:(?!</?b>).)*)', s[m.end():], re.S).group(1)
                if not _talmud_text(nxt):
                    end = m.start()
                    break
            bold = True
        elif t == '</b>':
            bold = False
        elif t in ('<br>', '<small>['):
            end = m.start()
            break
        elif not t.startswith('<'):
            h = _HEB.search(t)
            if h and not bold:
                end = m.start() + h.start()
                break
            seen = seen or bool(h)
    # Ueberzaehliges </b> kurz hinter dem Lauf: Lemma bis dorthin verlaengern.
    rest = s[end:]
    stop = min([i for i in (rest.find('<br>'), rest.find('<small>[')) if i >= 0] or [len(rest)])
    head = rest[:stop]
    first = re.search(r'</?b>', head)
    # Nur wenn das erste Tag danach selbst das ueberzaehlige </b> ist.
    gap = head[:first.start()] if first else ''
    if (first and first.group(0) == '</b>'
            and (_talmud_text(gap) or _ETC.fullmatch(strip_tags(gap)))
            and len(strip_tags(gap).split()) <= STRAY_MAX_WORDS):
        end += first.end()
    return s[:end], s[end:]

BOOKS = set("""בראשית שמות ויקרא במדבר דברים יהושע שופטים שמואל מלכים ישעיה ישעיהו
ירמיה ירמיהו יחזקאל הושע יואל עמוס עובדיה יונה מיכה נחום חבקוק צפניה חגי זכריה מלאכי
תהלים תהילים משלי איוב רות איכה קהלת אסתר דניאל עזרא נחמיה""".split())


def strip_tags(s):
    s = drop_small_brackets(s)
    s = re.sub(r'</?b>', '', s)
    # Schriftverweise <small>(...)</small> im Lemma: Klammertext bleibt, Tags
    # nicht. Sonst stuende maskiertes &lt;small&gt; im <lemma> der Banddatei.
    s = re.sub(r'</?small>', '', s)
    s = s.replace('<br>', ' ')
    return re.sub(r'\s+', ' ', s).strip()


def find_abbrs(text):
    """
    Erkennt echte hebraeische Abkuerzungstoken und merkt sich den Kontext.

    Wichtig: Ein blosses oeffnendes/schliessendes Anfuehrungszeichen ist keine
    Abkuerzung. Deshalb verlangt ABBR_TOK jetzt hebraeische Buchstaben auf
    beiden Seiten der Gershajim. Das verhindert Fehlklassifikationen wie
    ``"כי`` oder ``משה"``.

    Steht unmittelbar nach dem Kuerzel eine Senlake-Erklaerung
    ``<small>[...]</small>``, wird sie am konkreten Treffer gespeichert. Diese
    quelleneigene Erklaerung hat in Schritt 3 Vorrang vor Heuristiken.
    """
    seen, out = {}, []
    for m in ABBR_TOK.finditer(text or ''):
        t = m.group(0).strip('.:,;')
        if len(re.sub(r'[^א-ת]', '', t)) < 2:
            continue
        tail = (text or '')[m.end():]
        sm = re.match(r'\s*' + SMALL_BRACKET, tail)
        inline = (re.sub(r'<[^>]+>', '', sm.group(1)).strip() or None) if sm else None
        a = max(0, m.start() - 120)
        b = min(len(text or ''), m.end() + 120)
        context = strip_tags((text or '')[a:b])
        if t in seen:
            rec = seen[t]
            if inline and not rec.get('inline_expansion'):
                rec['inline_expansion'] = inline
            continue
        rec = {
            'abbr': t,
            'expansion': None,
            'inline_expansion': inline,
            'context': context,
        }
        seen[t] = rec
        out.append(rec)
    return out


def find_scripture(text):
    refs = []
    for inner in SCRIPT_RE.findall(text):
        parts = inner.strip().split()
        if parts and parts[0].strip('.:,;') in BOOKS:
            refs.append('(' + inner.strip() + ')')
    return refs


def parse(path, tractate, edition=''):
    raw = open(path, encoding='utf-8').read()
    lines = raw.split('\n')

    # von der Ausgabe mitgelieferte Erklaerungen einsammeln (nur Statistik;
    # die massgebliche Aufloesung macht Schritt 3 ueber glossary_he.json)
    inline_expl, gematria = 0, 0
    for m in PAIR_RE.finditer(raw):
        expa = m.group(2)
        if expa.strip().isdigit():
            gematria += 1
        else:
            inline_expl += 1

    try:
        first = next(i for i, l in enumerate(lines) if DAF_RE.match(l))
    except StopIteration:
        raise SystemExit('Keine "Daf X"-Marken gefunden — Dateiformat pruefen.')
    front = [l for l in lines[:first] if l.strip()]
    preface = '\n'.join(front[5:]) if len(front) > 5 else ''

    entries, cur, seq = [], None, 0
    for l in lines[first:]:
        m = DAF_RE.match(l)
        if m:
            cur, seq = m.group(1), 0
            continue
        if not l.strip() or cur is None:
            continue
        seq += 1
        para = l.strip()
        lem_html, body = split_lemma(para)
        lemma = strip_tags(lem_html) if lem_html is not None else None
        if lemma:
            # Fuehrende Satzzeichen sind Satzreste der Ausgabe ("<b> .</b> <b>...").
            lemma = re.sub(r'^[.,:;\s]+', '', lemma) or None
        body = body.strip()
        combined = (lemma or '') + ' ' + body
        entries.append({
            'id': '{}.{}.{}'.format(tractate.lower(), cur, seq),
            'daf': cur, 'seq': seq,
            'lemma_he': lemma,
            'commentary_html': body,
            'commentary_plain': strip_tags(body),
            'has_subnotes': '<br>' in body,
            'abbreviations': find_abbrs(combined),
            'scripture_refs': find_scripture(combined),
            'sefaria_ref': None,
            'commentary_en': None,
        })

    dafim = sorted({e['daf'] for e in entries},
                   key=lambda d: (int(re.sub(r'\D', '', d) or 0), d[-1]))
    return {
        'meta': {
            'work': 'Ben Yehoyada', 'tractate': tractate,
            'source_file': os.path.basename(path), 'source_edition': edition,
            'counts': {
                'dafim': len(dafim), 'entries': len(entries),
                'entries_with_lemma': sum(1 for e in entries if e['lemma_he']),
                'entries_freeform': sum(1 for e in entries if not e['lemma_he']),
                'inline_explanations': inline_expl, 'gematria_annotations': gematria,
            },
            'daf_range': '{} - {}'.format(dafim[0], dafim[-1]) if dafim else '',
        },
        'preface_he': preface,
        'entries': entries,
    }


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--in', dest='src', required=True)
    ap.add_argument('--tractate', required=True)
    ap.add_argument('--edition', default='Senlake 2019, based on Jerusalem 1897')
    ap.add_argument('--out', dest='dst', required=True)
    a = ap.parse_args()
    doc = parse(a.src, a.tractate, a.edition)
    os.makedirs(os.path.dirname(a.dst) or '.', exist_ok=True)
    json.dump(doc, open(a.dst, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    c = doc['meta']['counts']
    print('== PARSEN ==')
    for k, v in c.items():
        print('{:22s}: {}'.format(k, v))
    print('{:22s}: {}'.format('daf_range', doc['meta']['daf_range']))
    print('->', a.dst)
