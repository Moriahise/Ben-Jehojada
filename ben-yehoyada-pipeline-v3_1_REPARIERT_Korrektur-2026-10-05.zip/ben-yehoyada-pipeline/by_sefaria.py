# -*- coding: utf-8 -*-
"""
Schritt 2 — Sefaria-Mapping.

Ordnet jedem Eintrag die Talmud-Grundstelle zu, indem das Lemma
(Dibbur ha-Matchil) gegen die Segmente des jeweiligen Daf abgeglichen wird.
Gefuellt werden:  sefaria_ref, talmud.he, talmud.en, talmud.match

ZWEI QUELLEN — die erste, die verfuegbar ist, wird benutzt:

  A) LOKAL (empfohlen, offline, schnell)
     --sefaria-dir PFAD
     Erwartet die Sefaria-Export-Struktur, z.B.
       .../json/Talmud/Bavli/Seder Zeraim/Berakhot/Hebrew/merged.json
       .../json/Talmud/Bavli/Seder Zeraim/Berakhot/English/merged.json
     oder direkt zwei Dateien via --he-file / --en-file.

  B) API
     --api          holt https://www.sefaria.org/api/v3/texts/<Traktat>.<Daf>
     Achtung: in abgeschotteten Umgebungen oft durch Egress-Policy blockiert.

SELBSTTEST (ohne Netz, ohne Daten):
     python3 by_sefaria.py --selftest
"""
import json, re, os, sys, time, unicodedata, argparse, difflib

# Zuordnung und Ausschnitt des Kopfbands liegen seit der Korrektur vom
# 2026-09-23 in by_band. Siehe dort die Begruendung; hier bleibt nur das
# Einlesen der Quellen, die Blattadressierung und der Lauf ueber die Eintraege.
import by_band as BB

NIKUD = re.compile(r'[֑-ׇ]')
TAGS = re.compile(r'<[^>]+>')
NONHEB = re.compile(r'[^א-ת ]')


# ---------------------------------------------------------------- Normalisierung
PAREN = re.compile(r'\([^)]*\)')


def norm_he(s):
    """Vergleichsform: ohne Nikud, ohne Tags, ohne Satzzeichen, einfache Spatien."""
    s = unicodedata.normalize('NFC', s or '')
    s = TAGS.sub(' ', s)
    # Eingeklammerte Schriftverweise gehoeren zum Kommentar, nicht zum Zitat.
    # Bleiben sie stehen, zerlegen sie das Lemma und der Treffer geht verloren.
    s = PAREN.sub(' ', s)
    s = NIKUD.sub('', s)
    s = NONHEB.sub(' ', s)
    return re.sub(r'\s+', ' ', s).strip()


def skeleton(s):
    """
    Zweite Vergleichsstufe: zusaetzlich die Lesemuetter waw/jod entfernen.
    Grund: der Ben Jehojada zitiert oft defektiv (גְּאֻלָּה), waehrend der
    Talmudtext plene schreibt (גאולה). Ohne diese Stufe scheitert ein
    sonst wortwoertlicher Treffer an einem einzigen Buchstaben.
    """
    return re.sub(r'\s+', ' ', re.sub(r'[וי]', '', norm_he(s))).strip()


def words(s, n=None):
    w = norm_he(s).split()
    return w[:n] if n else w


# ---------------------------------------------------------------- Daf <-> Index
def daf_to_index(daf, offset):
    """'4b' -> laufender Segment-Index im Sefaria-Array."""
    m = re.match(r'^(\d+)([ab])$', daf.strip())
    if not m:
        return None
    num, side = int(m.group(1)), m.group(2)
    return (num - offset) * 2 + (0 if side == 'a' else 1)


def detect_offset(arr):
    """Sefaria-Talmudarrays beginnen je nach Export bei 1a oder 2a."""
    lead = 0
    for x in arr:
        if isinstance(x, list) and len(x) == 0:
            lead += 1
        else:
            break
    return 1 if lead >= 2 else 2


# ---------------------------------------------------------------- Quellen
def load_local(he_file, en_file):
    def rd(p):
        if not p or not os.path.exists(p):
            return None
        if p.lower().endswith('.txt'):
            return load_sefaria_txt(p)
        d = json.load(open(p, encoding='utf-8'))
        return d.get('text', d) if isinstance(d, dict) else d
    return rd(he_file), rd(en_file)


HEB_VAL = {'א':1,'ב':2,'ג':3,'ד':4,'ה':5,'ו':6,'ז':7,'ח':8,'ט':9,
           'י':10,'כ':20,'ל':30,'מ':40,'נ':50,'ס':60,'ע':70,'פ':80,'צ':90,
           'ק':100,'ר':200,'ש':300,'ת':400,
           'ך':20,'ם':40,'ן':50,'ף':80,'ץ':90}
DICTA_DAF = re.compile(r'^\s*\*{2,}\s*דף\s+([א-ת"״’\']+?)\s*([.:])\s*\*{2,}\s*$')
# Strukturmarken der Dicta-Ausgabe, die keine Textsegmente sind
DICTA_SKIP = {"גמ'", 'גמ׳', "מתני'", 'מתני׳', 'הדרן', 'מתניתין', 'גמרא'}


def heb_to_int(s):
    """'ב' -> 2, 'ל"ב' -> 32, 'ט"ו' -> 15."""
    letters = [c for c in s if c in HEB_VAL]
    return sum(HEB_VAL[c] for c in letters) if letters else None


def load_dicta_txt(path):
    """
    Liest die Dicta-Ausgabe 'Talmud Bavli with Nikud'.
    Blattmarken dort:  *** דף ב. ***   (Punkt = Amud alef, Doppelpunkt = bet)
    Danach ein Segment je nicht leerer Zeile.
    """
    out, cur = {}, None
    for line in open(path, encoding='utf-8'):
        line = line.rstrip('\n').rstrip('\r')
        m = DICTA_DAF.match(line)
        if m:
            n = heb_to_int(m.group(1))
            if n is None:
                continue
            cur = '{}{}'.format(n, 'a' if m.group(2) == '.' else 'b')
            out.setdefault(cur, [])
            continue
        t = line.strip()
        if cur is None or not t or t in DICTA_SKIP:
            continue
        out[cur].append(t)
    return out


def load_sefaria_txt(path):
    """
    Liest einen Textexport und erkennt das Format selbst:
      * Sefaria-Export  -> Zeile 'Daf 4b'
      * Dicta-Ausgabe   -> Zeile ' *** דף ד: *** '
    Rueckgabe in beiden Faellen: {'4b': [seg, seg, ...], ...}
    """
    head = open(path, encoding='utf-8').read(4000)
    if DICTA_DAF.search(head) or '*** דף' in head:
        return load_dicta_txt(path)

    out, cur = {}, None
    for line in open(path, encoding='utf-8'):
        line = line.rstrip('\n').rstrip('\r')
        m = re.match(r'^Daf\s+(\S+)\s*$', line)
        if m:
            cur = m.group(1)
            out.setdefault(cur, [])
            continue
        if cur is None or not line.strip():
            continue
        out[cur].append(line.strip())
    return out


def find_merged(sefaria_dir, tractate):
    """Sucht merged.json fuer Hebrew/English unter einem Sefaria-Export-Baum."""
    he = en = None
    for root, _dirs, files in os.walk(sefaria_dir):
        if 'merged.json' not in files:
            continue
        parts = root.replace('\\', '/').split('/')
        if tractate not in parts:
            continue
        if 'Hebrew' in parts:
            he = os.path.join(root, 'merged.json')
        elif 'English' in parts:
            en = os.path.join(root, 'merged.json')
    return he, en


def fetch_api(tractate, daf, lang, session_cache={}):
    import urllib.request
    key = (tractate, daf, lang)
    if key in session_cache:
        return session_cache[key]
    url = 'https://www.sefaria.org/api/v3/texts/{}.{}?version={}'.format(tractate, daf, lang)
    try:
        with urllib.request.urlopen(url, timeout=25) as r:
            d = json.loads(r.read().decode('utf-8'))
        segs = []
        for v in d.get('versions', []):
            t = v.get('text')
            if isinstance(t, list):
                segs = t
                break
        session_cache[key] = segs
        time.sleep(0.3)                     # hoeflich bleiben
        return segs
    except Exception as e:
        print('   ! API {} {}: {}'.format(tractate, daf, e), file=sys.stderr)
        session_cache[key] = []
        return []


# ---------------------------------------------------------------- Matching
def match_lemma(lemma, segments, min_score=0.55):
    """
    Gibt (segment_index, methode, score) zurueck oder (None, 'none', 0).

    ACHTUNG — diese Funktion wurde am 2026-09-23 ersetzt. Die alte Fassung
    arbeitete in Stufen (contains / skeleton / headwords / fuzzy) und nahm in
    jeder Stufe das ERSTE Segment, das die Bedingung erfuellte. Das war der
    Grund fuer die Fehlzuordnungen in Band 01: bei zwei Gebeten auf Berachot
    16b, die beide mit "יהי רצון מלפניך ה'" beginnen, gewann das erste,
    obwohl das Lemma das zweite meint. Jetzt wird jedes Segment auf die
    Deckung des VOLLSTAENDIGEN Lemmas gemessen und das beste gewaehlt —
    siehe by_band.best_segment.

    `min_score` bleibt aus Vertraeglichkeitsgruenden erhalten; die Schwelle
    ist jetzt by_band.COV_MIN.
    """
    if not segments:
        return None, 'none', 0.0
    idx, sc, a, b, cov = BB.best_segment(lemma, segments)
    if idx is None or cov < BB.COV_MIN:
        return None, 'none', round(cov, 3)
    return idx, BB.method_of(lemma, segments[idx], cov), round(cov, 3)


def neighbour_dafim(daf):
    """Das vorige und das folgende Blatt, in dieser Reihenfolge."""
    m = re.match(r'^(\d+)([ab])$', daf.strip())
    if not m:
        return []
    n, side = int(m.group(1)), m.group(2)
    nxt = '{}{}'.format(n, 'b') if side == 'a' else '{}{}'.format(n + 1, 'a')
    prv = '{}{}'.format(n - 1, 'b') if side == 'a' else '{}{}'.format(n, 'a')
    return [nxt, prv]


def neighbour_segments(daf, he_arr, en_arr, use_api, tractate):
    if isinstance(he_arr, dict):
        return (he_arr.get(daf, []),
                en_arr.get(daf, []) if isinstance(en_arr, dict) else [])
    if isinstance(he_arr, list):
        off = detect_offset(he_arr)
        i = daf_to_index(daf, off)
        h = he_arr[i] if (i is not None and 0 <= i < len(he_arr)) else []
        e = en_arr[i] if (en_arr and i is not None and 0 <= i < len(en_arr)) else []
        return (h, e)
    if use_api:
        return (fetch_api(tractate, daf, 'hebrew'), fetch_api(tractate, daf, 'english'))
    return ([], [])


def trim_band(segment, lemma, max_words=42, lead=6):
    """
    Kuerzt ein Talmudsegment auf ein Fenster um das Lemma.

    ACHTUNG — auch diese Funktion wurde am 2026-09-23 ersetzt. Die alte
    Fassung ankerte auf den ersten drei Lemma-Woertern und nahm deren ERSTES
    Vorkommen; kam die Wendung im Segment zweimal vor, schnitt sie an der
    falschen Stelle (Berachot 20a:4). Fanden sich die drei Woerter gar nicht
    — etwa bei einer aramaeischen Paraphrase —, lieferte sie stillschweigend
    die ersten 42 Woerter des Segments. Und sie brach das Zitat hart bei
    max_words ab, auch mitten im Satz.

    Jetzt richtet by_band.cut_band das vollstaendige Lemma aus, ankert an der
    besten Uebereinstimmung und laesst das Fenster ueber max_words hinaus
    wachsen, bis die zitierte Passage vollstaendig darin steht.
    """
    band, _info = BB.cut_band(segment, lemma, max_words=max_words, lead=lead)
    return band


# ---------------------------------------------------------------- Hauptlauf
OVERRIDE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             'band_overrides.json')


def load_overrides(path=None):
    """
    Handentscheidungen des Lektorats zur Kopfband-Zuordnung.

    Sie werden bei JEDEM Lauf gelesen und gehen der Automatik vor. Ohne diese
    Tabelle waere eine Korrektur in der TXT-Datei beim naechsten Lauf wieder
    ueberschrieben — der eigentliche Grund, warum die sieben Fehlstellen in
    Band 01 zweimal auftauchen konnten.

    Schluessel ist die Eintrags-ID aus Schritt 1 (z.B. berakhot.14a.3).
    """
    path = path or OVERRIDE_FILE
    if not os.path.exists(path):
        return {}
    d = json.load(open(path, encoding='utf-8'))
    raw = d.get('overrides', d)
    out = {}
    for key, v in raw.items():
        if key.startswith('_') or not isinstance(v, dict):
            continue
        if v.get('entry_id'):
            out[v['entry_id']] = v
        out[key] = v
    return out


def run(doc, he_arr=None, en_arr=None, use_api=False, tractate='Berakhot',
        limit_daf=None, band_words=0, overrides=None):
    overrides = load_overrides() if overrides is None else overrides
    stats = {'total': 0, 'matched': 0, 'by_method': {}, 'no_source': 0,
             # 'band_missing' = das Kopfband traegt die Stelle NICHT (Befund),
             # 'band_wording' = Wortlaut des Kommentars weicht ab (ansehen).
             'band_missing': 0, 'band_missing_ids': [],
             'band_wording': 0, 'band_wording_ids': []}
    off_he = detect_offset(he_arr) if isinstance(he_arr, list) else 2
    off_en = detect_offset(en_arr) if isinstance(en_arr, list) else off_he

    cache = {}
    for e in doc['entries']:
        if limit_daf and e['daf'] not in limit_daf:
            continue
        stats['total'] += 1
        if not e.get('lemma_he'):
            continue
        daf = e['daf']

        if daf not in cache:
            if isinstance(he_arr, dict):
                # Textexport: direkt nach Daf-Nummer adressiert, keine Indexrechnung
                segs_he = he_arr.get(daf, [])
                segs_en = en_arr.get(daf, []) if isinstance(en_arr, dict) else []
            elif he_arr is not None:
                i = daf_to_index(daf, off_he)
                segs_he = he_arr[i] if (i is not None and 0 <= i < len(he_arr)) else []
                j = daf_to_index(daf, off_en)
                segs_en = en_arr[j] if (en_arr and j is not None and 0 <= j < len(en_arr)) else []
            elif use_api:
                segs_he = fetch_api(tractate, daf, 'hebrew')
                segs_en = fetch_api(tractate, daf, 'english')
            else:
                segs_he, segs_en = [], []
            cache[daf] = (segs_he, segs_en)
        segs_he, segs_en = cache[daf]

        if not segs_he:
            stats['no_source'] += 1
            continue

        # Handentscheidung des Lektorats? Sie geht allem anderen vor und
        # ueberlebt damit jede Neuerzeugung.
        ov = overrides.get(e.get('id'))
        if ov:
            nsegs = neighbour_segments(ov['daf'], he_arr, en_arr, use_api, tractate)
            if nsegs[0] and ov['seg'] - 1 < len(nsegs[0]):
                segs_he, segs_en, hit_daf = nsegs[0], nsegs[1], ov['daf']
                idx, method, score = ov['seg'] - 1, 'override', 1.0
            else:
                ov = None
        if not ov:
            # Die Blattangabe des Ben Jehojada ist starke Evidenz: sitzt das
            # Lemma dort sicher, werden die Nachbarblaetter nicht befragt.
            # Sonst muessen sie das eigene Blatt deutlich uebertreffen —
            # sonst gewinnt eine spaetere Gemara-Zitierung gegen die Mischna.
            pages = [(daf, segs_he)]
            for nb in neighbour_dafim(daf):
                pages.append((nb, neighbour_segments(nb, he_arr, en_arr,
                                                     use_api, tractate)[0]))
            hit_daf, idx, cov, moved = BB.choose_place(e['lemma_he'], pages)
            # Nicht die Deckung allein entscheidet, sondern ob wenigstens eine
            # zusammenhaengende Wortfolge uebereinstimmt — siehe BB.acceptable.
            ok_seg = False
            if idx is not None:
                segs_chk = (segs_he if hit_daf == daf
                            else neighbour_segments(hit_daf, he_arr, en_arr,
                                                    use_api, tractate)[0])
                if idx < len(segs_chk):
                    ok_seg = BB.acceptable(e['lemma_he'], segs_chk[idx], cov)
            if idx is None or not ok_seg:
                e.setdefault('talmud', {})['match'] = {
                    'method': 'none', 'score': round(cov or 0.0, 3)}
                continue
            if hit_daf != daf:
                segs_he, segs_en = neighbour_segments(hit_daf, he_arr, en_arr,
                                                      use_api, tractate)
            method = BB.method_of(e['lemma_he'], segs_he[idx], cov)
            if moved:
                method += '+nachbar'
            score = round(cov, 3)

        he_txt = TAGS.sub('', segs_he[idx]).strip()
        en_txt = TAGS.sub('', segs_en[idx]).strip() if idx < len(segs_en) else None
        band_info = {}
        if band_words:
            he_txt, band_info = BB.cut_band(he_txt, e['lemma_he'], max_words=band_words)
            if en_txt:
                en_txt, _ = BB.cut_band(en_txt, e['lemma_he'],
                                        max_words=int(band_words * 1.6))
        # Die Abnahmeprüfung, die frueher fehlte: traegt das Kopfband die
        # zitierte Stelle wirklich? Das Ergebnis steht im Bericht.
        band_ok, band_cov = BB.band_contains_lemma(he_txt, e['lemma_he'])
        e['sefaria_ref'] = '{} {}:{}'.format(tractate, hit_daf, idx + 1)
        e['talmud'] = {'he': he_txt, 'en': en_txt,
                       'match': {'method': method, 'score': score,
                                 'band_coverage': band_cov,
                                 'band_ok': bool(band_ok),
                                 'band_words': band_info.get('words'),
                                 'band_extended': band_info.get('extended', False)}}
        stats['matched'] += 1
        stats['by_method'][method] = stats['by_method'].get(method, 0) + 1
        if not band_ok:
            key = 'band_missing' if band_cov < BB.COV_MIN else 'band_wording'
            stats[key] += 1
            stats[key + '_ids'].append(e.get('id'))

    stats['percent'] = round(100.0 * stats['matched'] / stats['total'], 1) if stats['total'] else 0
    doc.setdefault('meta', {})['sefaria_mapping'] = stats
    return stats


# ---------------------------------------------------------------- Selbsttest
def selftest():
    """
    Prueft die Matching-Mechanik ohne Netz. Das Fixture baut Segmente, die das
    Lemma verbatim enthalten (so steht es auch im echten Talmud, denn das
    Dibbur ha-Matchil IST ein Talmudzitat) — einmal glatt, einmal mit Nikud,
    Tags und Zusatzwoertern, einmal nur als Wortanfang.
    """
    lemma = 'אֵיזֶהוּ בֶּן עוֹלָם הַבָּא? זֶה הַסּוֹמֵךְ גְּאֻלָּה לִתְפִלָּה שֶׁל עַרְבִית.'
    segs = [
        'מאי טעמא דרבי יוחנן',
        '<b>אמר רבי יוחנן</b> איזהו בן עולם הבא זה הסומך גאולה לתפלה של ערבית',
        'רבי יהושע בן לוי אומר תפלות באמצע תקנום',
    ]
    i, m, s = match_lemma(lemma, segs)
    ok1 = (i == 1)
    print('  [1] verbatim + Tags + Nikud  -> Segment {}, {}, {}  {}'.format(i, m, s, 'OK' if ok1 else 'FEHLER'))

    segs2 = ['בענין אחר לגמרי', 'איזהו בן עולם הבא זה הסומך גאולה לתפלה אשר של ערבית ממש']
    i2, m2, s2 = match_lemma(lemma, segs2)
    ok2 = (i2 == 1)
    print('  [2] eingeschobenes Wort      -> Segment {}, {}, {}  {}'.format(i2, m2, s2, 'OK' if ok2 else 'FEHLER'))

    i3, m3, s3 = match_lemma(lemma, ['דבר אחר לגמרי', 'ותו לא מידי'])
    ok3 = (i3 is None)
    print('  [3] kein Treffer erwartet    -> {}, {}, {}  {}'.format(i3, m3, s3, 'OK' if ok3 else 'FEHLER'))

    ok4 = daf_to_index('2a', 2) == 0 and daf_to_index('4b', 2) == 5 and daf_to_index('64a', 2) == 124
    print('  [4] Daf->Index (2a,4b,64a)   -> {}, {}, {}  {}'.format(
        daf_to_index('2a', 2), daf_to_index('4b', 2), daf_to_index('64a', 2), 'OK' if ok4 else 'FEHLER'))

    allok = ok1 and ok2 and ok3 and ok4
    print('\n  SELBSTTEST:', 'BESTANDEN' if allok else 'FEHLGESCHLAGEN')
    return 0 if allok else 1


# ---------------------------------------------------------------- CLI
if __name__ == '__main__':
    ap = argparse.ArgumentParser(description='Sefaria-Mapping fuer Ben Jehojada')
    ap.add_argument('--in', dest='src', default='out/berakhot.glossed.json')
    ap.add_argument('--out', dest='dst', default='out/berakhot.mapped.json')
    ap.add_argument('--tractate', default='Berakhot')
    ap.add_argument('--sefaria-dir', help='Wurzel eines Sefaria-Export-Baums')
    ap.add_argument('--he-file'); ap.add_argument('--en-file')
    ap.add_argument('--api', action='store_true', help='ueber die Sefaria-API holen')
    ap.add_argument('--daf', help='nur diese Dafim, kommagetrennt (z.B. 4b,5a)')
    ap.add_argument('--band-words', type=int, default=0,
                    help='Kopfband auf N Woerter um das Lemma kuerzen (0 = ungekuerzt)')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()

    if a.selftest:
        print('== SELBSTTEST Matching-Logik ==')
        sys.exit(selftest())

    he_arr = en_arr = None
    if a.sefaria_dir:
        hf, ef = find_merged(a.sefaria_dir, a.tractate)
        print('gefunden: he={} en={}'.format(hf, ef))
        he_arr, en_arr = load_local(hf, ef)
    elif a.he_file:
        he_arr, en_arr = load_local(a.he_file, a.en_file)

    if he_arr is None and not a.api:
        print('Keine Quelle angegeben. --sefaria-dir, --he-file oder --api benutzen.', file=sys.stderr)
        print('Zum Pruefen der Logik ohne Daten: python3 by_sefaria.py --selftest', file=sys.stderr)
        sys.exit(2)

    doc = json.load(open(a.src, encoding='utf-8'))
    limit = set(a.daf.split(',')) if a.daf else None
    st = run(doc, he_arr, en_arr, use_api=a.api, tractate=a.tractate, limit_daf=limit,
             band_words=a.band_words)
    os.makedirs(os.path.dirname(a.dst) or '.', exist_ok=True)
    json.dump(doc, open(a.dst, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('== SEFARIA-MAPPING ==')
    print('geprueft :', st['total'])
    print('zugeordnet: {} ({}%)'.format(st['matched'], st['percent']))
    print('Methoden :', st['by_method'])
    if st['no_source']:
        print('ohne Quelltext:', st['no_source'])
    print('->', a.dst)
