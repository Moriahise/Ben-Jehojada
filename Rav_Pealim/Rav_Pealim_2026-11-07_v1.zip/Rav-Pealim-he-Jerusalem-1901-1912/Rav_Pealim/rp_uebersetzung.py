# -*- coding: utf-8 -*-
"""
Uebersetzung · Speicher, Arbeitslisten, Translation_Batch-Dateien und EN_FERTIG-Baende
(nach dem Muster von lc_uebersetzung.py).

Die englische Uebersetzung steht versioniert in uebersetzung/<reihe>/*.txt (sy, oc, yd, eh,
cm), je Zeile ein Eintrag, geschluesselt nach Sefaria-Ref (stabil, unabhaengig von IDs und
Bandgrenzen):

    @Volume I, Sod Yesharim 1:2 = <b>Question.</b> I was asked …        <en> des Absatzes
    !Volume I, Sod Yesharim 1:2 = Pruefhinweis …                         Unsicherheit (Pruefbericht)
    %Volume I, Sod Yesharim 1:2 = Bewertung …                            PRUEFEN-Zeile des Validators gesehen
    ## Kommentarzeile                                                    wird ignoriert

Die Titel (<en_title>) setzt die Pipeline (Titel der Ausgabe); sie werden nicht uebersetzt.
Der Master (out/band/…_BILINGUAL.txt) bleibt unveraendert; gebaut werden nur fuer Baende
mit Uebersetzung:
    out/band/Rav_Pealim_Band_XX_BILINGUAL_EN_FERTIG.txt   (alles uebersetzt)
    out/band/Rav_Pealim_Band_XX_BILINGUAL_EN_STAND.txt    (Zwischenstand)
    out/batches/Translation_Batch_XX_RPL-…_bis_RPL-…_EN_FERTIG.txt   (erste Portion, wenn vollstaendig)
    out/uebersetzung/Rav_Pealim_Uebersetzung_Pruefbericht.md

    python3 rp_uebersetzung.py liste --band 1 --zeichen 20000      naechste offene Absaetze (ohne Nikud)
    python3 rp_uebersetzung.py stand
    python3 rp_uebersetzung.py bauen
"""
import argparse
import collections
import re
import sys
from pathlib import Path

import rp_bandplan as B
import rp_common as C

sys.path.insert(0, str(C.HERE / 'indesign'))
UEB = C.HERE / 'uebersetzung'
ZEILE_RE = re.compile(r'^([@!%])(Volume (?:IV|III|II|I), [A-Za-z ]+? \d+(?::\d+)?) = (.*)$')
UNSICHER_RE = re.compile(r'unsicher|unklar|nicht (?:sicher|gesichert|aufzul|nachvollziehbar|gefunden)|vermutet|'
                         r'Abweichung|fehlt in der Quelle|möglich|offen', re.I)


# --- Speicher -------------------------------------------------------------------------
def lade_speicher(ordner=None):
    """{'seg': {ref: en}, 'hinweise': {ref: [..]}, 'gesehen': {ref: [..]}, 'quelle': {ref: datei:zeile}}"""
    out = {'seg': {}, 'hinweise': collections.defaultdict(list), 'gesehen': collections.defaultdict(list), 'quelle': {}}
    basis = Path(ordner or UEB)
    for f in sorted(basis.glob('*/*.txt')):
        for nr, zeile in enumerate(f.read_text(encoding='utf-8').splitlines(), start=1):
            z = zeile.rstrip()
            if not z or z.startswith('##'):
                continue
            m = ZEILE_RE.match(z)
            if not m:
                raise SystemExit('{}/{}:{}: Zeile nicht lesbar: {}'.format(f.parent.name, f.name, nr, z[:80]))
            art, ref, text = m.group(1), m.group(2), m.group(3).strip()
            if art in '!%':
                out['hinweise' if art == '!' else 'gesehen'][ref].append(text)
                continue
            if ref in out['seg'] and out['seg'][ref] != text:
                raise SystemExit('{}:{}: {} doppelt mit anderem Text ({})'.format(f.name, nr, ref, out['quelle'][ref]))
            out['seg'][ref] = text
            out['quelle'][ref] = '{}/{}:{}'.format(f.parent.name, f.name, nr)
    return out


def segmentfolge(plan=None):
    """Segmente aller Baende wie in den Mastern (IDs, n, Ref, Abschnitt, Band)."""
    werk, gl, secs, segs, vols = plan or B.plan()
    for v in vols:
        for s in v['segments']:
            s['band'] = v['number']
    return segs, vols


def kurz_he(html):
    """Arbeitsform fuer die Uebersetzung: ohne Nikud/Teamim, Tags b/small/i bleiben."""
    t = re.sub('[֑-ׇ]', '', html or '')
    return re.sub(r'\s+', ' ', t).strip()


def liste(band, zeichen=20000, ab=None, alle=False, mafteach=None, verweise=None):
    sp = lade_speicher()
    segs, _ = segmentfolge()
    out, n, letzter, gestartet = [], 0, None, ab is None
    for s in segs:
        if s['band'] != band:
            continue
        if not gestartet:
            gestartet = s['ref'] == ab
            if not gestartet:
                continue
        if not alle and s['ref'] in sp['seg']:
            continue
        if s['abschnitt'] != letzter:
            m = (mafteach or {}).get(s['quelle_ref'], {}).get('inhalt', '')
            out.append('### {} | {} | {}{}'.format(s['quelle_ref'], s['section_he'], s['section_en'],
                                                   ' | Mafteach: ' + m if m else ''))
            letzter = s['abschnitt']
        z = '@{} [{}] {}'.format(s['ref'], s['n'], kurz_he(s['he']))
        out.append(z)
        for q in [q for q in (verweise or {}).get(s['ref'], []) if q['status'] != 'OHNE_SIMAN']:
            out.append('##   Verweis: {} → {}'.format(q['angabe'][:40], '{} (Band {}, {})'.format(
                q['ziel_titel_en'], q['band'], q['status']) if q['band'] else q['status']))
        n += len(z)
        if n >= zeichen:
            break
    return '\n'.join(out)


def stand():
    sp = lade_speicher()
    segs, vols = segmentfolge()
    res = collections.OrderedDict()
    for v in vols:
        text = [s for s in segs if s['band'] == v['number']]
        fertig = [s for s in text if s['ref'] in sp['seg']]
        res[v['number']] = {'reihe': v['reihe'], 'segmente': len(text), 'uebersetzt': len(fertig),
                            'he_konsonanten': sum(s['plan_chars'] for s in text),
                            'he_konsonanten_uebersetzt': sum(s['plan_chars'] for s in fertig),
                            'naechster': next((s['ref'] for s in text if s['ref'] not in sp['seg']), None)}
    alle = {s['ref'] for s in segs}
    fremd = [r for r in sp['seg'] if r not in alle]
    return res, fremd


# --- Dateien bauen ----------------------------------------------------------------------
SEG_BLOCK = re.compile(r'(<segment id="([^"]+)" n="\d+">\r?\n<he>[\s\S]*?</he>\r?\n<en>)(<!\[CDATA\[[\s\S]*?\]\]>)(</en>)')


def fuelle_master(raw, segs_band, sp):
    """Leere <en> des Masters aus dem Speicher fuellen. -> (text, zaehler)"""
    by_id = {s['id']: s for s in segs_band}
    zaehler = {'seg': 0, 'offen': 0}

    def seg(m):
        s = by_id[m.group(2)]
        if re.sub(r'^<!\[CDATA\[|\]\]>$', '', m.group(3)).strip():
            return m.group(0)
        en = sp['seg'].get(s['ref'])
        if not en:
            zaehler['offen'] += 1
            return m.group(0)
        zaehler['seg'] += 1
        return m.group(1) + C.protect_cdata(en) + m.group(4)

    return SEG_BLOCK.sub(seg, raw), zaehler


def batch_bereiche(segs_band, max_seg=C.BATCH_MAX_SEGMENTS, max_chars=C.BATCH_MAX_CHARS):
    """takeNextBatchAtCursor() des Buchmanagers ueber den unuebersetzten Master."""
    out, cur, chars = [], [], 0
    for s in segs_band:
        c = s['plan_chars']
        if cur and (len(cur) >= max_seg or chars + c > max_chars):
            out.append(cur)
            cur, chars = [], 0
        cur.append(s)
        chars += c
    if cur:
        out.append(cur)
    return out


def batch_datei(volume, chosen, sp, ordner):
    """writeTranslationBatch() des Buchmanagers, Felder gefuellt (Rueckgabe als _EN_FERTIG)."""
    import erzeuge_rp_jsx as E
    out = ['<translation_batch project="{}" volume="{:02d}">'.format(C.PROJECT_ATTR, volume),
           '<!-- Nur leere <en_title>- und <en>-Felder füllen. IDs, n, <he_title>, <he> und alle Tags unverändert lassen. -->',
           '<!-- VERBINDLICHE UEBERSETZUNGSANWEISUNG: {} · Fassung {} -->'.format(E.ANWEISUNG, E.ANWEISUNG_FASSUNG)]
    last = None
    for s in chosen:
        if s['abschnitt'] != last:
            out += ['', '<section>', '<he_title>' + C.xml_escape(s['section_he']) + '</he_title>',
                    '<en_title>' + C.xml_escape(s['section_en']) + '</en_title>', '</section>']
            last = s['abschnitt']
        out += ['', '<segment id="{}" n="{}">'.format(s['id'], s['n']), '<he>' + C.protect_cdata(s['he']) + '</he>',
                '<en>' + C.protect_cdata(sp['seg'].get(s['ref'], '')) + '</en>', '</segment>']
    out += ['', '</translation_batch>']
    f = Path(ordner) / 'Translation_Batch_{:02d}_{}_bis_{}_EN_FERTIG.txt'.format(volume, chosen[0]['id'], chosen[-1]['id'])
    C.write_bic_text(f, '\r\n'.join(out))
    return f


def bauen(out='out', quiet=False, plan=None):
    import rp_validate as V
    sp = lade_speicher()
    segs, vols = segmentfolge(plan)
    o = Path(out)
    ergebnisse, dateien = [], []
    for v in vols:
        band = [s for s in segs if s['band'] == v['number']]
        stale = list((o / 'band').glob('{}_Band_{:02d}_BILINGUAL_EN_*.txt'.format(C.WERK_TAG, v['number'])))
        stale += list((o / 'batches').glob('Translation_Batch_{:02d}_*_EN_FERTIG.txt'.format(v['number'])))
        if not any(s['ref'] in sp['seg'] for s in band):
            for f in stale:
                f.unlink()
            continue
        master = B.band_datei(o, v['number'])
        if not master.exists():
            raise SystemExit('Master fehlt: {} (zuerst produzieren.py)'.format(master))
        raw = master.read_text(encoding='utf-8-sig')
        if re.findall(r'<segment id="([^"]+)"', raw) != [s['id'] for s in band]:
            raise SystemExit('{}: Segmentfolge passt nicht zur Pipeline – Master neu erzeugen'.format(master.name))
        text, z = fuelle_master(raw, band, sp)
        fertig = z['offen'] == 0
        ziel = o / 'band' / '{}_Band_{:02d}_BILINGUAL_{}.txt'.format(C.WERK_TAG, v['number'], 'EN_FERTIG' if fertig else 'EN_STAND')
        for f in stale:
            f.unlink()
        C.write_bic_text(ziel, text)
        r = V.pruefe(ziel, master, fertig)
        ergebnisse.append((v['number'], ziel, z, r, fertig))
        bereiche = batch_bereiche(band)
        if bereiche and all(s['ref'] in sp['seg'] for s in bereiche[0]):
            f = batch_datei(v['number'], bereiche[0], sp, o / 'batches')
            dateien.append((f, V.pruefe(f, master, True)))
    bericht(o, ergebnisse, dateien, sp, segs)
    if not quiet:
        for vol, ziel, z, r, fertig in ergebnisse:
            print('Band {:02d}: {} Segmente uebersetzt, {} offen · {} · FEHLER {} · PRUEFEN {}'.format(
                vol, z['seg'], z['offen'], ziel.name, len(r['fehler']), len(r['pruefen'])))
        if not ergebnisse:
            print('Noch keine Uebersetzung im Speicher (uebersetzung/<reihe>/*.txt).')
    return ergebnisse, dateien


def bericht(o, ergebnisse, dateien, sp, segs):
    import erzeuge_rp_jsx as E
    res, fremd = stand()
    ids = {s['ref']: s['id'] for s in segs}
    L = ['# Rav Pe’alim · Übersetzung · Prüfbericht', '',
         'Anweisung: `{}` · Speicher: `uebersetzung/<reihe>/*.txt`'.format(E.ANWEISUNG), '',
         '| Band | Reihe | Absätze | übersetzt | HE-Konsonanten übersetzt | nächster offener Absatz |',
         '|---|---|---:|---:|---:|---|']
    for nr, r in res.items():
        L.append('| {:02d} | {} | {} | {} | {:.1f} % | {} |'.format(
            nr, r['reihe'], r['segmente'], r['uebersetzt'],
            100.0 * r['he_konsonanten_uebersetzt'] / r['he_konsonanten'], r['naechster'] or '–'))
    L.append('')
    for vol, ziel, z, r, fertig in ergebnisse:
        L += ['## Band {:02d} · `{}`'.format(vol, ziel.name), '',
              '- rp_validate.py gegen den Master ({}): **{} FEHLER**, {} PRUEFEN'.format(
                  'EN_FERTIG-Modus' if fertig else 'Zwischenstand', len(r['fehler']), len(r['pruefen']))]
        L += ['  - FEHLER ' + x for x in r['fehler'][:50]]
        L += ['  - PRUEFEN ' + x for x in r['pruefen'][:200]]
        L.append('')
    for f, rb in dateien:
        L += ['## `{}`'.format(f.name), '', '- {} FEHLER, {} PRUEFEN'.format(len(rb['fehler']), len(rb['pruefen'])), '']
    if fremd:
        L += ['## Einträge ohne Absatz im Master', ''] + ['- ' + x for x in fremd] + ['']
    alle = [(ref, h) for ref, hs in sp['hinweise'].items() for h in hs]
    unsicher = [(ref, h) for ref, h in alle if UNSICHER_RE.search(h)]
    L += ['## Unsicherheiten einzeln (Segment-Ref, Segment-ID)', '']
    L += ['- `{}` ({}): {}'.format(ref, ids.get(ref, '?'), h) for ref, h in unsicher] or ['- keine']
    L += ['', '## Alle Prüffälle der Übersetzung (Segment-Ref, Segment-ID)', '']
    L += ['- `{}` ({}): {}'.format(ref, ids.get(ref, '?'), h) for ref, h in alle] or ['- keine']
    d = o / 'uebersetzung'
    d.mkdir(parents=True, exist_ok=True)
    (d / (C.WERK_TAG + '_Uebersetzung_Pruefbericht.md')).write_text('\n'.join(L) + '\n', encoding='utf-8')


def main(argv=None):
    ap = argparse.ArgumentParser(description='Rav Pe’alim – Uebersetzung')
    sub = ap.add_subparsers(dest='cmd', required=True)
    li = sub.add_parser('liste')
    li.add_argument('--band', type=int, required=True)
    li.add_argument('--zeichen', type=int, default=20000)
    li.add_argument('--ab')
    li.add_argument('--alle', action='store_true')
    sub.add_parser('stand')
    b = sub.add_parser('bauen')
    b.add_argument('--out', default=str(C.HERE / 'out'))
    a = ap.parse_args(argv)
    if a.cmd == 'liste':
        import rp_konkordanz as K
        k = K.run(str(C.HERE / 'out'), quiet=True)
        verweise = collections.defaultdict(list)
        for q in k['querverweise']:
            verweise[q['stelle']].append(q)
        import rp_struktur as ST
        werk = C.load_werk()
        maf, _ = ST.ordne_mafteach(werk, ST.lies_mafteach(werk))
        print(liste(a.band, a.zeichen, a.ab, a.alle, maf, verweise))
    elif a.cmd == 'stand':
        res, fremd = stand()
        for nr, r in res.items():
            print('Band {:02d} ({}): {}/{} Absaetze · {:.1f} % der Konsonanten · naechster {}'.format(
                nr, r['reihe'], r['uebersetzt'], r['segmente'],
                100.0 * r['he_konsonanten_uebersetzt'] / r['he_konsonanten'], r['naechster']))
        if fremd:
            print('ohne Absatz im Master:', fremd[:10])
    else:
        bauen(a.out)
    return 0


if __name__ == '__main__':
    sys.exit(main())
