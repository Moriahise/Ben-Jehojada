# Übersetzung Rav Pe’alim · feste Wiedergaben

Ergänzt die Übersetzungsanweisung 1.0; hält Entscheidungen fest, damit alle Reihen einheitlich bleiben.
Eintragsformat der Speicherdateien siehe `rp_uebersetzung.py` (`@Ref = Text`, `!Ref = Prüffall`, `%Ref = PRUEFEN gesehen`).
Speicher je Reihe: `sy/` (Sod Yesharim, Pilot), `oc/`, `yd/`, `eh/`, `cm/`; Dateinamen `<laufende Nummer>_si<von>-<bis>.txt`.

## Frage und Antwort
- שאלה → **Question.** · תשובה → **Response.** · עוד שאלה → **A further question.** (fettes Anfangswort bleibt fett)
- נשאלתי מ… → I was asked by … · ממ״א → from another place · מצורבא מרבנן → by a Torah scholar
- ושכמ״ה → and may your reward be doubled from Heaven · אכי״ר → Amen, so may it be His will
- מעכ״ת → His Honour (Anrede: your Honour) · הצעיר → the humble (author)

## Gottesnamen und Anrede (wie Leshon Chakhamim)
- יהוה / ה׳ / השם / השי״ת → HaShem; אלהים / אלקים / אלוק → G-d; הקב״ה → the Holy One, blessed be He
- Namen als Buchstabengegenstand (הוי״ה, אהי״ה, ע״ב, ס״ג, מ״ה, ב״ן, Milui) hebräisch sichtbar lassen und beschreiben
- Anrede an G-d: You, Your (groß)

## Stellenangaben
- סי׳ in Responsen → § (Responsa of the Rashba, Part 1, §617); im Schulchan Aruch → Kapitel (Shulchan Arukh, Orach Chayim 128:3)
- ס״ק → se'if katan (Magen Avraham 128:5) · דף ט׳ ע״א → folio 9a · ע״ג / ע״ד (vier Spalten je Blatt) → column c / d
- Rav Pe’alim selbst: „Rav Pe’alim, Part I, Orach Chayim §4“; Sod Yesharim mit Ausgabenzählung: „… Sod Yesharim §10 [Sod Yesharim, Siman 10 in this edition]“ (Regel 40)

## Personen, Werke, Ehrentitel
- Werke und Autoritäten nach `out/werke/Rav_Pealim_Werkverzeichnis.tsv` (Spalte werk_en)
- רבינו האר״י זלה״ה → our master the Arizal, of blessed memory · מהרח״ו → R. Chayim Vital · מוהרש״ש → the Rashash
- מרן → Maran (R. Yosef Karo) · מור״ם / רמ״א → the Rema
- ז״ל / זצ״ל / זלה״ה → of blessed memory · נר״ו → may the Merciful One protect and redeem him · הי״ו → may HaShem protect him and grant him life

## Kabbalistische Begriffe
- nach `glossar_kabbala.json` / `out/glossar/Rav_Pealim_Glossar_Kabbala.tsv` (Regel 30): Zeir Anpin, Nukva, Abba, Imma, mochin, zivvug, Sefirot (Keter, Chokhmah, Binah, Da'at, Chesed, Gevurah, Tiferet, Netzach, Hod, Yesod, Malkhut)
- ת״ת in Sod Yesharim = Tiferet; או״א = Abba ve-Imma; זו״ן = Zeir Anpin and Nukva

## Offene Festlegungen (nach den ersten Simanim des Pilotbands entscheiden)
- Wiedergabe von „בס״ד“ am Ende der Antworten (with the help of Heaven) und von „וה׳ יודע“
- Länge EN/HE messen (Planwert 2,375) und `rp_common.EN_EXPANSION` anpassen
