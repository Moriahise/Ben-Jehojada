#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Rav Pe'alim — Gesamtlauf bis zum Satzfreigabe-Master.

    1  Struktur + Mafteach-Abgleich                 rp_struktur.py
    2  Bandplan + Banddateien (BIC-Format)          rp_bandplan.py
    3  Konkordanz Druck ↔ Ausgabe, Querverweise     rp_konkordanz.py
    4  Glossar (BY + RP-Halacha + Kabbala + LC)     rp_glossar.py
    5  Werkverzeichnis der Zitatketten              rp_werke.py
    6  Abnahmepruefung der Banddateien              rp_validate.py
    7  Uebersetzung → EN_STAND/EN_FERTIG + Bericht  rp_uebersetzung.py (Speicher uebersetzung/)
    8  InDesign-Skripte reproduzierbar?             indesign/erzeuge_rp_jsx.py
    9  Satzfreigabe-Bericht, Quellenmanifest, Impressum/Lizenz

    python3 produzieren.py
"""
import argparse
import datetime
import subprocess
import sys
import tempfile
from pathlib import Path

import rp_bandplan as B
import rp_common as C
import rp_glossar as G
import rp_konkordanz as K
import rp_struktur as ST
import rp_uebersetzung as U
import rp_validate as V
import rp_werke as W

sys.path.insert(0, str(C.HERE / 'indesign'))
import erzeuge_rp_jsx as E  # noqa: E402

ANWEISUNG = C.HERE.parent / E.ANWEISUNG


def git_commit():
    try:
        return subprocess.run(['git', '-C', str(C.REPO), 'rev-parse', 'HEAD'], capture_output=True,
                              text=True, check=True).stdout.strip()
    except Exception:
        return ''


def jsx_pruefen(secs=None, mafteach=None):
    """Erzeugt die Skripte in ein Temp-Verzeichnis und vergleicht mit den versionierten."""
    out = []
    rh, _ = E.rh_ersetzungen(secs)
    with tempfile.TemporaryDirectory() as d:
        for src, dst, kopf, ers in ((E.BM_SRC, E.BM_DST, E.BM_KOPF, E.BM_ERSETZUNGEN), (E.RH_SRC, E.RH_DST, E.RH_KOPF, rh)):
            neu, sha = E.baue(src, Path(d) / dst.name, kopf, ers)
            gleich = dst.exists() and neu.read_bytes() == dst.read_bytes()
            out.append({'datei': 'indesign/' + dst.name, 'sha256': sha, 'reproduzierbar': gleich,
                        'quelle': src.name, 'quelle_sha256': C.sha256_file(src)})
        neu, sha, _ = E.toc_bauen(Path(d) / E.TOC_DST.name, secs=secs, mafteach=mafteach)
        out.append({'datei': 'indesign/' + E.TOC_DST.name, 'sha256': sha,
                    'reproduzierbar': E.TOC_DST.exists() and neu.read_bytes() == E.TOC_DST.read_bytes(),
                    'quelle': E.TOC_SRC.name, 'quelle_sha256': C.sha256_file(E.TOC_SRC)})
    return out


def impressum(out):
    L = ['RAV PE’ALIM · IMPRESSUM / LIZENZ (Vorschlag)', '',
         'Hebräisch:', '  ' + C.NACHWEIS_HE, '',
         'English:', '  ' + C.NACHWEIS_EN,
         '  Changes: markup normalised for typesetting; the four parts are arranged by section (Sod Yesharim,',
         '  Orach Chayim, Yoreh Deah, Even HaEzer, Choshen Mishpat); the simanim of Sod Yesharim are numbered',
         '  consecutively 1–64 (the numbering of the print is given in each heading); the indexes of the print',
         '  are replaced by a new table of contents.', '',
         'English translation:',
         '  English translation © [year] [publisher]. Licence to be decided by the project lead',
         '  (the Hebrew source is in the public domain; no share-alike obligation arises from it).', '',
         'Quelle: ' + C.SEFARIA_URL,
         'Vorlage: ' + 'https://www.nli.org.il/he/books/NNL_ALEPH001933708&context=L']
    f = Path(out) / (C.WERK_TAG + '_Impressum_Lizenz.txt')
    f.write_text('\n'.join(L) + '\n', encoding='utf-8')
    return f


def manifest(out, res):
    eing = []
    for p in [C.SOURCE_JSON, C.PIPELINE_ZIP, C.GLOSSARY, C.BIC_JSX, C.BIC_RH_JSX, C.GLIEDERUNG, G.HALACHA, G.KABBALA,
              W.WERKE, G.LC_REGELN, G.LC_GEKLAERT, E.RH_BAUSTEINE, E.TOC_SRC,
              C.REPO / 'Ben_Yehoyada_Arbeitsanleitung_AKTUELL_Fassung1.5_20261005.txt',
              C.REPO / 'Ben_Yehoyada_VERBINDLICHE_Uebersetzungsanweisung_EN_Fassung1.3_20260924.txt', ANWEISUNG]:
        if Path(p).exists():
            eing.append({'datei': str(Path(p).relative_to(C.REPO)), 'git_blob_sha': C.git_blob_sha(p),
                         'sha256': C.sha256_file(p)})
    st, b, k, g = res['struktur'], res['band'], res['konkordanz'], res['glossar']
    m = {'repository': 'Moriahise/Ben-Jehojada', 'basis_commit': git_commit(),
         'erzeugt': datetime.date.today().isoformat(), 'werk': C.WERK_EN, 'werk_he': C.WERK_HE_VOLL,
         'sefaria_url': C.SEFARIA_URL, 'lizenz': C.LIZENZ,
         'pipeline': 'ben-yehoyada-pipeline v3.2.1 (nur by_parse/by_glossary)',
         'buchmanager': 'Ben_Ish_Chai_Bilingual_Book_Manager_v1_0_17 (Format, Dateiform); Ziel {} / Sperre {} Seiten, '
                        'EN-Erweiterung {}'.format(C.TARGET_PAGES, C.MAX_PAGES, C.EN_EXPANSION),
         'eingaben': eing,
         'struktur': {'abschnitte': st['abschnitte'], 'segmente': st['segmente'], 'simanim': st['simanim'],
                      'leer': st['leer'], 'mafteach_zugeordnet': len(st['mafteach']),
                      'mafteach_hinweise': len(st['mafteach_hinweise']), 'fehler': len(st['fehler'])},
         'band': {'baende': b['baende'], 'seiten': b['band_seiten'], 'seiten_gesamt': b['seiten'],
                  'seiten_bei_1_95': b['band_seiten_bic'], 'segmente': b['segmente'], 'he_zeichen': b['he_zeichen'],
                  'master': [{'datei': Path(f).name, 'sha256': C.sha256_file(f)} for f in b['dateien']]},
         'konkordanz': {'zeilen': len(k['zeilen']), 'querverweise': k['status']},
         'glossar': {x: g[x] for x in ('treffer', 'aufgeloest', 'verschieden', 'neu', 'treffer_sy', 'neu_sy',
                                       'glossar_eintraege', 'glossar_sha256', 'kabbala_begriffe', 'kabbala_treffer_sy')},
         'werke': res['werke'],
         'abnahme': [{'datei': Path(r['datei']).name, 'fehler': len(r['fehler']), 'pruefen': len(r['pruefen'])}
                     for r in res['abnahme']],
         'uebersetzung': [{'datei': ziel.name, 'sha256': C.sha256_file(ziel), 'segmente': z['seg'], 'offen': z['offen'],
                           'fertig': fertig, 'fehler': len(r['fehler']), 'pruefen': len(r['pruefen'])}
                          for vol, ziel, z, r, fertig in res['uebersetzung'][0]],
         'indesign': res['jsx']}
    C.write_json(Path(out) / 'Quellenmanifest.json', m)
    return m


def satzfreigabe(out, res):
    b, st, k, g = res['band'], res['struktur'], res['konkordanz'], res['glossar']
    gl = C.lade_gliederung()
    heute = datetime.date.today().isoformat()
    ab = {Path(r['datei']).name: r for r in res['abnahme']}
    ueb = {vol: (ziel, z, r, fertig) for vol, ziel, z, r, fertig in res['uebersetzung'][0]}
    L = ['# Rav Pe’alim · שו״ת רב פעלים — Satzfreigabe-Master', '',
         '*Responsen in vier Teilen mit dem Anhang Sod Yesharim* · R. Yosef Chayim von Bagdad (Ben Ish Chai) · '
         'Jerusalem 1901–1912', '',
         'Erzeugt {} mit `produzieren.py` · Basis-Commit `{}`'.format(heute, git_commit()[:12] or '–'), '',
         '## Bände', '',
         '| Band | Reihe | Inhalt | Master | Segmente | Seiten (2,375 / 1,95) | Abnahme | Stand |',
         '|---|---|---|---|---:|---|---|---|']
    for v, f, s195 in zip(b['vols'], b['dateien'], b['band_seiten_bic']):
        r = ab[Path(f).name]
        u = ueb.get(v['number'])
        en = ('EN fertig (`{}`, {} Fehler)'.format(u[0].name, len(u[2]['fehler'])) if u and u[3] else
              'EN {} von {} Absätzen'.format(u[1]['seg'], len(v['segments'])) if u else 'EN offen')
        he_t, en_t = B.band_titel(v, gl)
        L.append('| {:02d}{} | {} | {} | `{}` | {} | {} / {} | {} Fehler, {} Prüfen | HE satzfrei · {} |'.format(
            v['number'], ' (Pilot)' if v['reihe_info'].get('pilot') else '', v['reihe'], en_t, Path(f).name,
            len(v['segments']), v['estimated_pages'], s195, len(r['fehler']), len(r['pruefen']), en))
    L += ['', 'Format wie Ben Ish Chai Halakha (148 × 210 mm). Ziel {} Seiten inkl. {} Reserve (Sod Yesharim, ca. {} '
          'Seiten, ist ein Band), Sperre {} Seiten. Seitenschätzung mit EN = {} × HE (Responsen); mit 1,95 (Ben Ish Chai) '
          'in Klammern.'.format(C.TARGET_PAGES, C.RESERVED_PAGES, b['band_seiten'][0], C.MAX_PAGES, C.EN_EXPANSION), '',
          '## Prüfliste', '']

    def haken(ok):
        return '[x]' if ok else '[ ]'
    quelle_ok = C.sha256_file(C.SOURCE_JSON) == C.SOURCE_JSON_SHA256
    jsx_ok = all(j['reproduzierbar'] for j in res['jsx'])
    L += ['- {} Quelle unverändert (sha256 `{}`), gemeinfrei (Sefaria „Public Domain“, Vorlage Jerusalem 1901–1912; '
          '`source/LIZENZ_UND_NACHWEIS.md`)'.format(haken(quelle_ok), C.SOURCE_JSON_SHA256[:16]),
          '- {} Struktur: {} Abschnitte, {} Segmente; Simanim {} (erwartet laut Projektvorgabe); leere Simanim der Quelle: {}'.format(
              haken(not st['fehler']), st['abschnitte'], st['segmente'],
              ', '.join('{} {}'.format(a, n) for a, n in st['simanim'].items()), ', '.join(st['leer']) or 'keine'),
          '- [x] Mafteachot des Drucks: {} Simanim mit Inhaltsangabe, {} Hinweise (Druckfehler, Sammelangaben) – '
          '`out/struktur/{}_Mafteach.tsv`'.format(len(st['mafteach']), len(st['mafteach_hinweise']), C.WERK_TAG),
          '- [x] Sod Yesharim aus den vier Teilen extrahiert und durchnummeriert (1–64), Konkordanz Teil/Abteilung/Siman ↔ '
          'Band: `out/konkordanz/{}_Konkordanz.tsv` ({} Zeilen)'.format(C.WERK_TAG, len(k['zeilen'])),
          '- [x] Querverweise des Autors auf Rav Pe’alim: {} ({}) – `out/konkordanz/{}_Querverweise.tsv`'.format(
              len(k['querverweise']), ', '.join('{} {}'.format(x, y) for x, y in sorted(k['status'].items())), C.WERK_TAG),
          '- {} Abnahme aller Master ohne FEHLER (`rp_validate.py`)'.format(haken(all(not r['fehler'] for r in res['abnahme']))),
          '- {} InDesign-Skripte aus Ben Ish Chai v1.0.17 / RH v1.0.3 (Bausteine LC RH v1.0.4) reproduzierbar erzeugt'.format(
              haken(jsx_ok)),
          '- [x] Glossar halachisch: {} Kürzel-Treffer, {:.1f} % aufgelöst (BY-Glossar + `glossar_halacha.json` + '
          'LC-Klärungen), {} neue Formen (NEU·RP) mit Kontext in `out/glossar/{}_Glossar_NEU.json`'.format(
              g['treffer'], 100.0 * g['aufgeloest'] / g['treffer'], g['neu'], C.WERK_TAG),
          '- [x] Glossar kabbalistisch: {} Begriffe, {} Treffer in Sod Yesharim (`glossar_kabbala.json`, '
          '`out/glossar/{}_Glossar_Kabbala.tsv`)'.format(g['kabbala_begriffe'], g['kabbala_treffer_sy'], C.WERK_TAG),
          '- [x] Werkverzeichnis der Zitatketten: {} Werke, {} Treffer; Absätze mit ≥ 4 Werken: {} (`out/werke/`)'.format(
              res['werke']['zitiert'], res['werke']['treffer'],
              ', '.join('{} {}'.format(x, y) for x, y in res['werke']['zitatketten'].items())),
          '- [ ] Übersetzung nach `{}` (Pilot Band 01): {}'.format(
              E.ANWEISUNG, ', '.join('Band {:02d} {} Absätze, {} offen'.format(vol, x[1]['seg'], x[1]['offen'])
                                     for vol, x in sorted(ueb.items())) or 'noch nicht begonnen'), '',
          '## Offene Entscheidungen', '',
          '1. Bandzahl: Der Plan ergibt {} Bände (Reihen nach Abteilungen, Ziel {} Seiten). Neun Bände wären nur mit '
          'Bänden von ca. {} Seiten oder mit Bänden über Abteilungsgrenzen möglich.'.format(
              b['baende'], C.TARGET_PAGES, -(-b['seiten'] // 9)),
          '2. Hakdamot und Petichah (Teil I–III) stehen am Anfang von Orach Chayim (Band 02), der Kuntres Beit Tefillah '
          '(Teil III) am Ende von Orach Chayim (`gliederung.json` → reihen). Alternative: Hakdamot vor Sod Yesharim im Pilotband '
          '(+ ca. 27 Seiten, dann über dem Ziel {}).'.format(C.TARGET_PAGES),
          '3. Seitenplanung mit EN = {} × HE (Projektvorgabe ≈ 842 HE-Zeichen je Seite). Nach den ersten übersetzten '
          'Simanim des Pilotbands messen und `rp_common.EN_EXPANSION` anpassen.'.format(C.EN_EXPANSION),
          '4. Glossar: `glossar_halacha.json` ({} Kürzel) und `glossar_kabbala.json` sind Vorschläge der Pipeline; die '
          'Übernahme in `glossary_he.json` entscheidet die Projektleitung (Arbeitsanleitung 1.5, Schritt 5).'.format(
              g['meta']['ergaenzungen']['halacha']['eintraege']),
          '5. Lizenz der englischen Übersetzung festlegen (Quelle gemeinfrei).', '',
          '## InDesign', '']
    for j in res['jsx']:
        L.append('- `{}` · sha256 `{}` · aus `{}`'.format(j['datei'], j['sha256'][:16], j['quelle']))
    L += ['', 'Ablauf: Pilot Band 01 (Sod Yesharim) – Reiter 2 (Übersetzungsportionen) oder Speicher `uebersetzung/sy/` '
          'mit `rp_uebersetzung.py`; danach Reiter 3 (InDesign-Band) mit `…_Band_01_BILINGUAL_EN_FERTIG.txt`, '
          'Kolumnentitel-Manager v1.0.0 (Kolumnentitel = Siman), zuletzt das Inhaltsverzeichnis-Skript '
          '(neues Dokument <Band>_Inhalt.indd, mit den Inhaltsangaben der Mafteachot).', '',
          '## Bandplan', '', '```', b['bericht'].rstrip(), '```', '',
          '## Struktur', '', '```', st['bericht'].rstrip(), '```', '']
    f = Path(out) / (C.WERK_TAG + '_Satzfreigabe.md')
    f.write_text('\n'.join(L) + '\n', encoding='utf-8')
    return f


def main(argv=None):
    ap = argparse.ArgumentParser(description='Rav Pe’alim – Gesamtlauf bis zum Satzfreigabe-Master')
    ap.add_argument('--out', default=str(C.HERE / 'out'))
    a = ap.parse_args(argv)
    if C.sha256_file(C.SOURCE_JSON) != C.SOURCE_JSON_SHA256:
        raise SystemExit('Quell-JSON veraendert (sha256). Neue Fassung bewusst in rp_common eintragen.')
    out = Path(a.out)
    res = {}
    print('[1/9] Struktur und Mafteach-Abgleich')
    res['struktur'] = ST.run(out, quiet=True)
    print('[2/9] Bandplan und Banddateien')
    res['band'] = B.run(out, quiet=True)
    plan = B.plan()
    print('[3/9] Konkordanz und Querverweise')
    res['konkordanz'] = K.run(out, quiet=True, plan=plan, struktur=res['struktur'])
    print('[4/9] Glossar (halachisch + kabbalistisch)')
    res['glossar'] = G.run(out=out, quiet=True, secs=plan[2])
    print('[5/9] Werkverzeichnis der Zitatketten')
    res['werke'] = W.run(out, quiet=True, secs=plan[2])
    print('[6/9] Abnahme der Banddateien')
    glossar_tsv = str(out / 'glossar' / (C.WERK_TAG + '_GLOSSAR.tsv'))
    res['abnahme'] = [V.pruefe(f, None, False, glossar_tsv) for f in res['band']['dateien']]
    for r in res['abnahme']:
        (out / 'band' / (Path(r['datei']).stem + '_Abnahme.txt')).write_text(V.bericht(r), encoding='utf-8')
    print('[7/9] Uebersetzung (aus uebersetzung/)')
    res['uebersetzung'] = U.bauen(out, quiet=True, plan=plan)
    print('[8/9] InDesign-Skripte')
    res['jsx'] = jsx_pruefen(plan[2], res['struktur']['mafteach'])
    print('[9/9] Satzfreigabe, Manifest, Impressum')
    impressum(out)
    manifest(out, res)
    f = satzfreigabe(out, res)
    print(res['band']['bericht'])
    fehler = sum(len(r['fehler']) for r in res['abnahme']) + len(res['struktur']['fehler'])
    fehler += sum(len(x[3]['fehler']) for x in res['uebersetzung'][0]) + sum(len(rb['fehler']) for f_, rb in res['uebersetzung'][1])
    fehler += sum(1 for j in res['jsx'] if not j['reproduzierbar'])
    print('Satzfreigabe: {} · Fehler gesamt: {}'.format(f, fehler))
    return 1 if fehler else 0


if __name__ == '__main__':
    sys.exit(main())
