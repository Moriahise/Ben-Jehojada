# Rav Pe’alim · Lizenz und Nachweis der Quelle

| | |
|---|---|
| Werk | שו״ת רב פעלים · Responsa Rav Pealim (R. Yosef Chayim von Bagdad, Ben Ish Chai, 1835–1909) |
| Fassung | „Rav Pealim, Jerusalem 1901-1912“ (רב פעלים, ירושלים תרס״א–תרע״ב) |
| Datei | `Responsa_Rav_Pealim_-_he_-_Rav_Pealim_Jerusalem_1901-1912.json` |
| sha256 | `9f93272b88795936ee47b15e449725d2968cdf70b44133a256f8c30a9ae32bbf` |
| Herkunft | Sefaria-Download (vom Projekt bereitgestellt, 07.11.2026): https://www.sefaria.org/download/version/Responsa%20Rav%20Pealim%20-%20he%20-%20Rav%20Pealim%2C%20Jerusalem%201901-1912.json |
| Vorlage | National Library of Israel, NNL_ALEPH001933708 (`versionSource` der Datei) |
| Lizenz | **Public Domain** (Feld `license` der Datei; `digitizedBySefaria: true`, `status: locked`) |
| Kategorien | Responsa · Acharonim |

## Folgen für die Ausgabe

- Der hebräische Text ist gemeinfrei; er darf ohne Lizenzbedingungen gesetzt, verändert und verkauft werden.
  Nachweis (Vorschlag) im Impressum: `out/Rav_Pealim_Impressum_Lizenz.txt`.
- Die Pipeline verändert den Text nicht; sie normalisiert nur das Markup (`<b>`, `<br>`) und lässt die
  Mafteachot des Drucks im Satz aus (`gliederung.json` → `auslassen`).
- Für die englische Übersetzung ergibt sich aus der Quelle keine Share-Alike-Pflicht; die Lizenz legt die
  Projektleitung fest.

## Prüfung

`produzieren.py` bricht ab, wenn die sha256 der Datei nicht dem Wert in `rp_common.SOURCE_JSON_SHA256` entspricht
(neue Fassung nur bewusst eintragen).
