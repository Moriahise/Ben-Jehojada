# -*- coding: utf-8 -*-
"""
Abnahmepruefung einer Rav-Pe'alim-Banddatei oder eines Translation_Batch (Dateiform des
Ben-Ish-Chai-/Rav-Pe'alim-Buchmanagers). Uebernommen aus lc_validate.py / oyc_validate.py.

    python3 rp_validate.py --in Band_01_BILINGUAL_EN_FERTIG.txt --gegen Band_01_BILINGUAL.txt
    python3 rp_validate.py --in Translation_Batch_01_RPL-…_EN_FERTIG.txt --gegen Band_01_BILINGUAL.txt
    python3 rp_validate.py --in Band_01_BILINGUAL.txt                 (frischer Master)

FEHLER (blockierend, Rueckgabecode 1)
  Struktur   IDs, n, Reihenfolge, Zahl der Segmente, Abschnittsfolge wie im
             Ausgangsmaster; keine doppelten IDs; IDs mit Kennung RPL-
  Geschuetzt <he>, <he_title> und das vorgegebene <en_title> (Titel der Ausgabe)
             zeichengleich (nach CDATA, Zeilenenden)
  EN         bei --fertig (Vorgabe bei Dateinamen *_EN_FERTIG*): jedes <en> und
             jedes <en_title> gefuellt; <en> nicht gleich <he>
  Titel      <en_title> ohne hebraeische Zeichen und ohne Tags
  Tags       in <en> und <he> nur b, i, small, sup, br; ausgeglichen
  Verboten   YHWH, Yahweh, Jehovah, Adonai, "Bible:", "Tanach:", Markdown-Zaeune
  Nummer     kein Absatz des Englischen beginnt mit "[" + Zahl (Absatzerkennung)
PRUEFEN (nicht blockierend)
  Laengenverhaeltnis EN/HE ausserhalb 1,0–4,5 (Responsen: Kuerzel werden ausgeschrieben)
  hoher Anteil hebraeischer Zeichen in <en>
  Segmente mit NEU-Kuerzeln aus dem Glossar (--glossar), zur Sichtpruefung
"""
import argparse
import collections
import json
import re
import sys
from pathlib import Path

import rp_common as C

SEC_RE = re.compile(r'<section>\s*<he_title>([\s\S]*?)</he_title>\s*<en_title>([\s\S]*?)</en_title>\s*</section>', re.I)
SEG_RE = re.compile(r'<segment\b([^>]*)>\s*<he>([\s\S]*?)</he>\s*<en>([\s\S]*?)</en>\s*</segment>', re.I)
ATTR_RE = re.compile(r'(\w+)=["\']([^"\']*)["\']')
HEB_RE = re.compile('[֐-׿]')
ERLAUBT = {'b', 'i', 'small', 'sup', 'br'}
VERBOTEN = [r'\bYHWH\b', r'\bYahweh\b', r'\bJehovah\b', r'\bAdonai\b', r'\bBible:', r'\bTanach:', r'```']
LAENGE = (1.0, 4.5)


def restore_cdata(s):
    s = (s or '').strip()
    if s.startswith('<![CDATA[') and s.endswith(']]>'):
        s = s[9:-3].replace(']]]]><![CDATA[>', ']]>')
    return s


def xml_unescape(s):
    return (s or '').replace('&quot;', '"').replace('&gt;', '>').replace('&lt;', '<').replace('&amp;', '&')


def norm(s):
    return re.sub(r'\s+', ' ', (s or '').replace('\r\n', '\n').replace('\r', '\n')).strip()


def lese(path):
    raw = Path(path).read_text(encoding='utf-8-sig').replace('\r\n', '\n').replace('\r', '\n')
    ev = []
    for m in SEC_RE.finditer(raw):
        ev.append((m.start(), 'sec', restore_cdata(xml_unescape(m.group(1))), restore_cdata(xml_unescape(m.group(2)))))
    for m in SEG_RE.finditer(raw):
        a = dict(ATTR_RE.findall(m.group(1)))
        ev.append((m.start(), 'seg', a, restore_cdata(m.group(2)), restore_cdata(m.group(3))))
    ev.sort(key=lambda e: e[0])
    secs, segs, cur = [], [], None
    for e in ev:
        if e[1] == 'sec':
            cur = {'he': e[2], 'en': e[3], 'i': len(secs)}
            secs.append(cur)
        else:
            segs.append({'id': e[2].get('id', ''), 'n': e[2].get('n', ''), 'he': e[3], 'en': e[4],
                         'sec_he': cur['he'] if cur else '', 'sec_en': cur['en'] if cur else '',
                         'sec_i': cur['i'] if cur else -1})
    kopf = re.search(r'<(book|translation_batch)\b([^>]*)>', raw)
    planung = re.search(r'<planning\b([^>]*)/>', raw)
    return {'secs': secs, 'segs': segs, 'kopf': kopf.group(0) if kopf else '',
            'planung': dict(ATTR_RE.findall(planung.group(1))) if planung else {},
            'batch': bool(kopf and kopf.group(1) == 'translation_batch')}


def tags_pruefen(text):
    fehler = []
    stapel = []
    for m in re.finditer(r'<(/?)([A-Za-z]+)[^>]*?(/?)>', text):
        zu, name, selbst = m.group(1), m.group(2).lower(), m.group(3)
        if name not in ERLAUBT:
            fehler.append('Tag <{}> nicht erlaubt'.format(name))
            continue
        if name == 'br' or selbst:
            continue
        if zu:
            if not stapel or stapel[-1] != name:
                fehler.append('Tag </{}> ohne passendes oeffnendes Tag'.format(name))
            else:
                stapel.pop()
        else:
            stapel.append(name)
    if stapel:
        fehler.append('nicht geschlossen: ' + ', '.join('<{}>'.format(x) for x in stapel))
    return fehler


def pruefe(datei, gegen=None, fertig=None, glossar=None):
    d = lese(datei)
    F, P = [], []
    if fertig is None:
        fertig = '_EN_FERTIG' in Path(datei).name
    ids = [s['id'] for s in d['segs']]
    dup = [k for k, v in collections.Counter(ids).items() if v > 1]
    if dup:
        F.append('Doppelte IDs: ' + ', '.join(dup[:10]))
    if not d['segs']:
        F.append('Keine <segment>-Bloecke erkannt')
    fremd = [i for i in ids if not re.match(r'^' + C.ID_PREFIX + r'\d{7}$', i)]
    if fremd:
        F.append('IDs ohne Kennung {}: {}'.format(C.ID_PREFIX, ', '.join(fremd[:10])))
    ref = None
    if gegen:
        ref = lese(gegen)
        rmap = {s['id']: s for s in ref['segs']}
        rids = [s['id'] for s in ref['segs']]
        if d['batch']:
            fehlend = [i for i in ids if i not in rmap]
            if fehlend:
                F.append('IDs nicht im Master: ' + ', '.join(fehlend[:10]))
            pos = [rids.index(i) for i in ids if i in rmap]
            if pos != sorted(pos) or (pos and pos != list(range(pos[0], pos[0] + len(pos)))):
                F.append('Batch ist kein zusammenhaengender, geordneter Ausschnitt des Masters')
        else:
            if ids != rids:
                F.append('Segmentfolge weicht ab: {} statt {} Segmente; erste Abweichung bei {}'.format(
                    len(ids), len(rids), next((a for a, b in zip(ids, rids) if a != b),
                                              ids[len(rids):][:1] or rids[len(ids):][:1])))
            if [s['he'] for s in d['secs']] != [s['he'] for s in ref['secs']]:
                F.append('Abschnittsfolge (<he_title>) weicht vom Master ab')
        for s in d['segs']:
            r = rmap.get(s['id'])
            if not r:
                continue
            if s['n'] != r['n']:
                F.append('{}: n="{}" statt "{}"'.format(s['id'], s['n'], r['n']))
            if norm(s['he']) != norm(r['he']):
                F.append('{}: <he> veraendert'.format(s['id']))
            if norm(s['sec_he']) != norm(r['sec_he']):
                F.append('{}: Abschnitt (<he_title>) veraendert oder verschoben'.format(s['id']))
            if norm(r['sec_en']) and norm(s['sec_en']) != norm(r['sec_en']):
                F.append('{}: <en_title> des Abschnitts veraendert (Master: "{}")'.format(s['id'], r['sec_en']))
            if norm(r['en']) and norm(s['en']) != norm(r['en']):
                F.append('{}: bereits gefuelltes <en> veraendert'.format(s['id']))
    for s in d['secs']:
        en = s['en']
        if fertig and not norm(en):
            F.append('<en_title> leer fuer "{}"'.format(s['he']))
        if HEB_RE.search(en):
            F.append('<en_title> mit hebraeischen Zeichen: "{}"'.format(en))
        if '<' in en:
            F.append('<en_title> mit Tags: "{}"'.format(en))
    neu = {}
    if glossar and Path(glossar).exists():
        for r in C.read_tsv(glossar):
            if 'NEU' in (r.get('status') or ''):
                neu[r['abbr']] = True
    gefuellt = 0
    for s in d['segs']:
        for f in tags_pruefen(s['he']):
            F.append('{}: <he> {}'.format(s['id'], f))
        en = s['en']
        if not norm(C.strip_tags(en)):
            if fertig:
                F.append('{}: <en> leer'.format(s['id']))
            continue
        gefuellt += 1
        if norm(en) == norm(s['he']):
            F.append('{}: <en> enthaelt den hebraeischen Text'.format(s['id']))
        for f in tags_pruefen(en):
            F.append('{}: {}'.format(s['id'], f))
        for v in VERBOTEN:
            if re.search(v, en):
                F.append('{}: verbotene Form {}'.format(s['id'], v.replace('\\b', '')))
        for par in re.split(r'\n|<br\s*/?>', en):
            if re.match(r'^\s*\[\d', C.strip_tags(par)):
                F.append('{}: Absatz beginnt mit "[" und Zahl (stoert die Absatzerkennung)'.format(s['id']))
        he_len = len(C.strip_nikud(C.strip_tags(s['he'])))
        en_len = len(C.strip_tags(en))
        if he_len and not LAENGE[0] <= en_len / float(he_len) <= LAENGE[1]:
            P.append('{}: Laengenverhaeltnis EN/HE {:.2f} (HE {} / EN {} Zeichen)'.format(
                s['id'], en_len / float(he_len), he_len, en_len))
        if re.search(r'<br\s*/?>', en) and not re.search(r'<br\s*/?>', s['he']):
            P.append('{}: <br> im Englischen, aber nicht im Hebraeischen'.format(s['id']))
        hb = len(HEB_RE.findall(C.strip_nikud(en)))
        if en_len and hb / float(en_len) > 0.15:
            P.append('{}: {:.0f} % hebraeische Zeichen in <en>'.format(s['id'], 100.0 * hb / en_len))
        if neu:
            plain = C.strip_nikud(C.strip_tags(s['he']))
            treffer = sorted({k for k in neu if re.search(r'(?<![א-ת"])' + re.escape(k) + r'(?![א-ת"])', plain)})
            if treffer:
                P.append('{}: NEU-Kuerzel {} – Aufloesung im Englischen sichten'.format(s['id'], ' '.join(treffer[:8])))
    return {'datei': str(datei), 'gegen': str(gegen) if gegen else None, 'segmente': len(d['segs']),
            'abschnitte': len(d['secs']), 'en_gefuellt': gefuellt, 'fertig_modus': fertig,
            'reihe': d['planung'].get('reihe', ''), 'fehler': F, 'pruefen': P}


def bericht(r):
    L = ['RAV PE’ALIM · ABNAHMEPRUEFUNG', '',
         'Datei: {}'.format(r['datei']), 'Gegen: {}'.format(r['gegen'] or '– (ohne Master-Vergleich)'),
         'Segmente {} · Abschnitte {} · <en> gefuellt {} · Modus {} · Reihe {}'.format(
             r['segmente'], r['abschnitte'], r['en_gefuellt'], 'EN_FERTIG' if r['fertig_modus'] else 'Master',
             r['reihe'] or '–'), '',
         'FEHLER: {}'.format(len(r['fehler']))]
    L += ['  ' + x for x in r['fehler'][:300]]
    L += ['', 'PRUEFEN: {}'.format(len(r['pruefen']))] + ['  ' + x for x in r['pruefen'][:500]]
    return '\n'.join(L) + '\n'


def main(argv=None):
    ap = argparse.ArgumentParser(description='Abnahmepruefung Rav Pe’alim (Banddatei/Batch)')
    ap.add_argument('--in', dest='datei', required=True)
    ap.add_argument('--gegen', help='Ausgangsmaster (BILINGUAL.txt) fuer den Feldvergleich')
    ap.add_argument('--fertig', action='store_true', help='alle <en>/<en_title> muessen gefuellt sein')
    ap.add_argument('--master', action='store_true', help='frischer Master: leere <en> erlaubt')
    ap.add_argument('--glossar', default=str(C.HERE / 'out' / 'glossar' / (C.WERK_TAG + '_GLOSSAR.tsv')))
    ap.add_argument('--json', help='Ergebnis zusaetzlich als JSON')
    a = ap.parse_args(argv)
    fertig = True if a.fertig else (False if a.master else None)
    r = pruefe(a.datei, a.gegen, fertig, a.glossar)
    print(bericht(r))
    if a.json:
        Path(a.json).write_text(json.dumps(r, ensure_ascii=False, indent=1), encoding='utf-8')
    return 1 if r['fehler'] else 0


if __name__ == '__main__':
    sys.exit(main())
