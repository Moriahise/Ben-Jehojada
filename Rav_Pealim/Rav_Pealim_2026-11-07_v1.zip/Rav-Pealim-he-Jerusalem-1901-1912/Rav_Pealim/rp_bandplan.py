# -*- coding: utf-8 -*-
"""
Bandplan nach Reihen (Abteilungen) und Banddateien (Satzfreigabe-Master, BIC-Dateiform).

Seitenschaetzung wie estimatedBodyPages() des Ben-Ish-Chai-Buchmanagers v1.0.17,
mit dem Planwert fuer Responsen:

    Seiten(Text) = ceil(max(HE/1050, EN/2000)),  EN = HE * 2,375 (zu uebersetzen)
    Band         = Seiten(Text) + 12 Reserve, Ziel 600, harte Grenze 800

Anders als planVolumes() des JSX (fuellt jeden Band bis zum Ziel) teilt der Plan
jede Reihe gleichmaessig: Zahl der Baende = ceil(Seiten der Reihe / 588), Grenzen
zwischen Simanim moeglichst nahe an gleichen Anteilen. Jede Reihe (gliederung.json
"reihen") beginnt einen neuen Band; Band 01 ist der Pilot Sod Yesharim.

HE zaehlt ohne Nikud/Teamim (plan_length), wie der RP-Buchmanager.

Ausgaben (out/band/, BIC-Dateiform, BOM + CRLF)
    Rav_Pealim_Band_01_BILINGUAL.txt …          je Band; <en_title> gefuellt (Titel der Ausgabe), <en> leer
    Rav_Pealim_Bandplan.txt
    Rav_Pealim_Segmentkontrolle.tsv
"""
import argparse
import math
import re
import sys
from pathlib import Path

import rp_common as C


def body_pages(he_chars, en_chars=None, he_cpp=C.HE_CHARS_PER_PAGE, expansion=C.EN_EXPANSION):
    en = he_chars * expansion if en_chars is None else en_chars
    return int(math.ceil(max(he_chars / float(he_cpp), en / float(C.EN_CHARS_PER_PAGE))))


def segmente(secs):
    """Segmentfolge der Ausgabe mit globalen IDs RPL-0000001 … in Bandfolge."""
    out, nr = [], 0
    for s in secs:
        for x in s['segmente']:
            nr += 1
            out.append({'id': '{}{:07d}'.format(C.ID_PREFIX, nr), 'n': x['n'], 'he': x['he'], 'en': '',
                        'reihe': s['reihe'], 'teil': s['teil'], 'bereich': s['bereich'], 'siman': s['siman'],
                        'lauf': s['lauf'], 'section_he': s['he_title'], 'section_en': s['en_title'],
                        'gruppe': s['gruppe'], 'ref': x['ref'], 'quelle_ref': s['quelle_ref'],
                        'plan_chars': x['plan_chars'], 'he_chars': x['he_chars'], 'rolle': 'text',
                        'abschnitt': s['nr']})
    return out


def _abschnitte(segs):
    out, cur = [], None
    for s in segs:
        if cur is None or s['abschnitt'] != cur['abschnitt']:
            cur = {'abschnitt': s['abschnitt'], 'reihe': s['reihe'], 'segments': [], 'he': 0}
            out.append(cur)
        cur['segments'].append(s)
        cur['he'] += s['plan_chars']
    return out


def teile_reihe(abschnitte, expansion=C.EN_EXPANSION, body_target=C.BODY_TARGET):
    """Gleichmaessige Teilung einer Reihe zwischen Abschnitten. -> Liste von Abschnittslisten."""
    gesamt = sum(a['he'] for a in abschnitte)
    n = max(1, int(math.ceil(body_pages(gesamt, expansion=expansion) / float(body_target))))
    while True:
        kum, grenzen, vorher = 0, [], 0
        kums = []
        for a in abschnitte:
            kum += a['he']
            kums.append(kum)
        for k in range(1, n):
            ziel = gesamt * k / float(n)
            beste = min(range(vorher + 1, len(abschnitte)), key=lambda i: abs(kums[i - 1] - ziel),
                        default=None)
            if beste is None:
                break
            grenzen.append(beste)
            vorher = beste
        teile, a0 = [], 0
        for g in grenzen + [len(abschnitte)]:
            teile.append(abschnitte[a0:g])
            a0 = g
        teile = [t for t in teile if t]
        if all(body_pages(sum(a['he'] for a in t), expansion=expansion) <= body_target for t in teile) or n > 40:
            return teile
        n += 1


def plan_volumes(segs, gl, expansion=C.EN_EXPANSION, body_target=C.BODY_TARGET):
    abschnitte = _abschnitte(segs)
    vols = []
    for r in gl['reihen']:
        eigene = [a for a in abschnitte if a['reihe'] == r['key']]
        if not eigene:
            continue
        for teil in teile_reihe(eigene, expansion, body_target):
            v = {'number': len(vols) + 1, 'reihe': r['key'], 'reihe_info': r,
                 'segments': [s for a in teil for s in a['segments']], 'he': sum(a['he'] for a in teil)}
            v['en'] = v['he'] * expansion
            v['body_pages'] = body_pages(v['he'], expansion=expansion)
            v['estimated_pages'] = v['body_pages'] + C.RESERVED_PAGES
            vols.append(v)
    teil_von = {}
    for v in vols:
        teil_von.setdefault(v['reihe'], []).append(v)
    for r, vs in teil_von.items():
        for i, v in enumerate(vs, start=1):
            v['reihe_band'] = i
            v['reihe_baende'] = len(vs)
    for v in vols:
        if v['estimated_pages'] > C.TARGET_PAGES:
            raise SystemExit('Band {} ueberschreitet schon in der Planung {} Seiten.'.format(v['number'], C.TARGET_PAGES))
    return vols


def band_titel(v, gl):
    a = gl['abteilungen'][v['reihe_info']['abteilung']]
    zusatz = ' ({}/{})'.format(v['reihe_band'], v['reihe_baende']) if v['reihe_baende'] > 1 else ''
    return a['he'] + zusatz, a['en'] + zusatz


def serialize_volume(v, gl):
    """serializeVolume() des BIC-JSX; project/reihe werkspezifisch, <en_title> gefuellt."""
    he_t, en_t = band_titel(v, gl)
    out = ['<book project="{}" volume="{:02d}" max_pages="{}" reihe="{}">'.format(
               C.PROJECT_ATTR, v['number'], C.MAX_PAGES, v['reihe']),
           '<planning estimated_pages="{}" target_pages="{}" reserved_pages="{}" reihe="{}" band_in_reihe="{}/{}" '
           'titel_he="{}" titel_en="{}" />'.format(
               v['estimated_pages'], C.TARGET_PAGES, C.RESERVED_PAGES, v['reihe'], v['reihe_band'], v['reihe_baende'],
               C.xml_escape(he_t), C.xml_escape(en_t))]
    last = None
    for s in v['segments']:
        if s['abschnitt'] != last:
            out += ['', '<section>', '<he_title>' + C.xml_escape(s['section_he']) + '</he_title>',
                    '<en_title>' + C.xml_escape(s['section_en']) + '</en_title>', '</section>']
            last = s['abschnitt']
        out += ['', '<segment id="{}" n="{}">'.format(s['id'], s['n']),
                '<he>' + C.protect_cdata(s['he']) + '</he>', '<en>' + C.protect_cdata(s['en']) + '</en>', '</segment>']
    out += ['', '</book>']
    return '\r\n'.join(out)


SEG_RE = re.compile(r'<segment\b[^>]*\bid="([^"]+)"[^>]*\bn="(\d+)"[^>]*>\s*<he>([\s\S]*?)</he>\s*<en>([\s\S]*?)</en>')


def cdata(x):
    return re.sub(r'^<!\[CDATA\[|\]\]>$', '', x.strip())


def master_hat_uebersetzung(path):
    """True, wenn der Master schon englischen Text zu hebraeischen Segmenten hat."""
    if not Path(path).exists():
        return False
    raw = Path(path).read_text(encoding='utf-8-sig')
    for m in SEG_RE.finditer(raw):
        if C.strip_tags(cdata(m.group(3))).strip() and C.strip_tags(cdata(m.group(4))).strip():
            return True
    return False


def band_datei(out, nummer):
    return Path(out) / 'band' / '{}_Band_{:02d}_BILINGUAL.txt'.format(C.WERK_TAG, nummer)


def plan(gl=None):
    """Werk, Abschnitte, Segmente und Baende ohne Dateien."""
    werk = C.load_werk()
    gl = gl or C.lade_gliederung()
    secs = C.build_edition(werk, gl)
    segs = segmente(secs)
    vols = plan_volumes(segs, gl)
    return werk, gl, secs, segs, vols


def run(out='out', ueberschreiben=False, quiet=False):
    werk, gl, secs, segs, vols = plan()
    vols_bic = plan_volumes(segs, gl, expansion=C.EN_EXPANSION_BIC)
    vols_540 = plan_volumes(segs, gl, body_target=540 - C.RESERVED_PAGES)
    o = Path(out) / 'band'
    written = []
    for v in vols:
        f = band_datei(out, v['number'])
        if master_hat_uebersetzung(f) and not ueberschreiben:
            raise SystemExit('Abbruch ohne Ueberschreiben: {} enthaelt bereits Englisch.'.format(f))
        C.write_bic_text(f, serialize_volume(v, gl))
        written.append(f)
    for alt in o.glob('{}_Band_*_BILINGUAL.txt'.format(C.WERK_TAG)):
        if alt not in written:
            alt.unlink()

    rows = []
    for v in vols:
        for s in v['segments']:
            rows.append([v['number'], s['id'], s['n'], s['section_he'], s['he_chars'], 'offen', s['ref'],
                         s['plan_chars'], s['reihe'], s['gruppe'], s['lauf'] or '', s['quelle_ref']])
    C.write_tsv(o / (C.WERK_TAG + '_Segmentkontrolle.tsv'),
                ['volume', 'segment_id', 'visible_number', 'section', 'he_chars', 'status', 'sefaria_ref',
                 'he_konsonanten', 'reihe', 'gruppe', 'lauf', 'siman_ref'], rows)

    total_plan = sum(s['plan_chars'] for s in segs)
    total_bic = sum(s['he_chars'] for s in segs)
    seiten = sum(v['estimated_pages'] for v in vols)
    L = ['RAV PE’ALIM · BANDPLAN (REIHEN NACH ABTEILUNGEN, FORMAT BEN ISH CHAI HALAKHA)', '',
         'Quelle: {} · {} · sha256 {}'.format(werk['meta']['title'], werk['meta']['versionTitle'], werk['meta']['sha256']),
         '        {} Segmente · {} Abschnitte · {} Reihen'.format(len(segs), len(secs), len(gl['reihen'])),
         'Format: {} × {} mm · Keter YG 10/{} pt · Cambria 9/10,8 pt (Ben Ish Chai v1.0.17)'.format(
             C.PAGE_W_MM, C.PAGE_H_MM, C.HE_LEADING_PT),
         'Kalibrierung: HE {} Zeichen/Seite · EN {} Zeichen/Seite · erwartete EN-Laenge {:.3f} × HE '
         '(Responsen; Ben Ish Chai misst {:.2f})'.format(C.HE_CHARS_PER_PAGE, C.EN_CHARS_PER_PAGE, C.EN_EXPANSION,
                                                       C.EN_EXPANSION_BIC),
         'Grenzen: Ziel {} Seiten (davon {} Reserve) · Textseiten hoechstens {} · absolute Sperre {}'.format(
             C.TARGET_PAGES, C.RESERVED_PAGES, C.BODY_TARGET, C.MAX_PAGES),
         'HE-Zeichen: {} ohne Nikud/Teamim (Planung) · {} mit Vokalzeichen'.format(total_plan, total_bic),
         'Teilung: jede Reihe beginnt einen Band; innerhalb der Reihe gleichmaessig zwischen Simanim', '',
         'Plan: {} Baende · ca. {} Seiten gesamt'.format(len(vols), seiten)]
    for v in vols:
        first, last = v['segments'][0], v['segments'][-1]
        he_t, en_t = band_titel(v, gl)
        L += ['Band {:02d} · {}{}: ca. {} Seiten (davon {} Reserve) · {} Segmente · {} bis {}'.format(
                  v['number'], en_t, ' · PILOT' if v['reihe_info'].get('pilot') else '', v['estimated_pages'],
                  C.RESERVED_PAGES, len(v['segments']), first['id'], last['id']),
              '    {}  →  {}'.format(first['section_he'], last['section_he']),
              '    {}  →  {}'.format(first['section_en'], last['section_en']),
              '    HE {} Zeichen = {:.1f} Seiten · EN geschaetzt {} Zeichen = {:.1f} Seiten · Reserve bis Ziel {}: {} · '
              'bis Sperre {}: {}'.format(v['he'], v['he'] / float(C.HE_CHARS_PER_PAGE), int(math.ceil(v['en'])),
                                         v['en'] / float(C.EN_CHARS_PER_PAGE), C.TARGET_PAGES,
                                         C.TARGET_PAGES - v['estimated_pages'], C.MAX_PAGES,
                                         C.MAX_PAGES - v['estimated_pages'])]
    L += ['', 'REIHEN']
    for r in gl['reihen']:
        vs = [v for v in vols if v['reihe'] == r['key']]
        he = sum(v['he'] for v in vs)
        L.append('  {:<3} {:<16} {:>2} Band/Baende · {:>9} HE-Zeichen · ca. {:>5} Seiten · {}'.format(
            r['key'], r['abteilung'], len(vs), he, sum(v['estimated_pages'] for v in vs), r.get('beschreibung', '')))
    L += ['', 'EMPFINDLICHKEIT',
          '  EN-Laenge {:.2f} × HE (gemessen bei Ben Ish Chai): {} Baende · ca. {} Seiten · '.format(
              C.EN_EXPANSION_BIC, len(vols_bic), sum(v['estimated_pages'] for v in vols_bic)) +
          ' · '.join('{:02d} {}'.format(v['number'], v['estimated_pages']) for v in vols_bic),
          '  Ziel 540 statt {} Seiten: {} Baende ({})'.format(
              C.TARGET_PAGES, len(vols_540), ', '.join('{} {}'.format(r['key'], len([v for v in vols_540
                                                                                    if v['reihe'] == r['key']]))
                                                       for r in gl['reihen'])) +
          ' – Sod Yesharim passt dann nicht in einen Band.',
          '  Gesamtumfang ({} HE-Zeichen × {:.3f} / {} + Reserve): ca. {} Seiten; eine Aufteilung in 9 Baende '
          'braeuchte Baende von ca. {} Seiten oder Baende ueber Abteilungsgrenzen hinweg.'.format(
              total_plan, C.EN_EXPANSION, C.EN_CHARS_PER_PAGE, seiten, int(math.ceil(seiten / 9.0)))]
    L += ['', 'HINWEISE',
          '  Master: <en_title> = Titel der Ausgabe (Siman-Zaehlung, Konkordanz zum Druck in '
          'out/konkordanz/), <en> leer; die Uebersetzung steht in uebersetzung/ und wird mit rp_uebersetzung.py zu '
          '*_EN_FERTIG.txt bzw. *_EN_STAND.txt zusammengefuehrt.',
          '  Sod Yesharim: Simanim des Drucks Teil I 1–17, II 1–14, III 1–13, IV 1–20 → Ausgabe 1–64.',
          '  Nicht gesetzt: Mafteachot des Drucks (gliederung.json → auslassen); leere Simanim der Quelle '
          '(Teil IV Orach Chayim 36–38).',
          '  InDesign: indesign/Rav_Pealim_Bilingual_Book_Manager_v1_0_0.jsx (Reiter 2/3), '
          'indesign/Rav_Pealim_Running_Header_Manager_v1_0_0.jsx (Kolumnentitel = Siman) und '
          'indesign/Rav_Pealim_Inhaltsverzeichnis_v1_0_0.jsx.']
    L += ['', 'Dateien:'] + ['  ' + str(f.name) for f in written]
    txt = '\n'.join(L) + '\n'
    C.write_bic_text(o / (C.WERK_TAG + '_Bandplan.txt'), txt)
    if not quiet:
        print(txt)
    return {'baende': len(vols), 'band_seiten': [v['estimated_pages'] for v in vols],
            'band_seiten_bic': [v['estimated_pages'] for v in vols_bic], 'baende_540': len(vols_540),
            'segmente': len(segs), 'he_zeichen': total_plan, 'he_zeichen_bic': total_bic, 'seiten': seiten,
            'dateien': [str(f) for f in written], 'bericht': txt, 'vols': vols, 'segs': segs, 'secs': secs}


def main(argv=None):
    ap = argparse.ArgumentParser(description='Rav Pe’alim – Bandplan und Banddateien')
    ap.add_argument('--out', default=str(C.HERE / 'out'))
    ap.add_argument('--ueberschreiben', action='store_true',
                    help='auch einen Master mit Englisch ueberschreiben (nie fuer Produktion)')
    a = ap.parse_args(argv)
    run(a.out, a.ueberschreiben)
    return 0


if __name__ == '__main__':
    sys.exit(main())
