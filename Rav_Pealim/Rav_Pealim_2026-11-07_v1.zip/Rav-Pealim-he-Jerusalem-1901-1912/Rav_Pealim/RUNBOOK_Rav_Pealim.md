# RUNBOOK · Rav Pe’alim (שו״ת רב פעלים)

Responsen des R. Yosef Chayim von Bagdad (Ben Ish Chai) in vier Teilen, Jerusalem 1901–1912, je mit dem
kabbalistischen Anhang „Sod Yesharim“. Pipeline und InDesign-Skripte nach dem Muster von Leshon Chakhamim
(`Leshon-Chakhamim-he-Bakhshi-Edition-2021/Leshon_Chakhamim`) und Ben Ish Chai Halakha (Buchmanager v1.0.17).

| | |
|---|---|
| Sefaria-Titel | Responsa Rav Pealim (`source/`, sha256 `9f93272b…`, gemeinfrei) |
| Struktur | Teil › Abteilung › Siman › Absatz |
| Simanim | Orach Chayim 185 · Yoreh Deah 169 · Even HaEzer 72 · Choshen Mishpat 31 · Sod Yesharim 64; dazu Kuntres Beit Tefillah (Teil III), Hakdamot I–III, Petichah I |
| Umfang | 4,18 Mio. HE-Zeichen (ohne Mafteachot) · ca. 5.090 Seiten · 10 Bände |
| Pilot | Band 01 = Sod Yesharim (64 Simanim aus den vier Teilen, durchnummeriert 1–64), ca. 578 Seiten |

## Ablauf

```bash
python3 produzieren.py          # Gesamtlauf (ca. 30 s), Ergebnis: out/Rav_Pealim_Satzfreigabe.md, Fehler gesamt: 0
python3 test_rp.py              # Regressionstests (Node fuer die JSX-Tests)
```

1. **Struktur** (`rp_struktur.py`): Zählung je Abteilung gegen `gliederung.json` → `erwartet` (FEHLER bei
   Abweichung); leere Simanim der Quelle (Teil IV Orach Chayim 36–38) werden genannt, nicht gesetzt.
   Mafteach-Abgleich: Inhaltsangabe des Drucks je Siman (487 Simanim), Druckfehler und Sammelangaben als Hinweis
   (`out/struktur/`).
2. **Bandplan** (`rp_bandplan.py`): Reihen nach Abteilungen (`gliederung.json` → `reihen`), jede Reihe beginnt
   einen Band, Teilung innerhalb der Reihe gleichmäßig zwischen Simanim. Seiten = max(HE/1050, EN/2000) mit
   EN = 2,375 × HE (Responsen; Projektvorgabe ≈ 842 HE-Zeichen je Seite) + 12 Reserve; Ziel 600, Sperre 800.
   Master `out/band/Rav_Pealim_Band_XX_BILINGUAL.txt` mit gefülltem `<en_title>` (Titel der Ausgabe).
3. **Konkordanz** (`rp_konkordanz.py`): Teil/Abteilung/Siman des Drucks ↔ Band, Laufnummer, Segment-IDs,
   Inhaltsangabe; Querverweise „רב פעלים ח״X … סי׳ Y“ mit Ziel in der Ausgabe (`out/konkordanz/`).
4. **Glossar** (`rp_glossar.py`): BY-Pipeline v3.2.1 + `glossar_halacha.json` (Responsen-/Poskim-Kürzel) +
   `glossar_kabbala.json` (Begriffe und Kürzel, in Sod Yesharim vor dem BY-Glossar) + LC-SHEM-Regeln und
   LC-Klärungen + `uebersetzung/glossar_geklaert.json` (`out/glossar/`).
5. **Werkverzeichnis** (`rp_werke.py`): zitierte Werke/Autoritäten mit einheitlicher englischer Wiedergabe,
   dichteste Zitatketten je Reihe (`out/werke/`).
6. **Abnahme** (`rp_validate.py`): jeder Master ohne FEHLER.
7. **Übersetzung** (`rp_uebersetzung.py`): Speicher `uebersetzung/<reihe>/*.txt` → EN_STAND/EN_FERTIG je Band,
   erste Translation_Batch-Datei, Prüfbericht.
8. **InDesign** (`indesign/erzeuge_rp_jsx.py`): Skripte reproduzierbar aus den Ben-Ish-Chai-Originalen.
9. **Satzfreigabe, Manifest, Impressum** (`out/`).

## Gliederung der Ausgabe (gliederung.json)

| Band | Reihe | Inhalt (Druck) | Seiten ca. |
|---|---|---|---:|
| 01 | Sod Yesharim (Pilot) | SY I 1–17, II 1–14, III 1–13, IV 1–20 → Simanim 1–64 | 578 |
| 02–04 | Orach Chayim | Hakdamot I–III, Petichah I; OC I–IV; Kuntres Beit Tefillah (III) | 527 · 507 · 526 |
| 05–07 | Yoreh Deah | YD I–IV | 492 · 492 · 492 |
| 08–09 | Even HaEzer | EH I–IV | 546 · 540 |
| 10 | Choshen Mishpat | CM II–IV | 386 |

Titel der Abschnitte (Pipeline, `rp_common.abschnitt_titel`):
- Sod Yesharim (durchnummeriert): `סוד ישרים סימן י״ח (ח״ב סי׳ א׳)` / `Sod Yesharim, Siman 18 (Part II, Siman 1)`,
  Kurztitel `Sod Yesharim 18`
- übrige Reihen (Zählung des Drucks): `אורח חיים ח״ב סימן י״ד` / `Orach Chayim, Part II, Siman 14`, Kurztitel
  `Orach Chayim II:14`
- Gruppen (Inhaltsverzeichnis, `{GRUPPE}`): Abteilung · Teil, dazu „Introductions“ und „Kuntres Beit Tefillah (Part III)“

Neun Bände (Projektschätzung) gingen nur mit Bänden von ca. 566 Seiten über Abteilungsgrenzen hinweg; der Plan
bleibt bei Abteilungsreihen (10 Bände). Empfindlichkeit im Bandplan: mit EN 1,95 × HE ca. 4.200 Seiten; mit Ziel
540 wären es 12 Bände und Sod Yesharim zwei.

## InDesign

| Skript | Quelle | Zweck |
|---|---|---|
| `indesign/Rav_Pealim_Bilingual_Book_Manager_v1_0_0.jsx` | Ben Ish Chai BM v1.0.17 | Reiter 2 (Übersetzungsportionen), Reiter 3 (InDesign-Band); Ziel 600, Sperre 800, EN 2,375; Kennung RPL; Reiter 1 verweist auf die Pipeline |
| `indesign/Rav_Pealim_Running_Header_Manager_v1_0_0.jsx` | Ben Ish Chai RH v1.0.3 + `rh_abschnitte_bausteine.js` (Stand LC RH v1.0.4) | Kolumnentitel = Siman-Überschrift („RAV PE’ALIM · {ABSCHNITT}“ / „רב פעלים · {ABSCHNITT_HE}“), Kurztitel je Siman, frischer Kopfrahmen je Lauf, nie Übersatz |
| `indesign/Rav_Pealim_Inhaltsverzeichnis_v1_0_0.jsx` | `vorlage_Inhaltsverzeichnis.jsx` (aus LC) | neues Inhaltsverzeichnis `<Band>_Inhalt.indd`, gegliedert nach Abteilung · Teil, unter jedem Siman die Inhaltsangabe der Mafteachot |

Ablauf in InDesign (Pilot):
1. Übersetzung von Band 01 (Speicher `uebersetzung/sy/` oder Reiter 2) → `rp_uebersetzung.py bauen` →
   `…_Band_01_BILINGUAL_EN_FERTIG.txt` mit 0 FEHLER.
2. Buchmanager Reiter 3 mit der EN_FERTIG-Datei (Band anlegen, Layout, Übersatz beheben).
3. Kolumnentitel-Manager: Reiter 1 Seitenregel „Abschnitt am Seitenanfang“, Analyse; Reiter 2 Vorlage
   „Siman-Überschrift · empfohlen“; „Alle Kolumnentitel erstellen/aktualisieren“, dann „Kolumnentitel prüfen“.
4. Inhaltsverzeichnis-Skript auf dem fertigen Band.

## Übersetzung

- Anweisung: `../Rav_Pealim_VERBINDLICHE_Uebersetzungsanweisung_EN_Fassung1.0_20261107.txt`; Prompt:
  `../PROMPT_Uebersetzung_Rav_Pealim.txt`; feste Wiedergaben: `uebersetzung/KONVENTIONEN.md`.
- Arbeitsliste: `python3 rp_uebersetzung.py liste --band 1 --zeichen 20000` (mit Inhaltsangabe des Mafteach und
  aufgelösten Verweisen auf Rav Pe’alim); Stand: `python3 rp_uebersetzung.py stand`.
- Speicherzeilen `@Volume I, Sod Yesharim 5:3 = …`, Prüffälle `!…`, gesehene PRUEFEN-Zeilen `%…`.
- Nach den ersten Simanim: Länge EN/HE messen und `rp_common.EN_EXPANSION` anpassen (Bandplan neu).

## Tests

`python3 test_rp.py`: Quelle und Zählungen, Sod-Yesharim-Nummerierung, hebräische Zahlen (auch ausgeschriebene
Buchstabennamen des Mafteach), Bandplan (Pilot ein Band, Grenzen, gleichmäßige Teilung, IDs), Abnahme (Fehler
werden erkannt, Titel der Ausgabe geschützt), Mafteach-Zuordnung, Querverweis-Parser, Glossar (Vorrang Kabbala in
Sod Yesharim, Präfixe, KONTEXT, SHEM, Stellenzahl), Werkverzeichnis, Übersetzungsspeicher und Füllen, InDesign
(Generator reproduzierbar, Werte des Buchmanagers, ES3-reservierte Wörter, Kolumnentitel aller 526 Simanim und
Inhaltsverzeichnis in Node ohne ES5-Methoden).
