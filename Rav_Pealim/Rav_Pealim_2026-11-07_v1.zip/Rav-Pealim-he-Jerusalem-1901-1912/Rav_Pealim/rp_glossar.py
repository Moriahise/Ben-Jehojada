# -*- coding: utf-8 -*-
"""
Glossar: Kuerzel (halachisch) und Begriffe (kabbalistisch) fuer die Uebersetzung.

Grundlage ist unveraendert die Ben-Jehojada-Pipeline v3.2.1 (by_parse.find_abbrs,
by_glossary.Glossary aus dem Repository-ZIP) mit der Repository-glossary_he.json – wie
in oyc_glossar.py und lc_glossar.py. Ergaenzt um:
    glossar_halacha.json   Responsen-/Poskim-Kuerzel, die das BY-Glossar nicht kennt
    glossar_kabbala.json   kabbalistische Begriffe (einheitliche Umschrift) und Kuerzel
    Leshon Chakhamim       Gottesnamen-/Kavvanot-Kuerzel (glossar_regeln.json "shem") und die
                           geklaerten Kuerzel der LC-Uebersetzung (uebersetzung/glossar_geklaert.json)
Die glossary_he.json wird nicht veraendert.

Reihenfolge der Aufloesung je Stelle
    SHEM        Gottesnamen-/Kavvanot-Kombination (LC-Regeln): nicht aufloesen
    KABBALA     in Sod Yesharim: Kuerzel aus glossar_kabbala.json (vor dem BY-Glossar, z. B. ת"ת = Tiferet)
    UEBERNOMMEN / ABGELEITET / INLINE / ZAHLWERT   BY-Glossar
    RP / KONTEXT  glossar_halacha.json (KONTEXT: Varianten mit "|", je Stelle entscheiden)
    KABBALA     ausserhalb Sod Yesharim, wenn das BY-Glossar nichts hat
    GEKLAERT·LC in der Uebersetzung von Leshon Chakhamim geklaert
    STELLENZAHL Zahl hinter einer Stellenangabe (סי׳, דף, אות …)
    NEU·RP      nicht aufloesbar: nur bei sicherem Kontext aufloesen, sonst transliterieren + melden

Ausgaben (out/glossar/)
    Rav_Pealim_GLOSSAR.tsv            Uebersetzerhilfe (Kuerzel) mit Status
    Rav_Pealim_Glossar_NEU.json       neue Kuerzel mit Kontexten (he/en leer bis zur Klaerung)
    Rav_Pealim_Glossar_Kabbala.tsv    kabbalistische Begriffe: Umschrift, Treffer in Sod Yesharim / sonst
    Rav_Pealim_Glossar_Bericht.txt
"""
import argparse
import collections
import json
import re
import sys
from pathlib import Path

import rp_common as C

HALACHA = C.HERE / 'glossar_halacha.json'
KABBALA = C.HERE / 'glossar_kabbala.json'
LC_REGELN = C.LC_DIR / 'glossar_regeln.json'
LC_GEKLAERT = C.LC_DIR / 'uebersetzung' / 'glossar_geklaert.json'
GEKLAERT = C.HERE / 'uebersetzung' / 'glossar_geklaert.json'
STATUS = {'curated': 'UEBERNOMMEN', 'context': 'UEBERNOMMEN', 'prefix': 'ABGELEITET', 'letter': 'ABGELEITET',
          'gematria_context': 'ZAHLWERT', 'inline': 'INLINE', 'inline_numeric': 'INLINE', 'stellenzahl': 'STELLENZAHL',
          'shem': 'SHEM', 'rp': 'RP', 'kontext': 'KONTEXT', 'kabbala': 'KABBALA', 'lc': 'GEKLAERT·LC',
          'rp_geklaert': 'GEKLAERT', None: 'NEU·RP'}
RANG = ['UEBERNOMMEN', 'ABGELEITET', 'RP', 'KABBALA', 'GEKLAERT', 'GEKLAERT·LC', 'KONTEXT', 'INLINE', 'ZAHLWERT',
        'STELLENZAHL', 'SHEM', 'NEU·RP']
PRAEFIXE = 'והבלמכשד'
STELLE_VOR = re.compile(r'(?:סי[\'׳]|סימן|דף|ס["״]ק|סעיף|סעי[\'׳]|אות|כלל|פרק|פ[\'׳]|שער|מזמור|ח["״][א-ה]|'
                        r'שאלה|עמוד|ע["״][אבגד]|הלכה|הל[\'׳]|משנה|מ["״]|תשובה|ובסי[\'׳]|ובסימן|בסי[\'׳]|בסימן|'
                        r'שנת|שנה|שנים|בן|בת|יום|ימים|פעמים|פסוק|ד["״]ה|בד["״]ה|חלק|אלף|מאות|סוף|ריש|תחלת|קמא|תנינא)\s*$')
HEB = 'א-ת'


def lade_json(path, leer=None):
    p = Path(path)
    return json.loads(p.read_text(encoding='utf-8')) if p.exists() else (leer if leer is not None else {})


def normtab(d):
    """Schluessel wie by_glossary.norm (Anfuehrungszeichen vereinheitlicht, ohne Nikud)."""
    import by_glossary
    return {by_glossary.norm(k): v for k, v in d.items()}


def mit_praefix(abbr, tab):
    """Eintrag ohne Praefixe ו ה ב ל מ כ ש ד (hoechstens zwei). -> (eintrag, praefix) | (None, '')"""
    import by_glossary
    a = by_glossary.norm(abbr)
    for i in range(0, 3):
        if a[i:] in tab:
            return tab[a[i:]], a[:i]
        if i < len(a) and a[i] not in PRAEFIXE:
            break
    return None, ''


def occ_re(abbr):
    return re.compile(r'(?<![א-ת"״])' + re.escape(abbr) + r'(?![א-ת"״])')


def lade_quellen():
    regeln = lade_json(LC_REGELN, {'shem': []})
    shem = {C.norm_quotes(x) for x in regeln.get('shem', [])}
    halacha = normtab(lade_json(HALACHA)['eintraege'])
    kab = lade_json(KABBALA)
    kab_k = normtab(kab['kuerzel'])
    lc = normtab(lade_json(LC_GEKLAERT, {'eintraege': {}}).get('eintraege', {}))
    lc = {k: v for k, v in lc.items() if v.get('status') in ('GEKLAERT', 'KONTEXT')}
    eigen = normtab(lade_json(GEKLAERT, {'eintraege': {}}).get('eintraege', {}))
    return {'shem': shem, 'halacha': halacha, 'kabbala': kab, 'kabbala_kuerzel': kab_k, 'lc': lc, 'eigen': eigen}


def ist_shem(abbr, shem):
    a = C.norm_quotes(C.strip_nikud(abbr))
    for i in range(0, 3):
        if a[i:] in shem:
            return True
        if i < len(a) and a[i] not in PRAEFIXE:
            break
    return False


def aufloesen(abbr, ctx, vortext, reihe, glossary, q, inline=None):
    """-> (quelle, {'he', 'en'} | None)"""
    import by_glossary
    if ist_shem(abbr, q['shem']):
        return 'shem', None
    e, pfx = mit_praefix(abbr, q['eigen'])
    if e and e.get('status') in ('GEKLAERT', 'KONTEXT'):
        return 'rp_geklaert', e
    if reihe == 'SY':
        e, pfx = mit_praefix(abbr, q['kabbala_kuerzel'])
        if e:
            return 'kabbala', {'he': (pfx + ' + ' if pfx else '') + e['he'], 'en': e['en']}
    r = glossary.resolve(abbr, context=ctx, inline_expansion=inline)
    if r:
        return r['source'], r
    e, pfx = mit_praefix(abbr, q['halacha'])
    if e:
        return ('kontext' if e['status'] == 'KONTEXT' else 'rp'), {'he': (pfx + ' + ' if pfx else '') + e['he'],
                                                                   'en': e['en']}
    e, pfx = mit_praefix(abbr, q['kabbala_kuerzel'])
    if e:
        return 'kabbala', {'he': (pfx + ' + ' if pfx else '') + e['he'], 'en': e['en']}
    e, pfx = mit_praefix(abbr, q['lc'])
    if e:
        return 'lc', {'he': e.get('he', ''), 'en': e.get('en', '')}
    if stellenzahl(glossary, abbr, vortext):
        return 'stellenzahl', None
    return None, None


def stellenzahl(glossary, abbr, vortext):
    import by_glossary
    return bool(STELLE_VOR.search(C.strip_nikud(vortext[-24:])) and glossary._gematria(by_glossary.norm(abbr)))


def sammle(secs, glossary, by_parse, q):
    import by_glossary
    rec = collections.OrderedDict()
    for s in secs:
        for p in s['segmente']:
            text = C.strip_tags(p['he'])
            for x in by_parse.find_abbrs(text):
                key = by_glossary.norm(x['abbr'])
                e = rec.get(key)
                if e is None:
                    v = glossary.idx.get(key)
                    e = rec[key] = {'abbr': key, 'treffer': 0, 'absaetze': [], 'quellen': collections.Counter(),
                                    'he': None, 'en': None, 'alt': (v or {}).get('alt'), 'kontexte': [],
                                    'reihen': collections.Counter()}
                e['absaetze'].append(p['ref'])
                occs = list(occ_re(x['abbr']).finditer(text)) or [None]
                m = occs[0]
                lo, hi = (m.start(), m.end()) if m else (0, len(text))
                ctx = by_parse.strip_tags(text[max(0, lo - 120):hi + 120])
                src, r = aufloesen(x['abbr'], ctx, text[:lo], s['reihe'], glossary, q, x.get('inline_expansion'))
                n = len(occs)
                e['treffer'] += n
                e['reihen'][s['reihe']] += n
                if src in (None, 'stellenzahl') and n > 1:
                    # Zahl oder offen: jede Stelle fuer sich (Stellenzahl nur hinter einer Stellenangabe)
                    for o in occs:
                        e['quellen']['stellenzahl' if stellenzahl(glossary, x['abbr'], text[:o.start()]) else None] += 1
                else:
                    e['quellen'][src] += n
                if r and e['he'] is None:
                    e['he'], e['en'] = r.get('he'), r.get('en')
                if len(e['kontexte']) < 3:
                    e['kontexte'].append('{}: {}'.format(p['ref'], (x.get('context') or '')[:160]))
    return rec


def status_von(e):
    namen = sorted({STATUS.get(k, k) for k in e['quellen']}, key=lambda n: RANG.index(n) if n in RANG else 99)
    return '+'.join(namen)


def begriff_re(formen):
    alt = '|'.join(re.escape(C.norm_quotes(f)) for f in sorted(formen, key=len, reverse=True))
    return re.compile(r'(?<![' + HEB + '"\'])[' + PRAEFIXE + ']{0,2}(?:' + alt + r')(?![' + HEB + '])')


def kabbala_begriffe(secs, kab):
    out = []
    texte = [(s['reihe'], p['ref'], C.norm_quotes(C.strip_nikud(C.strip_tags(p['he'])))) for s in secs for p in s['segmente']]
    for b in kab['begriffe']:
        rx = begriff_re(b['he'])
        sy, rest, abs_sy, erste, kontext = 0, 0, 0, '', ''
        for reihe, ref, t in texte:
            n = 0
            for m in rx.finditer(t):
                n += 1
                if reihe == 'SY' and not kontext:
                    kontext = t[max(0, m.start() - 60):m.end() + 60]
            if not n:
                continue
            if reihe == 'SY':
                sy += n
                abs_sy += 1
                erste = erste or ref
            else:
                rest += n
        out.append({'en': b['en'], 'he': ' / '.join(b['he']), 'kategorie': b['kategorie'],
                    'allgemein': bool(b.get('allgemein')), 'treffer_sy': sy, 'absaetze_sy': abs_sy,
                    'treffer_sonst': rest, 'erste_stelle_sy': erste, 'kontext': kontext})
    return out


def run(glossary_path=None, out='out', pipeline=None, quiet=False, secs=None):
    C.import_pipeline(pipeline)
    import by_glossary
    import by_parse
    gpath = Path(glossary_path or C.GLOSSARY)
    glossary = by_glossary.Glossary(str(gpath))
    graw = json.loads(gpath.read_text(encoding='utf-8'))
    if secs is None:
        secs = C.build_edition(C.load_werk())
    q = lade_quellen()
    rec = sammle(secs, glossary, by_parse, q)
    o = Path(out) / 'glossar'
    o.mkdir(parents=True, exist_ok=True)

    rows = []
    for e in sorted(rec.values(), key=lambda e: (-e['treffer'], e['abbr'])):
        e['status'] = status_von(e)
        rows.append([e['abbr'], e['he'] or '', e['en'] or '', e['status'],
                     ', '.join('{}:{}'.format(k or 'offen', v) for k, v in e['quellen'].most_common()),
                     e['treffer'], len(e['absaetze']), e['absaetze'][0],
                     ', '.join('{} {}'.format(k, v) for k, v in e['reihen'].most_common()), e['reihen'].get('SY', 0),
                     e['alt'] or '', e['kontexte'][0] if e['kontexte'] else ''])
    C.write_tsv(o / (C.WERK_TAG + '_GLOSSAR.tsv'),
                ['abbr', 'hebrew', 'english', 'status', 'mechanismus', 'treffer', 'absaetze', 'erste_stelle', 'reihen',
                 'treffer_sod_yesharim', 'alt_by', 'kontext'], rows)

    neu = collections.OrderedDict()
    for e in sorted(rec.values(), key=lambda e: (-e['quellen'].get(None, 0), e['abbr'])):
        if None not in e['quellen']:
            continue
        neu[e['abbr']] = {'he': '', 'en': '', 'neu': True, 'status': e['status'], 'treffer_offen': e['quellen'][None],
                          'treffer': e['treffer'], 'reihen': dict(e['reihen']), 'stellen': e['absaetze'][:8],
                          'kontexte': e['kontexte']}
    meta = {'werk': C.WERK_EN, 'basis_glossar': gpath.name, 'basis_glossar_sha256': C.sha256_file(gpath),
            'basis_eintraege': len(graw.get('abbreviations', {})),
            'pipeline': 'ben-yehoyada-pipeline v3.2.1 (by_parse.find_abbrs, by_glossary.Glossary)',
            'ergaenzungen': {'halacha': {'datei': HALACHA.name, 'eintraege': len(q['halacha'])},
                             'kabbala': {'datei': KABBALA.name, 'kuerzel': len(q['kabbala_kuerzel']),
                                         'begriffe': len(q['kabbala']['begriffe'])},
                             'lc_shem': len(q['shem']), 'lc_geklaert': len(q['lc']), 'rp_geklaert': len(q['eigen'])},
            'hinweis': 'he/en der neuen Kuerzel erst nach Beleg in uebersetzung/glossar_geklaert.json eintragen '
                       '(Anweisung RP 1.0, Regel 43); Uebernahme in glossary_he.json entscheidet die Projektleitung.'}
    C.write_json(o / (C.WERK_TAG + '_Glossar_NEU.json'), {'_meta': meta, 'neu': neu})

    kb = kabbala_begriffe(secs, q['kabbala'])
    C.write_tsv(o / (C.WERK_TAG + '_Glossar_Kabbala.tsv'),
                ['english', 'hebrew', 'kategorie', 'allgemeinsprachlich', 'treffer_sod_yesharim', 'absaetze_sod_yesharim',
                 'treffer_sonst', 'erste_stelle_sod_yesharim', 'kontext'],
                [[b['en'], b['he'], b['kategorie'], 'ja' if b['allgemein'] else '', b['treffer_sy'], b['absaetze_sy'],
                  '' if b['allgemein'] else b['treffer_sonst'], b['erste_stelle_sy'], b['kontext']] for b in kb])

    tot = sum(e['treffer'] for e in rec.values())
    by_src = collections.Counter()
    for e in rec.values():
        by_src.update({STATUS.get(k, k): v for k, v in e['quellen'].items()})
    aufgeloest = tot - by_src.get('NEU·RP', 0) - by_src.get('STELLENZAHL', 0) - by_src.get('SHEM', 0)
    tot_sy = sum(e['reihen'].get('SY', 0) for e in rec.values())
    neu_sy = sum(v['reihen'].get('SY', 0) for v in neu.values())
    L = ['RAV PE’ALIM · GLOSSAR (BASIS: BEN JEHOJADA + RP-HALACHA + KABBALA + LESHON CHAKHAMIM)', '',
         'Glossar: {} · {} Eintraege · sha256 {}'.format(gpath.name, meta['basis_eintraege'], meta['basis_glossar_sha256']),
         'Pipeline: ' + meta['pipeline'],
         'Ergaenzungen: {} ({} Kuerzel) · {} ({} Kuerzel, {} Begriffe) · LC: {} SHEM-Formen, {} geklaerte Kuerzel'.format(
             HALACHA.name, len(q['halacha']), KABBALA.name, len(q['kabbala_kuerzel']), len(q['kabbala']['begriffe']),
             len(q['shem']), len(q['lc'])), '',
         'Kuerzel (Gershajim) gesamt: {} Treffer · {} verschiedene'.format(tot, len(rec)),
         'aufgeloest (BY, RP, Kabbala, LC, Kontext): {} Treffer = {:.1f} %'.format(aufgeloest, 100.0 * aufgeloest / tot if tot else 0),
         'nach Mechanismus: ' + ', '.join('{} {}'.format(k, v) for k, v in by_src.most_common()),
         'Sod Yesharim (Pilot): {} Treffer, davon offen (NEU·RP) {}'.format(tot_sy, neu_sy), '',
         'NEUE KUERZEL (NEU·RP), haeufigste 60 (Treffer offen · Reihen · erste Stelle):']
    for k, v in list(neu.items())[:60]:
        L.append('  {:>5}  {:<12} {:<32} {}'.format(v['treffer_offen'], k,
                                                   ' '.join('{} {}'.format(a, b) for a, b in sorted(v['reihen'].items())),
                                                   v['stellen'][0]))
    L += ['  … insgesamt {} neue Formen; vollstaendig in {}_Glossar_NEU.json'.format(len(neu), C.WERK_TAG), '',
          'KABBALISTISCHE BEGRIFFE IN SOD YESHARIM (glossar_kabbala.json, Umschrift nach Regel 30; * = auch Allgemeinsprache):']
    for b in sorted(kb, key=lambda b: -b['treffer_sy'])[:40]:
        L.append('  {:>5} {} {:<44} {}'.format(b['treffer_sy'], '*' if b['allgemein'] else ' ', b['en'][:44], b['he'][:40]))
    txt = '\n'.join(L) + '\n'
    (o / (C.WERK_TAG + '_Glossar_Bericht.txt')).write_text(txt, encoding='utf-8')
    if not quiet:
        print(txt)
    return {'treffer': tot, 'aufgeloest': aufgeloest, 'verschieden': len(rec), 'neu': len(neu),
            'treffer_sy': tot_sy, 'neu_sy': neu_sy, 'nach_mechanismus': dict(by_src), 'bericht': txt,
            'glossar_sha256': meta['basis_glossar_sha256'], 'glossar_eintraege': meta['basis_eintraege'],
            'kabbala_begriffe': len(kb), 'kabbala_treffer_sy': sum(b['treffer_sy'] for b in kb), 'meta': meta}


def main(argv=None):
    ap = argparse.ArgumentParser(description='Rav Pe’alim – Glossar (halachisch und kabbalistisch)')
    ap.add_argument('--glossary', default=str(C.GLOSSARY))
    ap.add_argument('--pipeline', default=str(C.PIPELINE_ZIP))
    ap.add_argument('--out', default=str(C.HERE / 'out'))
    a = ap.parse_args(argv)
    run(a.glossary, a.out, a.pipeline)
    return 0


if __name__ == '__main__':
    sys.exit(main())
