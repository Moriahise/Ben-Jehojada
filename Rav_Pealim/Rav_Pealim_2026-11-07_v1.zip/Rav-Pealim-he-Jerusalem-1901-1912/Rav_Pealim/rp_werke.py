# -*- coding: utf-8 -*-
"""
Werkverzeichnis der Zitatketten: zitierte Werke und Autoritaeten mit einheitlicher
englischer Wiedergabe (werke_zitiert.json), Haeufigkeit je Reihe, und die Absaetze mit den
dichtesten Zitatketten (viele verschiedene Werke in einem Absatz) als Hinweis fuer die
Uebersetzung (Anweisung RP 1.0, Regel 39: Zitatketten vollstaendig, Werke einheitlich).

Gezaehlt wird die Form mit bis zu zwei Praefixen ו ה ב ל מ כ ש ד; mehrdeutige Formen
(ט"ז auch 16) sind in werke_zitiert.json markiert.

Ausgaben (out/werke/)
    Rav_Pealim_Werkverzeichnis.tsv      Werk, Formen, Kategorie, Treffer gesamt / je Reihe, erste Stelle
    Rav_Pealim_Werkverzeichnis.md       Uebersicht und dichteste Zitatketten (je Reihe die 15 dichtesten Absaetze)
"""
import argparse
import collections
import json
import re
import sys
from pathlib import Path

import rp_common as C

WERKE = C.HERE / 'werke_zitiert.json'
PRAEFIXE = 'והבלמכשד'


def lade():
    return json.loads(WERKE.read_text(encoding='utf-8'))


def form_re(formen):
    alt = '|'.join(re.escape(C.norm_quotes(f)) for f in sorted(formen, key=len, reverse=True))
    return re.compile(r'(?<![א-ת"\'])[' + PRAEFIXE + r']{0,2}(?:' + alt + r')(?![א-ת"])')


def run(out='out', quiet=False, secs=None, reihen=None):
    d = lade()
    if secs is None:
        secs = C.build_edition(C.load_werk())
    reihen = reihen or [r['key'] for r in C.lade_gliederung()['reihen']]
    rx = [(w, form_re(w['he'])) for w in d['werke']]
    zaehl = {w['en']: collections.Counter() for w in d['werke']}
    erste = {}
    dicht = collections.defaultdict(list)
    for s in secs:
        for p in s['segmente']:
            t = C.norm_quotes(C.strip_nikud(C.strip_tags(p['he'])))
            gefunden = []
            for w, r in rx:
                n = len(r.findall(t))
                if n:
                    zaehl[w['en']][s['reihe']] += n
                    erste.setdefault(w['en'], p['ref'])
                    if w['kategorie'] != 'Autor':
                        gefunden.append(w['en'])
            if len(gefunden) >= 4:
                dicht[s['reihe']].append((len(gefunden), p['ref'], gefunden))
    o = Path(out) / 'werke'
    rows = []
    for w in d['werke']:
        c = zaehl[w['en']]
        rows.append([w['en'], ' / '.join(w['he']), w['kategorie'], sum(c.values())] + [c.get(r, 0) for r in reihen] +
                    [erste.get(w['en'], ''), w.get('mehrdeutig', '')])
    C.write_tsv(o / (C.WERK_TAG + '_Werkverzeichnis.tsv'),
                ['werk_en', 'formen_he', 'kategorie', 'treffer'] + ['treffer_' + r for r in reihen] +
                ['erste_stelle', 'mehrdeutig'], rows)
    L = ['# Rav Pe’alim · Werkverzeichnis der Zitatketten', '',
         'Einheitliche englische Wiedergabe für die Übersetzung (Regel 31/39); Formen und Zählung in '
         '`{}_Werkverzeichnis.tsv`. Grundlage: `werke_zitiert.json` ({} Werke).'.format(C.WERK_TAG, len(d['werke'])), '',
         '| Werk (EN) | Kategorie | Treffer | ' + ' | '.join(reihen) + ' |', '|---|---|---:|' + '---:|' * len(reihen)]
    for r in sorted(rows, key=lambda r: -r[3]):
        if r[3]:
            L.append('| {} | {} | {} | '.format(r[0], r[2], r[3]) + ' | '.join(str(x) for x in r[4:4 + len(reihen)]) + ' |')
    L += ['', '## Dichteste Zitatketten (Absätze mit mindestens 4 verschiedenen Werken)', '']
    for r in reihen:
        liste = sorted(dicht.get(r, []), key=lambda x: -x[0])[:15]
        L += ['### {} ({} Absätze mit ≥ 4 Werken)'.format(r, len(dicht.get(r, []))), '']
        L += ['- `{}`: {} Werke – {}'.format(ref, n, ', '.join(g)) for n, ref, g in liste] or ['- keine']
        L.append('')
    (o / (C.WERK_TAG + '_Werkverzeichnis.md')).write_text('\n'.join(L) + '\n', encoding='utf-8')
    res = {'werke': len(d['werke']), 'zitiert': sum(1 for r in rows if r[3]), 'treffer': sum(r[3] for r in rows),
           'zitatketten': {r: len(dicht.get(r, [])) for r in reihen}}
    if not quiet:
        print('Werkverzeichnis: {} Werke, {} zitiert, {} Treffer · Zitatketten (≥ 4 Werke): {}'.format(
            res['werke'], res['zitiert'], res['treffer'], res['zitatketten']))
    return res


def main(argv=None):
    ap = argparse.ArgumentParser(description='Rav Pe’alim – Werkverzeichnis der Zitatketten')
    ap.add_argument('--out', default=str(C.HERE / 'out'))
    a = ap.parse_args(argv)
    run(a.out)
    return 0


if __name__ == '__main__':
    sys.exit(main())
