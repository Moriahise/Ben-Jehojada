# -*- coding: utf-8 -*-
"""
Konkordanz Teil/Abteilung/Siman des Drucks ↔ Band/Laufnummer/Segment-IDs der Ausgabe,
und die Querverweise des Autors auf Rav Pe'alim selbst.

Konkordanz (je Siman, Hakdama, Kuntres eine Zeile)
    reihe, band, lauf (Sod Yesharim 1–64; sonst Folge in der Reihe), Teil/Abteilung/Siman des Drucks,
    Sefaria-Ref, Titel HE/EN der Ausgabe, erste/letzte Segment-ID, Zeichen, Seitenanteil,
    Inhaltsangabe aus dem Mafteach des Drucks (rp_struktur.py)

Querverweise ("רב פעלים" + Teil + [Abteilung] + Siman/Sche'elah im Text)
    AUFGELOEST    Teil, Abteilung und Siman genannt; Ziel in der Ausgabe gefunden
    ANGENOMMEN    Abteilung nicht genannt: Abteilung des zitierenden Siman angenommen (pruefen)
    OHNE_SIMAN    nur Teil (z. B. Werktitel in den Hakdamot) oder "הנז'"; keine Zuordnung
    OHNE_TEIL     Siman ohne lesbaren Teil (Druckfehler wie "ת"א") – pruefen
    ZIEL_FEHLT    genannter Siman nicht vorhanden (Druckfehler oder anderes Werk) – pruefen
Jede Zeile nennt das Ziel in der Ausgabe (Band, Titel, erste Segment-ID), damit die
Uebersetzung den Verweis auf die Zaehlung des Drucks UND der Ausgabe stellen kann
(Uebersetzungsanweisung, Regel 40).

Ausgaben (out/konkordanz/)
    Rav_Pealim_Konkordanz.tsv
    Rav_Pealim_Konkordanz.md
    Rav_Pealim_Querverweise.tsv
"""
import argparse
import collections
import math
import re
import sys
from pathlib import Path

import rp_bandplan as B
import rp_common as C
import rp_struktur as ST

RP_RE = re.compile(r'רב\s*פעלים')
# Teilangabe unmittelbar nach "רב פעלים" (sonst gehoert ein spaeteres ח"ג zu einem anderen Werk)
TEIL_RE = re.compile(r'^\s*(?:ח["״]|חלק\s+)(ראשון|שני|שלישי|רביעי|[אבגד](?![א-ת]))')
TEIL_WORT = {'א': 1, 'ב': 2, 'ג': 3, 'ד': 4, 'ראשון': 1, 'שני': 2, 'שלישי': 3, 'רביעי': 4}
SIMAN_RE = re.compile(r'(?:\bב?סי[\'׳]|\bב?סימן|\bשאלה|(?<![א-ת])ס["״](?=[א-ת](?![א-ת])))\s*([א-ת]{1,4}(?:["״][א-ת])?[\'׳]?|[א-ת]["״][א-ת])')
STOP_RE = re.compile(r'[():;]|רב\s*פעלים')


def abteilung_in(text, gl):
    """Erste genannte Abteilung im Fenster (laengste Form zuerst)."""
    treffer = []
    for name, a in gl['abteilungen'].items():
        for k in sorted(a['kuerzel'] + [a['he']], key=len, reverse=True):
            for form in {k, k.replace('"', '״')}:
                i = text.find(form)
                if i >= 0:
                    treffer.append((i, -len(form), name))
    return min(treffer)[2] if treffer else None


def lies_verweis(fenster, gl):
    """-> {'teil', 'abteilung', 'siman', 'siman_druck', 'text'} aus dem Text nach 'רב פעלים'."""
    m = STOP_RE.search(fenster)
    f = fenster[:m.start()] if m else fenster
    t = TEIL_RE.search(f)
    teil = TEIL_WORT[t.group(1)] if t else None
    rest = f[t.end():] if t else f
    s = SIMAN_RE.search(rest[:45])
    if s and not t and s.start() > 25:
        s = None                         # Siman weit hinter "רב פעלים" ohne Teil: anderes Werk
    siman = C.zahlwert(s.group(1)) if s else None
    abt = abteilung_in(rest[:s.start()] if s else rest, gl)
    return {'teil': teil, 'abteilung': abt, 'siman': siman, 'siman_druck': s.group(0).strip() if s else '',
            'text': f.strip()}


def querverweise(werk, gl, ziele):
    """ziele: {(teil_key, abteilung, siman): konkordanzzeile}"""
    out = []
    for t, bereich, sim, p in C.iter_absaetze(werk):
        k = C.klartext(p['html'])
        for m in RP_RE.finditer(k):
            v = lies_verweis(k[m.end():m.end() + 90], gl)
            teil_key = C.TEILE[v['teil'] - 1] if v['teil'] else None
            abt, status = v['abteilung'], ''
            if not v['siman']:
                status = 'OHNE_SIMAN'
            elif not teil_key:
                status = 'OHNE_TEIL'
                abt = abt or (bereich if bereich in gl['abteilungen'] else None)
            else:
                if not abt:
                    abt = bereich if bereich in gl['abteilungen'] else None
                    status = 'ANGENOMMEN'
                z = ziele.get((teil_key, abt, v['siman']))
                status = (status or 'AUFGELOEST') if z else 'ZIEL_FEHLT'
            z = ziele.get((teil_key, abt, v['siman'])) if status in ('AUFGELOEST', 'ANGENOMMEN') else None
            out.append({'stelle': p['ref'], 'kontext': k[max(0, m.start() - 40):m.end() + 70],
                        'teil': teil_key or '', 'abteilung': abt or '', 'siman': v['siman'] or '',
                        'angabe': ('רב פעלים ' + v['text'])[:80], 'status': status,
                        'band': z['band'] if z else '', 'ziel_titel_en': z['en_title'] if z else '',
                        'ziel_titel_he': z['he_title'] if z else '', 'ziel_id': z['erste_id'] if z else ''})
    return out


def run(out='out', quiet=False, plan=None, struktur=None):
    werk, gl, secs, segs, vols = plan or B.plan()
    st = struktur or ST.run(out, quiet=True)
    maf = st['mafteach']
    band_von = {}
    for v in vols:
        for s in v['segments']:
            band_von[s['id']] = v
    zeilen = []
    for s in secs:
        ids = [x for x in segs if x['abschnitt'] == s['nr']]
        v = band_von[ids[0]['id']]
        he = sum(x['plan_chars'] for x in ids)
        zeilen.append({
            'reihe': s['reihe'], 'band': '{:02d}'.format(v['number']),
            'band_in_reihe': '{}/{}'.format(v['reihe_band'], v['reihe_baende']), 'lauf': s['lauf'] or '',
            'teil': s['teil'], 'abteilung': s['bereich'], 'siman_druck': s['siman'] or '',
            'siman_druck_he': C.hebr_zahl_g(s['siman']) if s['siman'] else '',
            'quelle_ref': s['quelle_ref'], 'sefaria_ref': '{}, {}'.format(C.SEFARIA_TITEL, s['quelle_ref']),
            'he_title': s['he_title'], 'en_title': s['en_title'], 'erste_id': ids[0]['id'], 'letzte_id': ids[-1]['id'],
            'segmente': len(ids), 'he_konsonanten': he,
            'seiten_ca': '{:.1f}'.format(he * C.EN_EXPANSION / C.EN_CHARS_PER_PAGE),
            'mafteach': maf.get(s['quelle_ref'], {}).get('inhalt', '')})
    ziele = {(z['teil'], z['abteilung'], z['siman_druck']): z for z in zeilen if z['siman_druck']}
    qv = querverweise(werk, gl, ziele)

    o = Path(out) / 'konkordanz'
    kopf = ['reihe', 'band', 'band_in_reihe', 'lauf', 'teil', 'abteilung', 'siman_druck', 'siman_druck_he',
            'quelle_ref', 'sefaria_ref', 'he_title', 'en_title', 'erste_id', 'letzte_id', 'segmente',
            'he_konsonanten', 'seiten_ca', 'mafteach']
    C.write_tsv(o / (C.WERK_TAG + '_Konkordanz.tsv'), kopf, [[z[k] for k in kopf] for z in zeilen])
    qkopf = ['stelle', 'status', 'teil', 'abteilung', 'siman', 'band', 'ziel_titel_en', 'ziel_titel_he', 'ziel_id',
             'angabe', 'kontext']
    C.write_tsv(o / (C.WERK_TAG + '_Querverweise.tsv'), qkopf, [[q[k] for k in qkopf] for q in qv])

    status = collections.Counter(q['status'] for q in qv)
    L = ['# Rav Pe’alim · Konkordanz Druck ↔ Ausgabe', '',
         'Erzeugt mit `rp_konkordanz.py`. Vollständige Tabelle: `{}_Konkordanz.tsv` ({} Zeilen); '
         'Querverweise des Autors: `{}_Querverweise.tsv`.'.format(C.WERK_TAG, len(zeilen), C.WERK_TAG), '',
         '## Bände', '', '| Band | Reihe | Inhalt (Druck) | Seiten ca. | Segmente |', '|---|---|---|---:|---|']
    for v in vols:
        teile = collections.OrderedDict()
        for z in [z for z in zeilen if z['band'] == '{:02d}'.format(v['number'])]:
            teile.setdefault((z['teil'], z['abteilung']), []).append(z['siman_druck'])
        inhalt = '; '.join('{} {} {}–{}'.format(a, C.ROEMISCH[t], min(x), max(x)) if x[0] else '{} ({})'.format(
            a, C.ROEMISCH[t]) for (t, a), x in teile.items())
        L.append('| {:02d} | {} | {} | {} | {}–{} |'.format(
            v['number'], v['reihe'], inhalt, v['estimated_pages'], v['segments'][0]['id'], v['segments'][-1]['id']))
    L += ['', '## Sod Yesharim (Band 01, Pilot) · Zählung der Ausgabe ↔ Druck', '',
          '| Ausgabe | Druck | Sefaria | Segmente | Inhalt (Mafteach des Drucks) |', '|---:|---|---|---|---|']
    for z in [z for z in zeilen if z['reihe'] == 'SY']:
        L.append('| {} | {} Teil {} Siman {} | {} | {}–{} | {} |'.format(
            z['lauf'], C.WERK_HE, C.ROEMISCH[z['teil']], z['siman_druck'], z['quelle_ref'], z['erste_id'],
            z['letzte_id'], z['mafteach'][:110] or '–'))
    L += ['', '## Querverweise auf Rav Pe’alim', '',
          'Gefunden: {} · {}'.format(len(qv), ', '.join('{} {}'.format(k, v) for k, v in sorted(status.items()))), '',
          '| Stelle | Status | Angabe | Ziel in der Ausgabe |', '|---|---|---|---|']
    for q in qv:
        L.append('| {} | {} | {} | {} |'.format(q['stelle'], q['status'], q['angabe'].replace('|', '/'),
                                                 'Band {} · {} · {}'.format(q['band'], q['ziel_titel_en'], q['ziel_id'])
                                                 if q['band'] else '–'))
    md = '\n'.join(L) + '\n'
    (o / (C.WERK_TAG + '_Konkordanz.md')).write_text(md, encoding='utf-8')
    if not quiet:
        print('Konkordanz: {} Zeilen · Querverweise: {} ({})'.format(
            len(zeilen), len(qv), ', '.join('{} {}'.format(k, v) for k, v in sorted(status.items()))))
    return {'zeilen': zeilen, 'querverweise': qv, 'status': dict(status), 'ziele': ziele}


def main(argv=None):
    ap = argparse.ArgumentParser(description='Rav Pe’alim – Konkordanz und Querverweise')
    ap.add_argument('--out', default=str(C.HERE / 'out'))
    a = ap.parse_args(argv)
    run(a.out)
    return 0


if __name__ == '__main__':
    sys.exit(main())
