// Bausteine fuer den Rav-Pe’alim-Kolumnentitel-Manager (uebernommen aus Leshon Chakhamim RH v1.0.4)
// (Kolumnentitel = Abschnittsueberschrift der Seite statt Gruppe).
// indesign/erzeuge_rp_jsx.py setzt jeden Block "//@@ NAME" in das aus dem
// Ben-Ish-Chai-Skript erzeugte Script ein: ERSETZE <funktion> tauscht die
// gleichnamige Funktion vollstaendig aus, EINFUEGEN steht vor
// "function buildParashahCatalogue(){". /*@ABSCHNITTE@*/ = Katalog aus der Pipeline.
// ExtendScript (ES3): kein JSON, keine Array-Methoden ausser push/slice/join/sort,
// kein String.trim; reservierte Woerter wie short, long, int, char, class, final,
// native, package, public, static, super, goto auch nicht als Eigenschaftsname.

//@@ EINFUEGEN
    // =====================================================================
    // Rav Pe’alim (wie Leshon Chakhamim v1.0.1): Kolumnentitel = Abschnittsueberschrift
    // =====================================================================

    function normalizeSectionEn(s){
        // Rav Pe’alim: Siman-Titel unterscheiden sich nur durch Zahlen ("Siman 13") – Ziffern bleiben
        // erhalten (normalizeEnglishWords des Ben-Ish-Chai-Skripts entfernt sie).
        s=cleanHeadingText(s).toLowerCase();
        s=s.replace(/[^a-z0-9]+/g," ").replace(/\s+/g," ");
        return trim(s);
    }

    function buildSectionCatalogue(){
        // [hebraeischer Titel, englischer Titel, HE-Kurztitel, EN-Kurztitel, Gruppe] in Werkfolge;
        // erzeugt aus der Pipeline (rp_common.build_edition: Titel und Kurztitel je Siman)
        var a=[
/*@ABSCHNITTE@*/
        ];
        var out=[],i;
        for(i=0;i<a.length;i++){
            out.push({index:i,he:a[i][0],en:a[i][1],heShort:a[i][2]||"",enShort:a[i][3]||"",group:a[i][4]||"",
                      heKey:normalizeHebrewWords(a[i][0]),enKey:normalizeSectionEn(a[i][1]),enAlias:[]});
        }
        return out;
    }

    function groupByKey(k){
        var i;
        for(i=0;i<PARASHOT.length;i++)if(PARASHOT[i].key===k)return PARASHOT[i];
        return null;
    }

    function sectionKeyMatches(s,key,isHebrew){
        var i;
        if(isHebrew)return s.heKey===key;
        if(s.enKey===key)return true;
        for(i=0;i<s.enAlias.length;i++)if(s.enAlias[i]===key)return true;
        return false;
    }

    function matchSection(text,isHebrew,cursor){
        // Vollstaendige Gleichheit (normalisiert); gleichlautende Titel in Werkfolge ab cursor
        var key=isHebrew?normalizeHebrewWords(text):normalizeSectionEn(text),i;
        if(!key)return null;
        cursor=cursor||0;
        for(i=cursor;i<SECTIONS.length;i++)if(sectionKeyMatches(SECTIONS[i],key,isHebrew))return SECTIONS[i];
        for(i=0;i<cursor&&i<SECTIONS.length;i++)if(sectionKeyMatches(SECTIONS[i],key,isHebrew))return SECTIONS[i];
        return null;
    }

    function parseSourceSections(raw){
        var re=/<section>\s*<he_title>([\s\S]*?)<\/he_title>\s*<en_title>([\s\S]*?)<\/en_title>\s*<\/section>/ig,m,out=[];
        while((m=re.exec(raw))!==null){
            out.push({he:cleanHeadingText(restoreCdata(xmlUnescape(m[1]))),en:cleanHeadingText(restoreCdata(xmlUnescape(m[2])))});
        }
        return out;
    }

    function registerSourceAliases(entries){
        // Englische Titel der Banddatei, die vom Katalog abweichen (spaeter geaenderte Uebersetzung),
        // werden dem ueber den hebraeischen Titel gefundenen Abschnitt als Alias zugeordnet.
        var cursor=0,i,s,k,n=0;
        for(i=0;i<entries.length;i++){
            s=matchSection(entries[i].he,true,cursor);
            if(!s)continue;
            cursor=s.index+1;
            k=normalizeSectionEn(entries[i].en);
            if(k&&!sectionKeyMatches(s,k,false)){s.enAlias.push(k);n++;}
        }
        return n;
    }

    function paragraphAtFrameTop(p){
        // true, wenn vor der Ueberschrift im selben Textrahmen nur Leerraum steht
        try{
            var ip=p.insertionPoints[0],frames=ip.parentTextFrames;
            if(!frames||!frames.length)return false;
            var start=frames[0].insertionPoints[0].index,idx=ip.index;
            if(idx<=start)return true;
            var before=p.parentStory.characters.itemByRange(start,idx-1).contents;
            if(before instanceof Array)before=before.join("");
            return !trim(String(before).replace(/[\r\n\u2028\u2029\u200B\uFEFF]/g," "));
        }catch(_){return false;}
    }

    function buildSectionStarts(headings,isHebrew){
        var out=[],cursor=0,i,h,s,g;
        for(i=0;i<headings.length;i++){
            h=headings[i];
            s=matchSection(h.text,isHebrew,cursor);
            if(s)cursor=s.index+1;
            g=s?groupByKey(s.group):null;
            out.push({pageIndex:h.pageIndex,pageName:h.pageName,textIndex:h.textIndex,atTop:!!h.atTop,
                      title:h.text,kurzTitel:s?(isHebrew?s.heShort:s.enShort):"",
                      otherTitle:s?(isHebrew?s.en:s.he):"",otherShort:s?(isHebrew?s.enShort:s.heShort):"",
                      groupHe:g?g.he:"",groupEn:g?g.en:"",matched:!!s,
                      detection:(isHebrew?"HE":"EN")+(s?" · Katalog":" · nicht im Katalog")});
        }
        return out;
    }

    function mirrorStarts(starts){
        // Fallback, wenn eine Sprache keine Ueberschriften hat: Titel der anderen Sprache ueber den Katalog
        var out=[],i,s;
        for(i=0;i<starts.length;i++){
            s=starts[i];
            out.push({pageIndex:s.pageIndex,pageName:s.pageName,textIndex:s.textIndex,atTop:s.atTop,
                      title:s.otherTitle,kurzTitel:s.otherShort,otherTitle:s.title,otherShort:s.kurzTitel,
                      groupHe:s.groupHe,groupEn:s.groupEn,matched:s.matched,detection:s.detection+" (gespiegelt)"});
        }
        return out;
    }

    function sectionForPage(starts,p,rule){
        // rule 0: Abschnitt am Seitenanfang - beginnt oben auf der Seite eine Ueberschrift, gilt sie,
        //         sonst der Abschnitt, der von der Vorseite weiterlaeuft
        // rule 1: erste auf der Seite beginnende Ueberschrift, sonst der weiterlaufende Abschnitt
        // rule 2: letzte Ueberschrift der Seite, sonst der weiterlaufende Abschnitt
        var before=null,first=null,last=null,i,s;
        for(i=0;i<starts.length;i++){
            s=starts[i];
            if(s.pageIndex<p)before=s;
            else if(s.pageIndex===p){if(!first)first=s;last=s;}
            else break;
        }
        if(rule===1){if(first)return {s:first,start:true};return before?{s:before,start:false}:null;}
        if(rule===2){if(last)return {s:last,start:true};return before?{s:before,start:false}:null;}
        if(first&&first.atTop)return {s:first,start:true};
        if(before)return {s:before,start:false};
        if(first)return {s:first,start:true};
        return null;
    }

    function pageRuleLabel(r){return r===1?"erste Überschrift der Seite":(r===2?"letzte Überschrift der Seite":"Abschnitt am Seitenanfang");}

    function headerTitle(info,lang,useShort){
        var full=lang==="en"?info.enTitle:info.heTitle,sh=lang==="en"?info.enShort:info.heShort;
        return String((useShort&&sh)?sh:(full||""));
    }

    function shortenWords(title,keep){
        // wortweise kuerzen und Auslassungszeichen setzen (letzter Ausweg bei Platzmangel)
        var w=trim(title).split(/\s+/),out;
        if(keep>=w.length)return trim(title);
        if(keep<1)keep=1;
        out=w.slice(0,keep).join(" ").replace(/[\s·:;,.\-–—(]+$/,"");
        return out+"…";
    }

    function templateShowsSection(cfg,lang){
        var t=lang==="en"?cfg.enTemplate:cfg.heTemplate;
        return t.indexOf("{ABSCHNITT")>=0||t.indexOf("{PARASHAH")>=0;
    }

    function headerMatchesTitle(txt,info,lang){
        // Kolumnentitel passt zur Ueberschrift: voller Titel, Kurztitel oder dessen gekuerzter Anfang
        var full=headerTitle(info,lang,false),sh=headerTitle(info,lang,true),cut,k,d;
        txt=String(txt||"");
        if(full&&txt.indexOf(full)>=0)return true;
        if(sh&&txt.indexOf(sh)>=0)return true;
        k=txt.lastIndexOf("…");
        if(k>0){
            cut=txt.substring(0,k);d=cut.lastIndexOf("· ");if(d>=0)cut=cut.substring(d+2);
            cut=trim(cut);
            if(cut&&(full.indexOf(cut)===0||(sh&&sh.indexOf(cut)===0)))return true;
        }
        return false;
    }

    // ---------------------------------------------------------------------
    // v1.0.3: Kopfrahmen neutral setzen, nie mit Ausnahme abbrechen
    // ---------------------------------------------------------------------

    function resetHeaderText(doc,tf,t){
        // Ein neuer oder alter Kopfrahmen erbt sonst Absatz- und Zeichenformat des Dokuments
        // (Grundlinienraster, Einzuege, "Absatzbeginn: naechster Rahmen", Aufzaehlung,
        // Versalien, kein Umbruch ...). Dann laeuft selbst ein einzelnes Wort ueber.
        var basic=null,k,para,chr,frm;
        try{basic=doc.paragraphStyles.item("$ID/NormalParagraphStyle");if(!basic.isValid)basic=null;}catch(_){basic=null;}
        if(!basic){try{basic=doc.paragraphStyles[1];}catch(_){basic=null;}}
        try{if(basic)t.applyParagraphStyle(basic,true);}catch(_){}
        try{t.applyCharacterStyle(doc.characterStyles[0],true);}catch(_){}
        para={leftIndent:0,rightIndent:0,firstLineIndent:0,lastLineIndent:0,spaceBefore:0,spaceAfter:0,
              alignToBaseline:false,keepWithNext:0,keepLinesTogether:false,ruleAbove:false,ruleBelow:false,
              dropCapCharacters:0,dropCapLines:0,paragraphShadingOn:false,paragraphBorderOn:false};
        chr={horizontalScale:100,verticalScale:100,baselineShift:0,skew:0,noBreak:false,
             underline:false,strikeThru:false};
        for(k in para){try{t[k]=para[k];}catch(_){}}
        for(k in chr){try{t[k]=chr[k];}catch(_){}}
        try{t.startParagraph=StartParagraph.ANYWHERE;}catch(_){}
        try{t.bulletsAndNumberingListType=ListType.NO_LIST;}catch(_){}
        try{t.spanColumnType=SpanColumnTypeOptions.SINGLE_COLUMN;}catch(_){}
        try{t.capitalization=Capitalization.NORMAL;}catch(_){}
        try{t.position=Position.NORMAL;}catch(_){}
        frm=null;
        try{frm=tf.textFramePreferences;}catch(_){}
        if(frm){
            try{frm.textColumnCount=1;}catch(_){}
            try{frm.autoSizingType=AutoSizingTypeEnum.OFF;}catch(_){}
            try{frm.firstBaselineOffset=FirstBaseline.ASCENT_OFFSET;}catch(_){}
            try{frm.minimumFirstBaselineOffset=0;}catch(_){}
        }
    }

    function headerFrameUsable(tf){
        // verkettete Kopfrahmen (Text laeuft in einen anderen Rahmen) werden neu angelegt
        try{if(tf.previousTextFrame&&tf.previousTextFrame.isValid)return false;}catch(_){}
        try{if(tf.nextTextFrame&&tf.nextTextFrame.isValid)return false;}catch(_){}
        try{if(tf.parentStory.textContainers.length>1)return false;}catch(_){}
        return true;
    }

    function rund1(x){return String(Math.round(Number(x)*10)/10).replace(".",",");}

    function headerDiagnosis(tf){
        // Warum der Kopfrahmen nicht passt (fuer den Bericht)
        var d=[],t,b,n;
        try{if(tf.overflows)d.push("Übersatz");}catch(_){}
        try{n=tf.parentStory.lines.length;if(n>1)d.push(n+" Zeilen");}catch(_){}
        try{if(!headerFrameUsable(tf))d.push("Rahmen verkettet");}catch(_){}
        try{b=tf.geometricBounds;d.push("Rahmen "+rund1(b[3]-b[1])+" × "+rund1(b[2]-b[0]));}catch(_){}
        try{
            t=tf.texts[0];
            try{d.push("Absatzformat „"+t.appliedParagraphStyle.name+"“");}catch(_){}
            try{d.push(rund1(t.pointSize)+" pt");}catch(_){}
            try{if(t.alignToBaseline)d.push("am Grundlinienraster");}catch(_){}
            try{if(t.leftIndent||t.rightIndent||t.firstLineIndent)d.push("Einzüge "+rund1(t.leftIndent)+"/"+rund1(t.rightIndent)+"/"+rund1(t.firstLineIndent));}catch(_){}
        }catch(_){}
        return d.join(", ");
    }

//@@ ERSETZE analyzeDocument
    function analyzeDocument(doc, cfg) {
        // Rav Pe’alim (wie Leshon Chakhamim v1.0.1): Ueberschriften je Sprache aus dem eigenen Textfluss
        var sourceEntries = [], sourceUsed = false, sourceWarning = "", aliases = 0, i;
        for (i = 0; i < SECTIONS.length; i++) SECTIONS[i].enAlias = [];
        if (cfg.sourceFile && cfg.sourceFile.exists) {
            try {
                sourceEntries = parseSourceSections(readUTF8(cfg.sourceFile));
                sourceUsed = sourceEntries.length > 0;
                aliases = registerSourceAliases(sourceEntries);
                state.sourceFile = cfg.sourceFile;
            } catch (e) {
                sourceWarning = "BILINGUAL-TXT konnte nicht ausgewertet werden: " + errorText(e);
            }
        } else if (cfg.sourceFile && cfg.sourceFile.fsName) {
            sourceWarning = "Gespeicherte BILINGUAL-TXT nicht gefunden: " + cfg.sourceFile.fsName;
        }

        var heHeadings = collectHeadingParagraphs(doc, STYLE_HE_HEAD, FRAME_HE_LABEL, true, false);
        var enHeadings = collectHeadingParagraphs(doc, STYLE_EN_HEAD, FRAME_EN_LABEL, false, false);
        var heStarts = buildSectionStarts(heHeadings, true);
        var enStarts = buildSectionStarts(enHeadings, false);
        var fallbackLang = "";
        if (!enStarts.length && heStarts.length) { enStarts = mirrorStarts(heStarts); fallbackLang = "en"; }
        else if (!heStarts.length && enStarts.length) { heStarts = mirrorStarts(enStarts); fallbackLang = "he"; }

        var pageMap = buildPageMap(doc, heStarts, enStarts, cfg);
        applyManualOverrides(pageMap, doc, cfg);
        applyExcludedPages(pageMap, doc, cfg);

        var unmatched = [];
        for (i = 0; i < heStarts.length; i++) if (!heStarts[i].matched) unmatched.push("HE S. " + heStarts[i].pageName + ": " + heStarts[i].title);
        for (i = 0; i < enStarts.length; i++) if (!enStarts[i].matched) unmatched.push("EN S. " + enStarts[i].pageName + ": " + enStarts[i].title);

        return {
            sourceEntries:sourceEntries,
            sourceUsed:sourceUsed,
            sourceWarning:sourceWarning,
            sourceAliases:aliases,
            heHeadings:heHeadings,
            enHeadings:enHeadings,
            heStarts:heStarts,
            enStarts:enStarts,
            starts:heStarts.length ? heStarts : enStarts,
            pageMap:pageMap,
            usedEnglishFallback:fallbackLang === "he",
            fallbackLang:fallbackLang,
            unmatched:unmatched,
            unresolvedYears:0
        };
    }

//@@ ERSETZE collectHeadingParagraphs
    function collectHeadingParagraphs(doc, styleName, frameLabel, isHebrew, allowHeuristic) {
        // Rav Pe’alim (wie Leshon Chakhamim v1.0.1): nur Absaetze mit dem Ueberschriften-Format des Buchmanagers;
        // Text genau wie im Dokument, dazu Seite und ob die Ueberschrift oben im Rahmen steht.
        var stories = collectStoriesByFrameLabel(doc, frameLabel);
        var out = [], i, j, story, paras, p, txt, styleOk, pageInfo, sid;
        for (i = 0; i < stories.length; i++) {
            story = stories[i];
            try { sid = String(story.id); } catch (_) { sid = String(i); }
            paras = story.paragraphs;
            for (j = 0; j < paras.length; j++) {
                p = paras[j];
                styleOk = false;
                try { styleOk = p.appliedParagraphStyle && p.appliedParagraphStyle.isValid && p.appliedParagraphStyle.name === styleName; } catch (_) {}
                if (!styleOk) continue;
                txt = cleanHeadingText(p.contents);
                if (!txt) continue;
                pageInfo = paragraphPageInfo(p);
                if (!pageInfo) continue;
                out.push({text:txt, pageIndex:pageInfo.index, pageName:pageInfo.name, textIndex:safeTextIndex(p),
                          storyId:sid, atTop:paragraphAtFrameTop(p), yearMarker:null, source:"style"});
            }
        }
        return dedupeHeadings(out);
    }

//@@ ERSETZE dedupeHeadings
    function dedupeHeadings(a) {
        // gleichlautende Ueberschriften bleiben erhalten; doppelt nur derselbe Absatz
        a.sort(function(x,y){ if (x.pageIndex !== y.pageIndex) return x.pageIndex-y.pageIndex; return x.textIndex-y.textIndex; });
        var out=[], seen={}, i, k;
        for(i=0;i<a.length;i++){
            k=(a[i].storyId||"")+"|"+a[i].textIndex;
            if(!seen[k]){seen[k]=true;out.push(a[i]);}
        }
        return out;
    }

//@@ ERSETZE buildPageMap
    function buildPageMap(doc, heStarts, enStarts, cfg) {
        var map = [], i, he, en, rule = cfg.pageRule || 0;
        for (i = 0; i < doc.pages.length; i++) {
            he = sectionForPage(heStarts, i, rule);
            en = sectionForPage(enStarts, i, rule);
            if (!he && !en) { map.push(null); continue; }
            map.push({
                heTitle:he ? he.s.title : "", heShort:he ? he.s.kurzTitel : "", heGroup:he ? he.s.groupHe : "",
                enTitle:en ? en.s.title : "", enShort:en ? en.s.kurzTitel : "", enGroup:en ? en.s.groupEn : "",
                startPageHe:he ? he.start : false, startPageEn:en ? en.start : false,
                startPage:!!((he && he.start) || (en && en.start)),
                year:null,
                source:(he ? he.s.detection : "") + (en ? (he ? " / " : "") + en.s.detection : ""),
                visible:true
            });
        }
        if (cfg.bodyOnly) {
            for (i = 0; i < doc.pages.length; i++) if (map[i] && !isBihBodyPage(doc.pages[i])) map[i].visible = false;
        }
        if (cfg.hideFirst) {
            for (i = 0; i < doc.pages.length; i++) {
                if (map[i] && (isLeftPage(doc.pages[i]) ? map[i].startPageEn : map[i].startPageHe)) map[i].visible = false;
            }
        }
        return map;
    }

//@@ ERSETZE applyRunningHeaders
    function applyRunningHeaders(doc, cfg, pageIndexes, mode) {
        requireHeaderFonts(cfg);
        var a = analyzeDocument(doc, cfg);
        state.lastAnalysis = a;
        var backup = null;
        if (cfg.backup) backup = createInDesignBackup(doc, mode === "test" ? "header_test" : "headers");
        var layer = ensureHeaderLayer(doc);
        var selected = pageIndexLookup(pageIndexes, doc.pages.length);
        var allPages = pageIndexes === null || pageIndexes === undefined;
        var changed=0,hidden=0,created=0,updated=0,shortFallbacks=0,shrunk=0,truncated=[],rules=0,startEmphasis=0,emphasisFallbacks=0,noHeaderPages=[],notFitted=[],pageErrors=[],i,page,info,headerResult;

        for(i=0;i<doc.pages.length;i++){
            if(!allPages && !selected[i])continue;
            page=doc.pages[i];info=a.pageMap[i];

            if(!info || !info.visible || !headerTitle(info,isLeftPage(page)?"en":"he",false)){
                if(removeHeaderFramesFromPage(page)>0)changed++;
                if(isBihBodyPage(page)) setPageNumberFrame(doc,page,cfg,false,layer);
                hidden++;
                noHeaderPages.push(displayPageNumber(page,i));
                if(cfg.ruleEnabled && isBihBodyPage(page)){normalizeHeaderRule(doc,page,cfg,layer);rules++;}
                continue;
            }

            try{
                setPageNumberFrame(doc,page,cfg,true,layer);
                headerResult=setHeaderForPage(doc,page,info,cfg,layer);
            }catch(ePage){
                // eine Seite mit Problem haelt den Lauf nicht an; sie steht im Bericht
                pageErrors.push("S. "+displayPageNumber(page,i)+": "+errorText(ePage));
                continue;
            }
            if(headerResult.failed){
                notFitted.push("S. "+displayPageNumber(page,i)+" („"+headerTitle(info,isLeftPage(page)?"en":"he",false)+"“): "+headerResult.failed);
                try{setPageNumberFrame(doc,page,cfg,false,layer);}catch(_){}
            }
            if(headerResult.created)created++;else updated++;
            if(headerResult.usedShort)shortFallbacks++;
            if(headerResult.shrunk)shrunk++;
            if(headerResult.truncated)truncated.push(displayPageNumber(page,i));
            if(headerResult.startEmphasis)startEmphasis++;
            if(headerResult.emphasisFallback)emphasisFallbacks++;
            if(cfg.ruleEnabled){normalizeHeaderRule(doc,page,cfg,layer);rules++;}
            changed++;
        }

        if(cfg.saveAfter)doc.save();
        var report = [], probleme = notFitted.length + pageErrors.length, j;
        if(probleme){
            report.push((mode === "test" ? "TESTLAUF" : "KOLUMNENTITEL AKTUALISIERT")+" · "+probleme+" SEITE(N) PRÜFEN (siehe unten)");
        }else{
            report.push(mode === "test" ? "TEST AUF AKTUELLER DOPPELSEITE ERFOLGREICH" : "KOLUMNENTITEL ERFOLGREICH AKTUALISIERT");
        }
        report.push("Dokument: "+doc.name);
        report.push("Abschnittsüberschriften erkannt: HE "+a.heStarts.length+" · EN "+a.enStarts.length+
                    (a.fallbackLang?" · "+(a.fallbackLang==="en"?"EN":"HE")+" aus der anderen Sprache übernommen":"")+
                    " · Seitenregel: "+pageRuleLabel(cfg.pageRule));
        report.push("Header erstellt: "+created+" · aktualisiert: "+updated+" · ausgeblendet/ohne Header: "+hidden);
        report.push("Seiten ohne Kolumnentitel: "+formatPageLabelList(noHeaderPages));
        report.push("Kurztitel verwendet: "+shortFallbacks+" · automatisch verkleinert: "+shrunk+" · mit „…“ gekürzt: "+truncated.length+
                    (truncated.length?" (S. "+formatPageLabelList(truncated)+")":""));
        if(a.unmatched.length)report.push("Überschriften ohne Katalogeintrag (Titel wie im Dokument, kein Kurztitel): "+a.unmatched.length);
        if(cfg.emphasizeStart) report.push("Seiten mit fett gesetztem Abschnittsbeginn: "+startEmphasis+(emphasisFallbacks?" · Schrift-Fallbacks: "+emphasisFallbacks:""));
        if(cfg.ruleEnabled)report.push("Headerlinien geprüft/gesetzt: "+rules+" · "+cfg.ruleWeight+" pt");
        if(a.sourceWarning)report.push("WARNUNG Quelle: "+a.sourceWarning);
        if(notFitted.length){
            report.push("OHNE KOLUMNENTITEL – passt in keiner Fassung in eine Zeile, Kopfrahmen entfernt (kein Übersatz): "+notFitted.length);
            for(j=0;j<notFitted.length&&j<12;j++)report.push("  "+notFitted[j]);
            if(notFitted.length>12)report.push("  … und "+(notFitted.length-12)+" weitere");
        }
        if(pageErrors.length){
            report.push("FEHLER auf einzelnen Seiten (übersprungen): "+pageErrors.length);
            for(j=0;j<pageErrors.length&&j<12;j++)report.push("  "+pageErrors[j]);
            if(pageErrors.length>12)report.push("  … und "+(pageErrors.length-12)+" weitere");
        }
        if(backup)report.push("INDD-Sicherung: "+backup.fsName);
        report.push("Fließtext-Rahmen wurden nicht verändert.");
        var txt=report.join("\r\n");
        try{doc.insertLabel(DOC_LAST_REPORT_LABEL,txt);}catch(_){}
        return txt;
    }

//@@ ERSETZE setHeaderForPage
    function setHeaderForPage(doc, page, info, cfg, layer) {
        // v1.0.4 einfach und sicher: alter Kopfrahmen wird geloescht (samt verstecktem Uebersatz,
        // der sonst als doppelte, groessere Woerter wieder auftauchte), ein frischer Rahmen angelegt,
        // dann gilt die erste Fassung, die in EINE Zeile passt:
        //   voller Titel -> Kurztitel -> kleinere Schrift bis Minimum -> wortweise mit "…" ->
        //   nur Werktitel. Passt nichts, bleibt die Seite ohne Kopfrahmen (nie Uebersatz).
        var isLeft = isLeftPage(page);
        var created = labeledFrames(page, HEADER_FRAME_LABEL).length === 0;
        removeHeaderFramesFromPage(page);
        var tf = getOrCreateSingleLabeledTextFrame(page, HEADER_FRAME_LABEL, layer);
        tf.geometricBounds = headerBounds(page, cfg.topMm, cfg.bottomMm);
        setFrameInsets(tf,0);
        try{tf.textFramePreferences.ignoreWrap=true;}catch(_){}
        try{tf.textFramePreferences.verticalJustification=VerticalJustification.CENTER_ALIGN;}catch(_){}
        try{tf.itemLayer=layer;}catch(_){}

        var lang = isLeft ? "en" : "he";
        var full = headerTitle(info, lang, false), kurz = headerTitle(info, lang, true);
        var size = lang === "en" ? cfg.enSize : cfg.heSize;
        var minSize = lang === "en" ? cfg.enMinSize : cfg.heMinSize;
        var langStart = lang === "en" ? info.startPageEn : info.startPageHe;
        if (langStart === undefined) langStart = info.startPage;
        var group = lang === "en" ? (info.enGroup || "") : (info.heGroup || "");
        var showsSection = templateShowsSection(cfg, lang);
        var shown = (cfg.autoShort && showsSection && kurz && kurz !== full) ? kurz : full;
        var emph = null, ok = false, usedShort = false, shrunk = false, truncated = false, failed = "";
        var sz = size, words, keep;

        function versuche(title, pt) {
            var r = renderHeaderText(info, cfg, lang, false, title);
            var needle = showsSection ? title : group;
            emph = formatHeaderTextFrame(doc, tf, r.text, cfg, lang, pt,
                {startPage:!!langStart, enTitle:lang === "en" ? needle : "", heTitle:lang === "he" ? needle : ""});
            return !headerNeedsFallback(tf);
        }

        ok = versuche(full, size);
        if (!ok && shown !== full) { ok = versuche(shown, size); usedShort = ok; }
        while (!ok && sz - 0.25 >= minSize - 0.001) {
            sz -= 0.25;
            ok = versuche(shown, sz);
            if (ok) { shrunk = true; usedShort = shown !== full; }
        }
        if (!ok && showsSection) {
            words = trim(shown).split(/\s+/);
            for (keep = words.length - 1; !ok && keep >= 1; keep--) {
                ok = versuche(shortenWords(shown, keep), minSize);
                if (ok) { truncated = true; shrunk = minSize < size; usedShort = shown !== full; }
            }
            if (!ok) { ok = versuche("", minSize); if (ok) truncated = true; }
        }
        if (!ok) {
            failed = headerDiagnosis(tf) || "Kopfrahmen läuft über";
            try { tf.remove(); } catch (_) {}
        }
        return {created:created,usedShort:usedShort,shrunk:shrunk,truncated:truncated,failed:failed,
                startEmphasis:!!(emph&&emph.applied),emphasisFallback:!!(emph&&emph.fallback)};
    }

//@@ ERSETZE renderHeaderText
    function renderHeaderText(info, cfg, lang, forceShort, title) {
        // {ABSCHNITT}/{PARASHAH} = englische, {ABSCHNITT_HE}/{PARASHAH_HE} = hebraeische Abschnittsueberschrift,
        // {GRUPPE}/{GRUPPE_HE} = Gruppe (Abteilung · Teil); title ersetzt den Titel der Seitensprache (Kurz-/Kuerzungsstufe)
        var tpl = lang === "en" ? cfg.enTemplate : cfg.heTemplate;
        var given = title !== undefined && title !== null;
        var enT = (lang === "en" && given) ? String(title) : headerTitle(info, "en", forceShort);
        var heT = (lang === "he" && given) ? String(title) : headerTitle(info, "he", forceShort);
        var text = tpl;
        text = replaceAllLiteral(text, "{ABSCHNITT}", enT);
        text = replaceAllLiteral(text, "{ABSCHNITT_HE}", heT);
        text = replaceAllLiteral(text, "{PARASHAH}", enT);
        text = replaceAllLiteral(text, "{PARASHAH_HE}", heT);
        text = replaceAllLiteral(text, "{GRUPPE}", info.enGroup || "");
        text = replaceAllLiteral(text, "{GRUPPE_HE}", info.heGroup || "");
        text = replaceAllLiteral(text, "{YEAR}", "");
        text = replaceAllLiteral(text, "{YEAR_HE}", "");
        text = cleanTemplateSeparators(text);
        return {text:text, usedShort:!!forceShort};
    }

//@@ ERSETZE validateRunningHeaders
    function validateRunningHeaders(doc,cfg){
        var a=analyzeDocument(doc,cfg),missing=[],extra=[],wrongSide=[],dup=[],numMissing=[],noHeaderExpected=[],wrongTitle=[],overset=[],i,page,info,headers,nums,lang,txt,expected;
        for(i=0;i<doc.pages.length;i++){
            page=doc.pages[i];info=a.pageMap[i];headers=labeledFrames(page,HEADER_FRAME_LABEL);nums=labeledFrames(page,PAGE_NUMBER_LABEL);
            lang=isLeftPage(page)?"en":"he";
            expected=!!(info&&info.visible&&headerTitle(info,lang,false));
            if(!expected)noHeaderExpected.push(displayPageNumber(page,i));
            if(expected&&!headers.length)missing.push(i+1);
            if(!expected&&headers.length)extra.push(i+1);
            if(headers.length>1)dup.push(i+1);
            if(cfg.bodyOnly&&isBihBodyPage(page)&&!nums.length)numMissing.push(i+1);
            if(headers.length){
                txt=cleanHeadingText(headers[0].contents);
                if(isLeftPage(page)&&containsHebrew(txt))wrongSide.push((i+1)+"(HE auf links)");
                if(!isLeftPage(page)&&!containsHebrew(txt))wrongSide.push((i+1)+"(EN auf rechts)");
                if(expected&&templateShowsSection(cfg,lang)&&!headerMatchesTitle(txt,info,lang))wrongTitle.push(displayPageNumber(page,i));
                if(headerNeedsFallback(headers[0]))overset.push(displayPageNumber(page,i));
            }
        }
        var out=[];
        out.push("KOLUMNENTITEL-PRÜFUNG");
        out.push("Dokument: "+doc.name+" · "+doc.pages.length+" Seiten");
        out.push("Abschnittsüberschriften erkannt: HE "+a.heStarts.length+" · EN "+a.enStarts.length+" · Seitenregel: "+pageRuleLabel(cfg.pageRule));
        out.push("Seiten ohne Kolumnentitel (laut aktueller Regel): "+formatPageLabelList(noHeaderExpected));
        out.push("Fehlende erwartete Header: "+formatNumberList(missing));
        out.push("Header auf laut Regel ausgeschlossenen Seiten: "+formatNumberList(extra));
        out.push("Doppelte Headerrahmen: "+formatNumberList(dup));
        out.push("Sprachseite auffällig: "+(wrongSide.length?wrongSide.join(", "):"keine"));
        out.push("Titel passt nicht zur Überschrift der Seite (z. B. nach neuem Umbruch): "+formatPageLabelList(wrongTitle));
        out.push("Kopfrahmen mit Übersatz oder zweizeilig: "+formatPageLabelList(overset));
        out.push("Fehlende RPL-Seitenzahlen: "+formatNumberList(numMissing));
        if(a.unmatched.length)out.push("Überschriften ohne Katalogeintrag: "+a.unmatched.length);
        if(a.sourceWarning)out.push("Quelle: "+a.sourceWarning);
        out.push((!missing.length&&!extra.length&&!dup.length&&!wrongSide.length&&!wrongTitle.length&&!overset.length)?"Ergebnis: keine Headerfehler erkannt.":"Ergebnis: oben genannte Seiten prüfen/reparieren (Kolumnentitel neu erstellen).");
        return out.join("\r\n");
    }

//@@ ERSETZE formatAnalysisReport
    function formatAnalysisReport(doc,a,cfg){
        var out=[],i,info,key,curKey=null,from=0;
        out.push("RAV PE’ALIM · KOLUMNENTITEL-ANALYSE · Kolumnentitel = Abschnittsüberschrift der Seite");
        out.push("Dokument: "+doc.name+" · "+doc.pages.length+" physische Seiten · Band "+(doc.extractLabel(DOC_VOLUME_LABEL)||"?"));
        out.push("Überschriften im Dokument: HE "+a.heHeadings.length+" · EN "+a.enHeadings.length+" · Seitenregel: "+pageRuleLabel(cfg.pageRule));
        out.push("BILINGUAL-TXT: "+(a.sourceUsed?a.sourceEntries.length+" Abschnitte"+(a.sourceAliases?" · "+a.sourceAliases+" abweichende englische Titel übernommen":""):"nicht verwendet (eingebauter Katalog)"));
        if(a.sourceUsed&&a.sourceEntries.length!==a.heHeadings.length)out.push("HINWEIS: Banddatei "+a.sourceEntries.length+" Abschnitte, Dokument "+a.heHeadings.length+" hebräische Überschriften.");
        if(a.sourceUsed&&a.enHeadings.length&&a.sourceEntries.length!==a.enHeadings.length)out.push("HINWEIS: Banddatei "+a.sourceEntries.length+" Abschnitte, Dokument "+a.enHeadings.length+" englische Überschriften.");
        if(a.fallbackLang)out.push("Fallback: keine "+(a.fallbackLang==="en"?"englischen":"hebräischen")+" Überschriften gefunden; Titel über den Katalog aus der anderen Sprache.");
        if(a.sourceWarning)out.push("WARNUNG: "+a.sourceWarning);
        if(a.unmatched.length){
            out.push("Nicht im Katalog (Titel wie im Dokument, ohne Kurztitel): "+a.unmatched.length);
            for(i=0;i<a.unmatched.length&&i<20;i++)out.push("  "+a.unmatched[i]);
        }
        out.push("");
        if(!a.heStarts.length&&!a.enStarts.length){
            out.push("Keine Abschnittsüberschrift erkannt. Prüfe die Absatzformate \""+STYLE_HE_HEAD+"\" / \""+STYLE_EN_HEAD+"\" oder lege im Fallback-Reiter manuelle Bereiche an.");
            return out.join("\r\n");
        }
        out.push("Kolumnentitel je Seitenbereich (rechte Seiten Hebräisch | linke Seiten Englisch):");
        function bereich(a0,a1){
            var inf=a.pageMap[a0];
            out.push("  S. "+displayPageNumber(doc.pages[a0],a0)+(a1>a0?"–"+displayPageNumber(doc.pages[a1],a1):"")+" · "+
                     (inf.heTitle||"–")+" | "+(inf.enTitle||"–")+(inf.visible?"":" · ohne Kolumnentitel"));
        }
        for(i=0;i<doc.pages.length;i++){
            info=a.pageMap[i];
            key=info?(info.heTitle+"|"+info.enTitle+"|"+info.visible):null;
            if(key!==curKey){
                if(curKey!==null)bereich(from,i-1);
                curKey=key;from=i;
            }
        }
        if(curKey!==null)bereich(from,doc.pages.length-1);
        if(cfg.excludedText)out.push("Zusätzlich ausgeschlossen: "+cfg.excludedText);
        if(cfg.overrides.length)out.push("Manuelle Overrides in dieser Sitzung: "+cfg.overrides.length);
        out.push("");
        out.push("Noch keine Layoutänderung vorgenommen.");
        return out.join("\r\n");
    }

//@@ ERSETZE formatHeaderTextFrame
    function formatHeaderTextFrame(doc, tf, text, cfg, lang, pointSize, info) {
        // v1.0.4: ganze Textkette ersetzen (tf.contents ersetzt nur den sichtbaren Teil; versteckter
        // Uebersatz blieb stehen) und alle geerbten Absatz-/Zeichenattribute neutralisieren
        var story = tf.parentStory, t, font;
        try { story.contents = text; } catch (_) { tf.contents = text; }
        t = story.texts[0];
        resetHeaderText(doc, tf, t);
        if(lang==="en"){
            font=requireFont(cfg.enFont,cfg.enStyle);
            try{t.appliedFont=font;}catch(_){}
            try{t.fontStyle=cfg.enStyle;}catch(_){}
            t.pointSize=pointSize;
            try{t.leading=pointSize+1.1;}catch(_){}
            try{t.tracking=cfg.enTracking;}catch(_){}
            try{t.justification=Justification.LEFT_ALIGN;}catch(_){}
            try{t.paragraphDirection=ParagraphDirectionOptions.LEFT_TO_RIGHT_DIRECTION;}catch(_){}
            try{t.composer="Adobe Paragraph Composer";}catch(_){}
        }else{
            font=requireFont(cfg.heFont,cfg.heStyle);
            try{t.appliedFont=font;}catch(_){}
            try{t.fontStyle=cfg.heStyle;}catch(_){}
            t.pointSize=pointSize;
            try{t.leading=pointSize+1.2;}catch(_){}
            try{t.tracking=cfg.heTracking;}catch(_){}
            try{t.justification=Justification.RIGHT_ALIGN;}catch(_){}
            try{t.paragraphDirection=ParagraphDirectionOptions.RIGHT_TO_LEFT_DIRECTION;}catch(_){}
            try{t.composer="Adobe World-Ready Paragraph Composer";}catch(_){}
        }
        try{t.hyphenation=false;}catch(_){}
        try{t.fillColor=blackSwatch(doc);t.fillTint=cfg.tint;}catch(_){}
        var emphasisResult = cfg.emphasizeStart ? applyStartPageEmphasis(doc, tf, info, cfg, lang) : {applied:false,fallback:false};
        try{story.recompose();}catch(_){}
        return emphasisResult;
    }
