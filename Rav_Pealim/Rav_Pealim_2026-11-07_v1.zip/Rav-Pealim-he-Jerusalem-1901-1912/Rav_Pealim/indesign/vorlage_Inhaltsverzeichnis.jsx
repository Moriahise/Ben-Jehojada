#target "InDesign"
#targetengine "RavPealimInhaltsverzeichnis_v100"

/*
    Rav Pe’alim · Inhaltsverzeichnis v1.0.0  (07.11.2026)
    Vorlage; das ausfuehrbare Skript erzeugt indesign/erzeuge_rp_jsx.py mit dem
    Katalog der Gruppen (Abteilung · Teil) und Simanim samt Inhaltsangabe aus
    den Mafteachot des Drucks (rp_struktur.py).
    Uebernommen aus Leshon_Chakhamim_Inhaltsverzeichnis_v1_0_0.jsx.

    Ersetzt die Mafteachot des Drucks (im Master ausgelassen). Arbeitsweise:
      1. den fertigen Band (mit dem Rav-Pe’alim-Buchmanager gebaut) als
         aktives Dokument oeffnen;
      2. Skript starten: es liest alle Absaetze mit den Absatzformaten
         "RPL · Abschnitt · Hebräisch" und "RPL · Section · English" samt
         Seitenzahl (Seitenname) und ordnet sie den Gruppen zu;
      3. es legt ein neues Dokument im Bandformat an (148 x 210 mm) mit
         "תוכן העניינים" (rechts-nach-links, unter jedem Siman die
         Inhaltsangabe des Drucks) und "Contents" und speichert es neben dem
         Band als <Band>_Inhalt.indd.
    Der Band selbst wird nicht veraendert. Nach jedem Umbruch neu ausfuehren.
    Seitenzahlen sind die Seitennamen des Bandes (Abschnittsnummerierung).
*/

(function () {
    var APP_NAME = "Rav Pe’alim · Inhaltsverzeichnis";
    var VERSION = "1.0.0";
    var STYLE_HE_HEAD = "RPL · Abschnitt · Hebräisch";
    var STYLE_EN_HEAD = "RPL · Section · English";
    var HE_FONT = "Keter YG";
    var HE_FONT_STYLE = "Medium";
    var EN_FONT = "Cambria";
    var EN_FONT_STYLE = "Regular";
    var PAGE_W_MM = 148;
    var PAGE_H_MM = 210;
    var MARGIN_MM = 12.7;
    var TITEL_HE = "תוכן העניינים";
    var TITEL_EN = "Contents";
    var RIGHT_INDENT_TAB = "\u0008";

    // Gruppen: Schluessel -> [hebraeisch, englisch]
    var GRUPPEN = /*@GRUPPEN@*/;
    // Abschnitte in Werkfolge: [Titel normalisiert (nur Buchstaben und Leerzeichen), Gruppe, Inhaltsangabe des Drucks]
    var ABSCHNITTE = /*@ABSCHNITTE@*/;

    function trim(s){return String(s||"").replace(/^\s+|\s+$/g,"");}

    function normalizeHebrewWords(s){
        s=String(s||"").replace(/[֑-ׇ]/g,"");
        s=s.replace(/[^א-ת ]+/g," ").replace(/\s+/g," ");
        return trim(s);
    }

    function katalogEintrag(titel){
        var t=normalizeHebrewWords(titel),i;
        for(i=0;i<ABSCHNITTE.length;i++)if(ABSCHNITTE[i][0]===t)return ABSCHNITTE[i];
        return null;
    }

    function zuordnen(he,en){
        // Hebraeisch: Gruppe und Inhaltsangabe ueber den Katalog; Englisch: gleiche Reihenfolge wie Hebraeisch
        var i,k,fehlend=[];
        for(i=0;i<he.length;i++){
            k=katalogEintrag(he[i].text);
            he[i].gruppe=k?k[1]:null;he[i].angabe=k&&k.length>2?k[2]:"";
            if(!k)fehlend.push(he[i].text);
        }
        var paarweise=(en.length===he.length);
        for(i=0;i<en.length;i++){en[i].gruppe=paarweise?he[i].gruppe:null;en[i].angabe="";}
        return {fehlend:fehlend,paarweise:paarweise};
    }

    function eintraege(heads,sprache){
        var out=[],last=null,i,h,g;
        for(i=0;i<heads.length;i++){
            h=heads[i];g=h.gruppe;
            if(g&&g!==last&&GRUPPEN[g]){out.push({art:"gruppe",text:GRUPPEN[g][sprache==="he"?0:1]});last=g;}
            out.push({art:"eintrag",text:trim(h.text),seite:String(h.seite)});
            if(sprache==="he"&&h.angabe)out.push({art:"angabe",text:trim(h.angabe)});
        }
        return out;
    }

    function zeilen(eintr){
        var out=[],i;
        for(i=0;i<eintr.length;i++){
            if(eintr[i].art==="eintrag")out.push(eintr[i].text+RIGHT_INDENT_TAB+eintr[i].seite);
            else out.push(eintr[i].text);
        }
        return out;
    }

    // ---------------- InDesign ----------------

    function mm(v){return String(Number(v))+" mm";}
    function safeFont(family,style){var f=app.fonts.itemByName(family+"\t"+style);if(f&&f.isValid)return f;f=app.fonts.itemByName(family);if(f&&f.isValid)return f;return app.fonts[0];}
    function ensurePara(doc,name){var s=doc.paragraphStyles.itemByName(name);if(!s.isValid)s=doc.paragraphStyles.add({name:name});return s;}

    function seitenName(par){
        try{var f=par.parentTextFrames;if(f&&f.length&&f[0].parentPage)return f[0].parentPage.name;}catch(_){}
        try{return par.insertionPoints[0].parentTextFrames[0].parentPage.name;}catch(__){}
        return "?";
    }

    function sammle(doc,styleName){
        // Die Story mit den meisten Ueberschriften dieses Formats ist der Textfluss des Bandes.
        var best=[],s,p,paras,list,i,j,name;
        for(i=0;i<doc.stories.length;i++){
            s=doc.stories[i];list=[];
            try{paras=s.paragraphs.everyItem().getElements();}catch(_){continue;}
            for(j=0;j<paras.length;j++){
                p=paras[j];
                try{name=p.appliedParagraphStyle.name;}catch(__){continue;}
                if(name===styleName&&trim(p.contents))list.push({text:String(p.contents).replace(/[\r\n]+$/,""),seite:seitenName(p)});
            }
            if(list.length>best.length)best=list;
        }
        return best;
    }

    function stile(doc){
        var gh=ensurePara(doc,"RPL · Inhalt · Gruppe · Hebräisch"),eh=ensurePara(doc,"RPL · Inhalt · Eintrag · Hebräisch");
        var ah=ensurePara(doc,"RPL · Inhalt · Angabe · Hebräisch");
        var ge=ensurePara(doc,"RPL · Inhalt · Group · English"),ee=ensurePara(doc,"RPL · Inhalt · Entry · English");
        var th=ensurePara(doc,"RPL · Inhalt · Titel · Hebräisch"),te=ensurePara(doc,"RPL · Inhalt · Title · English");
        var he=[th,gh,eh,ah],en=[te,ge,ee],i;
        for(i=0;i<he.length;i++){
            try{he[i].appliedFont=safeFont(HE_FONT,HE_FONT_STYLE);he[i].fontStyle=HE_FONT_STYLE;he[i].paragraphDirection=ParagraphDirectionOptions.RIGHT_TO_LEFT_DIRECTION;he[i].composer="Adobe World-Ready Paragraph Composer";he[i].justification=Justification.RIGHT_ALIGN;}catch(_){}
        }
        for(i=0;i<en.length;i++){
            try{en[i].appliedFont=safeFont(EN_FONT,EN_FONT_STYLE);en[i].fontStyle=EN_FONT_STYLE;en[i].paragraphDirection=ParagraphDirectionOptions.LEFT_TO_RIGHT_DIRECTION;en[i].justification=Justification.LEFT_ALIGN;}catch(_){}
        }
        try{th.pointSize=17;th.leading=20;th.justification=Justification.CENTER_ALIGN;th.spaceAfter=mm(6);}catch(_){}
        try{te.pointSize=15;te.leading=18;te.justification=Justification.CENTER_ALIGN;te.spaceAfter=mm(6);te.fontStyle="Bold";}catch(_){}
        try{gh.pointSize=11;gh.leading=13;gh.spaceBefore=mm(3);gh.spaceAfter=mm(1);gh.keepWithNext=2;}catch(_){}
        try{ge.pointSize=10;ge.leading=12;ge.spaceBefore=mm(3);ge.spaceAfter=mm(1);ge.keepWithNext=2;ge.fontStyle="Bold";}catch(_){}
        try{eh.pointSize=10;eh.leading=12.5;eh.rightIndent=mm(3);eh.keepWithNext=1;}catch(_){}
        try{ah.pointSize=8.5;ah.leading=10.5;ah.rightIndent=mm(7);ah.leftIndent=mm(6);ah.spaceAfter=mm(0.8);ah.justification=Justification.RIGHT_JUSTIFIED;}catch(_){}
        try{ee.pointSize=9;ee.leading=11.5;ee.leftIndent=mm(3);}catch(_){}
        return {he:{titel:th,gruppe:gh,eintrag:eh,angabe:ah},en:{titel:te,gruppe:ge,eintrag:ee,angabe:ee}};
    }

    function rahmen(doc,page){
        var b=page.bounds,x0=Number(b[1]),x1=Number(b[3]);
        var tf=page.textFrames.add({geometricBounds:[mm(MARGIN_MM),mm(x0+MARGIN_MM),mm(PAGE_H_MM-MARGIN_MM),mm(x1-MARGIN_MM)]});
        return tf;
    }

    function setzeText(doc,firstFrame,teile,st){
        // teile: [{sprache, titel, zeilen:[...], arten:[...]}]; jede Sprache beginnt auf neuer Seite
        var story=firstFrame.parentStory,text=[],formate=[],i,j,k;
        for(i=0;i<teile.length;i++){
            if(i>0){text.push("\u000C");formate.push(null);}            // Seitenumbruch (Sonderzeichen)
            text.push(teile[i].titel);formate.push(st[teile[i].sprache].titel);
            for(j=0;j<teile[i].zeilen.length;j++){
                text.push(teile[i].zeilen[j]);
                formate.push(st[teile[i].sprache][teile[i].arten[j]]);
            }
        }
        var roh=[],seitenumbruch=[];
        for(i=0;i<text.length;i++){if(text[i]==="\u000C"){seitenumbruch.push(roh.length);continue;}roh.push(text[i]);}
        story.contents=roh.join("\r");
        var paras=story.paragraphs,fi=0;
        for(k=0;k<formate.length;k++){
            if(formate[k]===null)continue;
            try{paras[fi].appliedParagraphStyle=formate[k];}catch(_){}
            fi++;
        }
        for(k=0;k<seitenumbruch.length;k++){
            try{paras[seitenumbruch[k]].startParagraph=StartParagraph.NEXT_PAGE;}catch(_){}
        }
        // Rahmen anhaengen, bis kein Uebersatz mehr
        var last=firstFrame,guard=0;
        while(last.overflows&&guard<400){
            var pg=doc.pages.add(LocationOptions.AT_END);
            var tf=rahmen(doc,pg);last.nextTextFrame=tf;last=tf;guard++;
        }
        return doc.pages.length;
    }

    function main(){
        if(!app.documents.length){alert("Bitte zuerst den fertigen Band öffnen.",APP_NAME);return;}
        var src=app.activeDocument;
        var he=sammle(src,STYLE_HE_HEAD),en=sammle(src,STYLE_EN_HEAD);
        if(!he.length){alert("Keine Absätze mit dem Format \""+STYLE_HE_HEAD+"\" gefunden. Ist das ein mit dem Rav-Pe’alim-Buchmanager gebauter Band?",APP_NAME);return;}
        var z=zuordnen(he,en);
        var eHe=eintraege(he,"he"),eEn=eintraege(en,"en"),teile=[],i,arten;
        arten=[];for(i=0;i<eHe.length;i++)arten.push(eHe[i].art);
        teile.push({sprache:"he",titel:TITEL_HE,zeilen:zeilen(eHe),arten:arten});
        if(eEn.length){arten=[];for(i=0;i<eEn.length;i++)arten.push(eEn[i].art);teile.push({sprache:"en",titel:TITEL_EN,zeilen:zeilen(eEn),arten:arten});}
        var doc=app.documents.add();
        try{doc.viewPreferences.horizontalMeasurementUnits=MeasurementUnits.MILLIMETERS;doc.viewPreferences.verticalMeasurementUnits=MeasurementUnits.MILLIMETERS;}catch(_){}
        doc.documentPreferences.facingPages=true;
        doc.documentPreferences.pageWidth=mm(PAGE_W_MM);
        doc.documentPreferences.pageHeight=mm(PAGE_H_MM);
        doc.documentPreferences.pagesPerDocument=1;
        try{doc.viewPreferences.rulerOrigin=RulerOrigin.PAGE_ORIGIN;}catch(_){}
        var st=stile(doc);
        var seiten=setzeText(doc,rahmen(doc,doc.pages[0]),teile,st);
        var ziel=null;
        try{if(src.saved&&src.fullName){ziel=new File(String(src.fullName.fsName).replace(/\.indd$/i,"")+"_Inhalt.indd");doc.save(ziel);}}catch(_){ziel=null;}
        alert("Inhaltsverzeichnis erstellt: "+seiten+" Seiten\r"+he.length+" hebräische und "+en.length+" englische Einträge"+
              (z.fehlend.length?"\r\rOhne Gruppe (Titel nicht im Katalog): "+z.fehlend.length+"\r"+z.fehlend.slice(0,5).join("\r"):"")+
              (en.length&&!z.paarweise?"\r\rEnglisch: andere Zahl der Überschriften als Hebräisch – ohne Gruppenzeilen.":"")+
              (ziel?"\r\rGespeichert: "+ziel.fsName:"\r\rBitte das neue Dokument speichern."),APP_NAME+" "+VERSION);
    }

    if(typeof app!=="undefined"&&app&&String(app.name||"").indexOf("InDesign")>=0)main();
})();
