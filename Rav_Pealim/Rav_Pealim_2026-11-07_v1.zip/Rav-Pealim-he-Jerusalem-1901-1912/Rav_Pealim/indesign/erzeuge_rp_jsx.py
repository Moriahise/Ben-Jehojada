# -*- coding: utf-8 -*-
"""
Erzeugt die InDesign-Skripte fuer Rav Pe'alim aus den freigegebenen Ben-Ish-Chai-Skripten
des Repositorys, nach dem Muster von Leshon_Chakhamim/indesign/erzeuge_lc_jsx.py:

    Ben_Ish_Chai_Bilingual_Book_Manager_v1_0_17-Milestone.jsx
        -> Rav_Pealim_Bilingual_Book_Manager_v1_0_0.jsx
    Ben_Ish_Chai_Running_Header_Manager_v1_0_3.jsx + rh_abschnitte_bausteine.js (Stand LC RH v1.0.4)
        -> Rav_Pealim_Running_Header_Manager_v1_0_0.jsx
    vorlage_Inhaltsverzeichnis.jsx (aus LC, mit Inhaltsangaben der Mafteachot)
        -> Rav_Pealim_Inhaltsverzeichnis_v1_0_0.jsx

Jede Aenderung ist eine genaue Ersetzung mit erwarteter Trefferzahl; weicht das Original
ab, bricht der Generator ab. Layout (148 x 210 mm, Keter YG / Cambria, 1050/2000 Zeichen),
Batch-, Merge- und Layoutlogik bleiben unveraendert. Abweichungen fuer Rav Pe'alim:
Ziel 600 Seiten (Sod Yesharim in einem Band), Sperre 800, EN-Erweiterung 2,375
(Responsen), Kennung RPL. Kataloge (Simanim, Kurztitel, Gruppen, Inhaltsangaben) kommen
aus der Pipeline (rp_common.build_edition, rp_struktur).

Aufruf:  python3 indesign/erzeuge_rp_jsx.py
"""
import collections
import hashlib
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import rp_common as C  # noqa: E402

BM_SRC = C.BIC_JSX
RH_SRC = C.BIC_RH_JSX
BM_DST = HERE / 'Rav_Pealim_Bilingual_Book_Manager_v1_0_0.jsx'
RH_DST = HERE / 'Rav_Pealim_Running_Header_Manager_v1_0_0.jsx'
RH_BAUSTEINE = HERE / 'rh_abschnitte_bausteine.js'
TOC_SRC = HERE / 'vorlage_Inhaltsverzeichnis.jsx'
TOC_DST = HERE / 'Rav_Pealim_Inhaltsverzeichnis_v1_0_0.jsx'
ANWEISUNG = 'Rav_Pealim_VERBINDLICHE_Uebersetzungsanweisung_EN_Fassung1.0_20261107.txt'
ANWEISUNG_FASSUNG = '1.0'
STAND = '07.11.2026'
BM_VERSION = '1.0.0'
RH_VERSION = '1.0.0'
EN_KOPF = 'RAV PE’ALIM'
HE_KOPF = 'רב פעלים'


def ersetze(text, alt, neu, anzahl=1):
    n = text.count(alt)
    if n != anzahl:
        raise SystemExit('Erwartet {}x, gefunden {}x: {!r}'.format(anzahl, n, alt[:90]))
    return text.replace(alt, neu)


BM_KOPF = '''/*
    Rav Pe’alim · Zweisprachiger Buchmanager v''' + BM_VERSION + '''  (''' + STAND + ''')
    Erzeugt mit Rav_Pealim/indesign/erzeuge_rp_jsx.py aus
    Ben_Ish_Chai_Bilingual_Book_Manager_v1_0_17-Milestone.jsx
    (nach dem Muster des Leshon Chakhamim Buchmanagers v1.0.1).

    Gleich wie Ben Ish Chai v1.0.17: Seitenformat 148 x 210 mm, Rahmen,
    Schriften (Keter YG / Cambria), Einzel- und Bulk-Batches, BatchQueue,
    Merge, Layout-Abgleich, Snapshots, Farblogik.

    Anpassungen fuer Rav Pe’alim (Responsen):
      - Ziel ''' + str(C.TARGET_PAGES) + ''' statt 540 Seiten (Sod Yesharim, ca. 578 Seiten, ist ein Band),
        Bandsperre ''' + str(C.MAX_PAGES) + ''' statt 600 Seiten (wie Leshon Chakhamim v1.0.1),
        erwartete EN-Laenge ''' + str(C.EN_EXPANSION) + ''' x HE statt 1,95 (Kuerzel, Stellenangaben und
        Zitatketten werden im Englischen ausgeschrieben). 1050/2000 Zeichen je Seite unveraendert.
      - Kennungen RPL statt BIH (Segment-IDs RPL-0000001, Rahmen-Labels
        RPL_HE_FRAME/RPL_EN_FRAME, Formate "RPL · …"); passend zum
        Rav Pe’alim Kolumnentitel-Manager v''' + RH_VERSION + '''
      - Banddateien kommen ausschliesslich aus der Pipeline (produzieren.py /
        rp_bandplan.py: Reihen nach Abteilungen, Pilot Sod Yesharim, Simanim als
        Abschnitte, <en_title> = Titel der Ausgabe). Reiter 1 erzeugt keine
        Banddateien, sondern verweist darauf.
      - Zeichenzaehlung fuer Batch-Kontingent und Seitenschaetzung ohne
        Nikud/Teamim (wie die Pipeline)
      - project="Rav Pealim"; Translation_Batches verweisen auf
        ''' + ANWEISUNG + '''
      - Dateinamen Rav_Pealim_Band_XX(.indd)
*/
'''

PIPELINE_HINWEIS = '''    var PIPELINE_HINWEIS = "Rav Pe’alim: Die Banddateien werden mit der Pipeline erzeugt "+
        "(Rav_Pealim, produzieren.py bzw. rp_bandplan.py). Dort sind Reihen (Sod Yesharim, Orach Chayim, "+
        "Yoreh Deah, Even HaEzer, Choshen Mishpat), Bandgrenzen zwischen Simanim und die Titel der Simanim festgelegt.\\r\\r"+
        "Bitte die fertige Rav_Pealim_Band_XX_BILINGUAL.txt in Reiter 2 oder 3 wählen.";
'''

BM_ERSETZUNGEN = [
    ('#targetengine "BenIshChaiBilingualBookManager_v117"',
     '#targetengine "RavPealimBilingualBookManager_v' + BM_VERSION.replace('.', '') + '"', 1),
    ('var APP_NAME = "Ben Ish Chai · Zweisprachiger Buchmanager";',
     'var APP_NAME = "Rav Pe’alim · Zweisprachiger Buchmanager";', 1),
    ('var VERSION = "1.0.17";', 'var VERSION = "' + BM_VERSION + '";', 1),
    ('Ben_Ish_Chai_Band_', 'Rav_Pealim_Band_', 4),
    ('/Ben_Ish_Chai_Bandplan.txt', '/Rav_Pealim_Bandplan_JSX.txt', 1),
    ('/Ben_Ish_Chai_Segmentkontrolle.tsv', '/Rav_Pealim_Segmentkontrolle_JSX.tsv', 1),
    ('project=\\"Ben Ish Chai Halakha\\"', 'project=\\"' + C.PROJECT_ATTR + '\\"', 3),
    ('Ben_Ish_Chai_VERBINDLICHE_Uebersetzungsanweisung_EN.txt · Fassung 1.2', ANWEISUNG + ' · Fassung ' + ANWEISUNG_FASSUNG, 1),
    ('"BEN ISH CHAI · FESTER ARBEITSABLAUF\\r\\r" +',
     '"RAV PE’ALIM · FESTER ARBEITSABLAUF\\r\\r" +\n'
     '            "BANDDATEIEN: Die BILINGUAL-Banddateien entstehen ausschließlich mit der Pipeline '
     '(Rav_Pealim: produzieren.py bzw. rp_bandplan.py). Reiter 1 erzeugt keine Banddateien; Schritte 1–3 '
     'unten entfallen. Pilot ist Band 01 (Sod Yesharim): mit Reiter 2 (Übersetzungsportionen) beginnen; '
     'übersetzte Bände (…_EN_FERTIG.txt aus rp_uebersetzung.py) direkt in Reiter 3 (InDesign-Band).\\r\\r" +', 1),
    ('"BEN ISH CHAI · BULK-LAYOUT LAUFPROTOKOLL"', '"RAV PE’ALIM · BULK-LAYOUT LAUFPROTOKOLL"', 1),
    # Reiter 1: keine Banddateien aus einer Roh-TXT
    ('''        analyzeBtn.onClick = function () {
            try {''', '''        analyzeBtn.onClick = function () {
            alert(PIPELINE_HINWEIS, APP_NAME); return;
            try {''', 1),
    ('''        createFilesBtn.onClick = function () {
            try {''', '''        createFilesBtn.onClick = function () {
            alert(PIPELINE_HINWEIS, APP_NAME); return;
            try {''', 1),
    ('    var VERSION = "' + BM_VERSION + '";\n', '    var VERSION = "' + BM_VERSION + '";\n' + PIPELINE_HINWEIS, 1),
    # Zeichenzaehlung ohne Nikud
    ('            next = current.heChars + visibleLength(seg.he);', '            next = current.heChars + planLength(seg.he);', 1),
    ('            current.heChars += visibleLength(seg.he);', '            current.heChars += planLength(seg.he);', 1),
    ('"\\t" + visibleLength(seg.he) + "\\toffen"', '"\\t" + planLength(seg.he) + "\\toffen"', 1),
    ('            c=visibleLength(s.he);', '            c=planLength(s.he);', 1),
    ('    function visibleLength(s){return trim(stripTags(s)).length;}',
     '    function visibleLength(s){return trim(stripTags(s)).length;}\n'
     '    // Rav Pe’alim: Zaehlung ohne Nikud/Teamim (U+0591–U+05C7), wie die Pipeline.\n'
     '    function planLength(s){return visibleLength(String(s||"").replace(/[\\u0591-\\u05C7]/g,""));}', 1),
    ('        var heVisible=visibleLength(heText),enVisible=visibleLength(enText);',
     '        var heVisible=planLength(heText),enVisible=visibleLength(enText);', 1),
    # Batch-Hinweise fuer Rav Pe'alim
    ('''        out.push("<!-- Englische Parashah-Ueberschrift: uebliche englische Transliteration in <en_title>; keine Uebersetzung und keine Format-Tags. InDesign setzt 15 pt Bold. -->");''',
     '''        out.push("<!-- Rav Pe’alim: <en_title> ist mit dem Titel der Ausgabe gefuellt (Siman-Zaehlung, Konkordanz zum Druck) und bleibt unveraendert. -->");
        out.push("<!-- Rav Pe’alim: Frage (שאלה) und Antwort (תשובה) als Question / Response; Kuerzel nach out/glossar/Rav_Pealim_GLOSSAR.tsv aufloesen, kabbalistische Begriffe nach Rav_Pealim_Glossar_Kabbala.tsv; Zitatketten vollstaendig, Werke nach Rav_Pealim_Werkverzeichnis.tsv; Verweise auf Rav Pe’alim nach Rav_Pealim_Querverweise.tsv. -->");''', 1),
    # Bandgroesse: Ziel 600, Sperre 800, EN-Erweiterung 2,375
    ('var TARGET_PAGES = 540;', 'var TARGET_PAGES = ' + str(C.TARGET_PAGES) + ';', 1),
    ('var EN_EXPANSION = 1.95;', 'var EN_EXPANSION = ' + str(C.EN_EXPANSION) + ';', 1),
    ('planning target: 540 pages, including 12 reserved pages',
     'planning target: ' + str(C.TARGET_PAGES) + ' pages, including 12 reserved pages (Rav Pe’alim)', 1),
    ('English expansion factor 1.95', 'English expansion factor ' + str(C.EN_EXPANSION) + ' (Rav Pe’alim responsa)', 1),
    ('var MAX_PAGES = 600;', 'var MAX_PAGES = ' + str(C.MAX_PAGES) + ';', 1),
    ('600-Seiten-', str(C.MAX_PAGES) + '-Seiten-', 7),
    ('maximal 600 Seiten.', 'maximal ' + str(C.MAX_PAGES) + ' Seiten.', 1),
    ('hält 600 Seiten als absolute Grenze', 'hält ' + str(C.MAX_PAGES) + ' Seiten als absolute Grenze', 1),
    ('Bei 600 physischen Seiten', 'Bei ' + str(C.MAX_PAGES) + ' physischen Seiten', 1),
    ('hard maximum: 600 physical pages', 'hard maximum: ' + str(C.MAX_PAGES) + ' physical pages', 1),
    ('600-page hard limit', str(C.MAX_PAGES) + '-page hard limit', 1),
    ('the 600-page limit', 'the ' + str(C.MAX_PAGES) + '-page limit', 1),
]

RH_KOPF = '''/*
    Rav Pe’alim · Kolumnentitel-Manager v''' + RH_VERSION + '''  (''' + STAND + ''')
    Erzeugt mit Rav_Pealim/indesign/erzeuge_rp_jsx.py aus
    Ben_Ish_Chai_Running_Header_Manager_v1_0_3.jsx und rh_abschnitte_bausteine.js
    (Stand Leshon Chakhamim Kolumnentitel-Manager v1.0.4).

    Kolumnentitel = Siman-Ueberschrift der Seite, genau wie im Dokument: linke
    Seiten die englische Ueberschrift aus dem EN-Textfluss, rechte Seiten die
    hebraeische aus dem HE-Textfluss (Absatzformate "RPL · Section · English" /
    "RPL · Abschnitt · Hebräisch"): "''' + EN_KOPF + ''' · {ABSCHNITT}" /
    "''' + HE_KOPF + ''' · {ABSCHNITT_HE}". Vorlage "Gruppe" ({GRUPPE} = Abteilung · Teil)
    bleibt waehlbar.
      - Seitenregel (Reiter 1): Abschnitt am Seitenanfang (Standard), erste oder
        letzte Ueberschrift der Seite.
      - Platzmangel: Kurztitel je Siman aus der Pipeline ("Sod Yesharim 18",
        "Orach Chayim II:14"), dann kleinere Schrift bis zum Minimum, zuletzt
        wortweise Kuerzung mit "…", zuletzt nur der Werktitel; passt nichts,
        bleibt die Seite ohne Kopfrahmen (nie Uebersatz) und steht im Bericht.
      - Kopfrahmen werden bei jedem Lauf frisch angelegt und neutral gesetzt
        (keine geerbten Absatzformate, ganze Textkette ersetzt).
      - Fettung des Abschnittstitels standardmaessig aus.
      - kein Jahrgang ({YEAR} bleibt leer)
      - ExtendScript (ES3): test_rp.py prueft alle Skripte auf reservierte Woerter.
*/
'''


def sections():
    return C.build_edition(C.load_werk())


def katalog_js(secs):
    """Gruppen-Katalog (buildParashahCatalogue): Gruppen in Bandfolge, Aliase = Siman-Titel."""
    gl = C.lade_gliederung()
    gr = C.gruppen(gl)
    folge = list(dict.fromkeys(s['gruppe'] for s in secs))
    zeilen = []
    for k in folge:
        e = gr[k]
        he_alias = [s['he_title'] for s in secs if s['gruppe'] == k]
        en_alias = [s['en_title'] for s in secs if s['gruppe'] == k]
        zeilen.append('            [{}, {}, {}, {}, {}]'.format(
            json.dumps(k, ensure_ascii=False), json.dumps(e['he'], ensure_ascii=False),
            json.dumps(e['en'], ensure_ascii=False),
            json.dumps([e['en'].lower()] + [a.lower() for a in en_alias], ensure_ascii=False),
            json.dumps(he_alias, ensure_ascii=False)))
    return ',\n'.join(zeilen), len(folge)


def abschnitte_katalog(secs):
    """Abschnitte in Bandfolge: [HE-Titel, EN-Titel, HE-Kurztitel, EN-Kurztitel, Gruppe]."""
    return [[s['he_title'], s['en_title'], s['he_kurz'], s['en_kurz'], s['gruppe']] for s in secs]


def funktionsblock(text, name):
    """Vollstaendige Funktion 'name' (Einzug 4) bis zur schliessenden Klammer '    }'."""
    kopf = '    function ' + name + '('
    if text.count(kopf) != 1:
        raise SystemExit('Funktion {} {}x gefunden'.format(name, text.count(kopf)))
    a = text.index(kopf)
    b = text.index('\n    }\n', a) + len('\n    }\n')
    if '\n    function ' in text[a + 1:b]:
        raise SystemExit('Funktionsende von {} nicht eindeutig'.format(name))
    return text[a:b]


def bausteine():
    """rh_abschnitte_bausteine.js -> {'EINFUEGEN': text, 'ERSETZE name': text}"""
    out, name, buf = collections.OrderedDict(), None, []
    for zeile in RH_BAUSTEINE.read_text(encoding='utf-8').split('\n'):
        if zeile.startswith('//@@ '):
            if name:
                out[name] = '\n'.join(buf).rstrip('\n') + '\n'
            name, buf = zeile[5:].strip(), []
        elif name:
            buf.append(zeile)
    if name:
        out[name] = '\n'.join(buf).rstrip('\n') + '\n'
    return out


def rh_ersetzungen(secs=None):
    secs = secs or sections()
    kat, n = katalog_js(secs)
    rh_src = RH_SRC.read_text(encoding='utf-8')
    a0 = rh_src.index('    function buildParashahCatalogue(){\n        var a=[\n')
    a1 = rh_src.index('        ];\n', a0)
    alt_katalog = rh_src[a0:a1 + len('        ];\n')]
    neu_katalog = ('    function buildParashahCatalogue(){\n'
                   '        // Rav Pe’alim: Gruppen (Abteilung · Teil); Aliase = Siman-Titel der Ausgabe\n'
                   '        var a=[\n' + kat + '\n        ];\n')
    ers = [
        ('#targetengine "BenIshChaiRunningHeaderManager_v103"',
         '#targetengine "RavPealimRunningHeaderManager_v' + RH_VERSION.replace('.', '') + '"', 1),
        ('var APP_NAME = "Ben Ish Chai · Kolumnentitel-Manager";', 'var APP_NAME = "Rav Pe’alim · Kolumnentitel-Manager";', 1),
        ('var VERSION = "1.0.3";', 'var VERSION = "' + RH_VERSION + '";', 1),
        ('"BEN ISH CHAI · {PARASHAH}"', '"' + EN_KOPF + ' · {PARASHAH}"', 3),
        ('"BEN ISH CHAI · {YEAR} · {PARASHAH}"', '"' + EN_KOPF + ' · {PARASHAH}"', 1),
        ('"בן איש חי · פרשת {PARASHAH_HE}"', '"' + HE_KOPF + ' · {PARASHAH_HE}"', 3),
        ('"בן איש חי · הלכות {YEAR_HE} · פרשת {PARASHAH_HE}"', '"' + HE_KOPF + ' · {PARASHAH_HE}"', 1),
        ('File.openDialog("Ben-Ish-Chai BILINGUAL.txt wählen"', 'File.openDialog("Rav-Pe’alim BILINGUAL.txt wählen"', 1),
        (alt_katalog, neu_katalog, 1),
        ('            aliases=[a[i][1]];\n            if(a[i].length>4&&a[i][4])for(j=0;j<a[i][4].length;j++)aliases.push(a[i][4][j]);',
         '            aliases=[a[i][1]];\n            if(a[i].length>4&&a[i][4])for(j=0;j<a[i][4].length;j++)aliases.push(a[i][4][j]);'
         '\n            // Rav Pe’alim: Gruppenname allein ist kein Abschnittstitel\n            aliases.shift();', 1),
        ('''            // Longest aliases first would be ideal; list is already specific.
            for(j=0;j<p.heAliases.length;j++){
                a=" "+normalizeHebrewWords(p.heAliases[j])+" ";
                if(t.indexOf(a)>=0)return p;
            }''', '''            // Rav Pe’alim: nur vollstaendige Gleichheit mit einem Siman-Titel
            for(j=0;j<p.heAliases.length;j++){
                a=" "+normalizeHebrewWords(p.heAliases[j])+" ";
                if(t===a)return p;
            }''', 1),
        ('''            a=" "+normalizeEnglishWords(p.en)+" ";if(t.indexOf(a)>=0)return p;
            for(j=0;j<p.enAliases.length;j++){
                a=" "+normalizeEnglishWords(p.enAliases[j])+" ";if(t.indexOf(a)>=0)return p;
            }''', '''            for(j=0;j<p.enAliases.length;j++){
                a=" "+normalizeEnglishWords(p.enAliases[j])+" ";if(t===a)return p;
            }''', 1),
    ]
    return ers + rh_abschnitt_ersetzungen(rh_src, secs), n


def rh_abschnitt_ersetzungen(rh_src, secs):
    """Kolumnentitel = Siman-Ueberschrift (Funktionen aus rh_abschnitte_bausteine.js)."""
    bs = bausteine()
    zeilen = ',\n'.join('            ' + json.dumps(x, ensure_ascii=False) for x in abschnitte_katalog(secs))
    einfuegen = bs.pop('EINFUEGEN')
    if einfuegen.count('/*@ABSCHNITTE@*/') != 1:
        raise SystemExit('Platzhalter /*@ABSCHNITTE@*/ fehlt')
    einfuegen = einfuegen.replace('/*@ABSCHNITTE@*/', zeilen)
    ers = []
    for k, neu in bs.items():
        art, name = k.split(None, 1)
        if art != 'ERSETZE':
            raise SystemExit('Unbekannter Baustein ' + k)
        ers.append((funktionsblock(rh_src, name), neu, 1))
    ers += [
        ('    function buildParashahCatalogue(){\n', einfuegen + '\n    function buildParashahCatalogue(){\n', 1),
        ('    var PARASHOT = buildParashahCatalogue();\n',
         '    var PARASHOT = buildParashahCatalogue();\n    var SECTIONS = buildSectionCatalogue();\n', 1),
        ('"Kurz · empfohlen für A5",\n            "Lang · mit Jahr",',
         '"Siman-Überschrift · empfohlen",\n            "Gruppe (Abteilung · Teil)",', 1),
        ('Bei Platzmangel automatisch Kurzfassung', 'Bei Platzmangel automatisch Kurztitel', 1),
        ('var enTemplateEdit = enTplRow.add("edittext", undefined, "' + EN_KOPF + ' · {PARASHAH}");',
         'var enTemplateEdit = enTplRow.add("edittext", undefined, "' + EN_KOPF + ' · {ABSCHNITT}");', 1),
        ('var heTemplateEdit = heTplRow.add("edittext", undefined, "' + HE_KOPF + ' · {PARASHAH_HE}");',
         'var heTemplateEdit = heTplRow.add("edittext", undefined, "' + HE_KOPF + ' · {ABSCHNITT_HE}");', 1),
        ('''            if (idx === 0) {
                enTemplateEdit.text = "''' + EN_KOPF + ''' · {PARASHAH}";
                heTemplateEdit.text = "''' + HE_KOPF + ''' · {PARASHAH_HE}";
            } else if (idx === 1) {
                enTemplateEdit.text = "''' + EN_KOPF + ''' · {PARASHAH}";
                heTemplateEdit.text = "''' + HE_KOPF + ''' · {PARASHAH_HE}";
            }''', '''            if (idx === 0) {
                enTemplateEdit.text = "''' + EN_KOPF + ''' · {ABSCHNITT}";
                heTemplateEdit.text = "''' + HE_KOPF + ''' · {ABSCHNITT_HE}";
            } else if (idx === 1) {
                enTemplateEdit.text = "''' + EN_KOPF + ''' · {GRUPPE}";
                heTemplateEdit.text = "''' + HE_KOPF + ''' · {GRUPPE_HE}";
            }''', 1),
        ('"Platzhalter: {PARASHAH} · {PARASHAH_HE} · {YEAR} · {YEAR_HE}.  Bei unbekanntem Jahr wird niemals geraten; '
         'bei Bedarf fällt der Lauf auf die Kurzvorlage zurück."',
         '"Platzhalter: {ABSCHNITT} · {ABSCHNITT_HE} = Siman-Überschrift der Seite (genau wie im Dokument; '
         'bei Platzmangel Kurztitel, kleinere Schrift, zuletzt Kürzung mit …) · {GRUPPE} · {GRUPPE_HE} = Abteilung · Teil."', 1),
        ('        bodyOnlyCheck.value = true;\n',
         '        bodyOnlyCheck.value = true;\n'
         '        var pageRuleList = analyzePanel.add("dropdownlist", undefined, [\n'
         '            "Seitenregel: Abschnitt am Seitenanfang",\n'
         '            "Seitenregel: erste Überschrift der Seite",\n'
         '            "Seitenregel: letzte Überschrift der Seite"\n'
         '        ]);\n'
         '        pageRuleList.selection = 0;\n'
         '        pageRuleList.helpTip = "Welche Überschrift im Kolumnentitel steht: der Siman, in dem die Seite beginnt '
         '(Standard; beginnt oben auf der Seite ein Siman, gilt er), der erste oder der letzte auf der Seite '
         'beginnende Siman.";\n', 1),
        ('cfg.bodyOnly = bodyOnlyCheck.value;',
         'cfg.bodyOnly = bodyOnlyCheck.value;\n            cfg.pageRule = pageRuleList.selection ? pageRuleList.selection.index : 0;', 1),
        ('Parashah-Name auf der ersten Parashah-Seite fett hervorheben', 'Siman-Titel auf der Seite seines Beginns fett hervorheben', 1),
        ('        emphasizeStartCheck.value = true;\n', '        emphasizeStartCheck.value = false;\n', 1),
        ('Der Kolumnentitel bleibt auf der Startseite sichtbar. Nur der Parashah-Teil wird stärker gesetzt; '
         'die restliche Kopfzeile bleibt unverändert.',
         'Der Kolumnentitel bleibt auf der Seite des Siman-Beginns sichtbar; nur der Titel wird stärker gesetzt.', 1),
        ('Legacy-Ausnahme: auf der ersten Seite einer neuen Parashah den Kolumnentitel ausblenden',
         'Ausnahme: auf der Seite eines Siman-Beginns keinen Kolumnentitel setzen', 1),
        ('"Manueller Parashah-Bereich"', '"Manueller Bereich (eigener Kolumnentitel)"', 1),
        ('Für einen manuellen Override werden englischer und hebräischer Parashah-Name benötigt.',
         'Für einen manuellen Override werden englischer und hebräischer Titel benötigt.', 1),
        ('erste Bereichsseite = neuer Parashah-Start', 'erste Bereichsseite = Siman-Beginn', 1),
        ('Ohne TXT greift automatisch der Parashah-Fallback.',
         'Ohne TXT gilt der eingebaute Siman-Katalog (Kurztitel aus der Pipeline).', 1),
    ]
    return ers


def norm_hebr(s):
    """normalizeHebrewWords() der JSX-Skripte."""
    s = re.sub('[֑-ׇ]', '', C.strip_tags(s or ''))
    s = re.sub('[^א-ת ]+', ' ', s)
    return re.sub(' +', ' ', s).strip()


def toc_bauen(dst=None, secs=None, mafteach=None):
    """Inhaltsverzeichnis-Skript: Vorlage + Katalog (Gruppen, Siman-Titel, Inhaltsangaben der Mafteachot)."""
    import rp_struktur as ST
    secs = secs or sections()
    if mafteach is None:
        werk = C.load_werk()
        mafteach, _ = ST.ordne_mafteach(werk, ST.lies_mafteach(werk))
    gr = C.gruppen(C.lade_gliederung())
    gruppen = collections.OrderedDict()
    for s in secs:
        gruppen.setdefault(s['gruppe'], [gr[s['gruppe']]['he'], gr[s['gruppe']]['en']])
    abschnitte = [[norm_hebr(s['he_title']), s['gruppe'], mafteach.get(s['quelle_ref'], {}).get('inhalt', '')]
                  for s in secs]
    text = TOC_SRC.read_text(encoding='utf-8')
    text = ersetze(text, '/*@GRUPPEN@*/', json.dumps(gruppen, ensure_ascii=False))
    text = ersetze(text, '/*@ABSCHNITTE@*/', '[\n        ' + ',\n        '.join(
        json.dumps(a, ensure_ascii=False) for a in abschnitte) + '\n    ]')
    text = ersetze(text, '    Vorlage; das ausfuehrbare Skript erzeugt indesign/erzeuge_rp_jsx.py mit dem\n',
                   '    Erzeugt mit Rav_Pealim/indesign/erzeuge_rp_jsx.py aus vorlage_Inhaltsverzeichnis.jsx mit dem\n')
    dst = Path(dst or TOC_DST)
    dst.write_text(text, encoding='utf-8', newline='')
    return dst, hashlib.sha256(dst.read_bytes()).hexdigest(), len(abschnitte)


def baue(src, dst, kopf, ersetzungen):
    text = src.read_text(encoding='utf-8')
    quelle_sha = hashlib.sha256(src.read_bytes()).hexdigest()
    for alt, neu, n in ersetzungen:
        text = ersetze(text, alt, neu, n)
    text = text.replace('BIH', C.KENNUNG)
    if 'BIH' in text or 'Ben_Ish_Chai_Band' in text:
        raise SystemExit('Restkennung in ' + dst.name)
    zeilen = text.split('\n')
    i = next(k for k, l in enumerate(zeilen) if not l.startswith('#'))
    text = ('\n'.join(zeilen[:i]) + '\n\n' + kopf.replace('*/', '    Quelle sha256 {}\n*/'.format(quelle_sha), 1) +
            '\n'.join(zeilen[i:]))
    dst.write_text(text, encoding='utf-8', newline='')
    return dst, hashlib.sha256(dst.read_bytes()).hexdigest()


def main():
    secs = sections()
    rh, n = rh_ersetzungen(secs)
    for d, s in (baue(BM_SRC, BM_DST, BM_KOPF, BM_ERSETZUNGEN), baue(RH_SRC, RH_DST, RH_KOPF, rh)):
        print('{}  sha256 {}'.format(d.name, s))
    print('Kolumnentitel-Katalog: {} Gruppen, {} Simanim/Abschnitte'.format(n, len(secs)))
    d, s, k = toc_bauen(secs=secs)
    print('{}  sha256 {}  ({} Abschnitte)'.format(d.name, s, k))
    return 0


if __name__ == '__main__':
    sys.exit(main())
