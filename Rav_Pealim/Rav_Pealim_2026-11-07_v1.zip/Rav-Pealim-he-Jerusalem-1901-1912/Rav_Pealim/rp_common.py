# -*- coding: utf-8 -*-
"""
Rav Pe'alim (שו"ת רב פעלים) · gemeinsame Grundlagen aller Arbeitsschritte.

Responsen des R. Yosef Chayim von Bagdad (Ben Ish Chai) in vier Teilen
(Jerusalem 1901–1912), je mit dem kabbalistischen Anhang "Sod Yesharim".
Gesetzt im Format von Ben Ish Chai Halakha (Buchmanager v1.0.17, A5): Abschnitt
= ein Siman (bzw. Hakdama, Petichah, Kuntres), Segment = ein Absatz der Quelle.

Quellenmodell (Sefaria "Responsa Rav Pealim - he - Rav Pealim, Jerusalem 1901-1912")
-----------------------------------------------------------------------------------
    text["Volume I"]["Introduction"]          Absaetze            (Ref "Volume I, Introduction 2")
    text["Volume I"]["Preface"]               Absaetze            (nur Teil I)
    text["Volume I"]["Index"]                 Listen je Abteilung (Mafteachot des Drucks)
    text["Volume I"]["Orach Chayim"]          Simanim → Absaetze  (Ref "Volume I, Orach Chayim 5:3")
    … "Yoreh Deah", "Even HaEzer", "Choshen Mishpat" (ab Teil II), "Sod Yesharim"
    text["Volume III"]["Kuntres Beit Tefillah"] Absaetze

Gliederung der Ausgabe (gliederung.json → reihen): nach Abteilungen ueber alle
vier Teile. Pilot ist Sod Yesharim (64 Simanim, durchnummeriert 1–64), danach
Orach Chayim, Yoreh Deah, Even HaEzer, Choshen Mishpat; jede Reihe beginnt
einen neuen Band. Die Mafteachot werden nicht gesetzt (neues Inhaltsverzeichnis),
ihre Inhaltsangaben stehen in der Konkordanz.

Lizenz: gemeinfrei (Sefaria "Public Domain", Vorlage Jerusalem 1901–1912,
digitalisiert von Sefaria; source/LIZENZ_UND_NACHWEIS.md).
"""
import hashlib
import json
import re
import sys
import unicodedata
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent


def _finde_repo(start):
    for d in [start] + list(start.parents):
        if (d / 'glossary_he.json').exists() and (d / 'ben-yehoyada-pipeline-v3_2_1_2026-10-05.zip').exists():
            return d
    return start.parents[1]


REPO = _finde_repo(HERE)

WERK_EN = 'Rav Pe’alim'
WERK_EN_ASCII = 'Rav Pealim'
WERK_HE = 'רב פעלים'
WERK_HE_VOLL = 'שו״ת רב פעלים'
WERK_TAG = 'Rav_Pealim'
PROJECT_ATTR = 'Rav Pealim'
KENNUNG = 'RPL'                      # InDesign-Labels, Absatzformate, Segment-IDs
ID_PREFIX = KENNUNG + '-'
UNTERTITEL_DE = 'Responsen in vier Teilen mit dem Anhang Sod Yesharim'
UNTERTITEL_EN = 'Responsa in Four Parts, with the Appendix Sod Yesharim'

SOURCE_JSON = HERE / 'source' / 'Responsa_Rav_Pealim_-_he_-_Rav_Pealim_Jerusalem_1901-1912.json'
SOURCE_JSON_SHA256 = '9f93272b88795936ee47b15e449725d2968cdf70b44133a256f8c30a9ae32bbf'
SEFARIA_TITEL = 'Responsa Rav Pealim'
SEFARIA_URL = ('https://www.sefaria.org/download/version/'
               'Responsa%20Rav%20Pealim%20-%20he%20-%20Rav%20Pealim%2C%20Jerusalem%201901-1912.json')
LIZENZ = 'Public Domain'
NACHWEIS_HE = ('הטקסט העברי: שו״ת רב פעלים, ירושלים תרס״א–תרע״ב (1901–1912), '
               'דיגיטציה: ספריא (Sefaria) על פי עותק הספרייה הלאומית; נחלת הכלל.')
NACHWEIS_EN = ('Hebrew text: Responsa Rav Pe’alim, Jerusalem 1901–1912, digitized by Sefaria from the copy of the '
               'National Library of Israel (NNL_ALEPH001933708); public domain.')

GLIEDERUNG = HERE / 'gliederung.json'
PIPELINE_ZIP = REPO / 'ben-yehoyada-pipeline-v3_2_1_2026-10-05.zip'
PIPELINE_ZIP_BLOB = '2eab4448a8e1e0beec0c9cc2304e6154f06d95f5'
GLOSSARY = REPO / 'glossary_he.json'
BIC_JSX = REPO / 'Ben_Ish_Chai_Bilingual_Book_Manager_v1_0_17-Milestone.jsx'
BIC_RH_JSX = REPO / 'Ben_Ish_Chai_Running_Header_Manager_v1_0_3.jsx'
LC_DIR = REPO / 'Leshon-Chakhamim-he-Bakhshi-Edition-2021' / 'Leshon_Chakhamim'
OYC_DIR = REPO / 'Od-Yosef-Chai-Halakhot-he-Jerusalem-1910' / 'Od_Yosef_Chai_Halakhot'

# --- Kalibrierung ----------------------------------------------------------------
# Satz wie Ben_Ish_Chai_Bilingual_Book_Manager_v1_0_17 (A5, Keter YG 10/12, Cambria 9/10,8):
PAGE_W_MM = 148
PAGE_H_MM = 210
HE_CHARS_PER_PAGE = 1050
EN_CHARS_PER_PAGE = 2000
HE_LEADING_PT = 12
# Responsen: Kuerzel, Stellenangaben und Zitatketten werden im Englischen ausgeschrieben.
# Planwert aus der Projektvorgabe (4,23 Mio. Zeichen ≈ 5.020 Seiten ≈ 842 HE-Zeichen je Seite);
# Ben Ish Chai (Halakha) misst 1,95. Der Bandplan zeigt beide Werte.
EN_EXPANSION = 2.375
EN_EXPANSION_BIC = 1.95
# Bandgroesse: Sod Yesharim (≈ 570 Seiten) muss ein Band sein -> Ziel 600 statt 540;
# harte Sperre wie Leshon Chakhamim (Buchmanager v1.0.1) 800 Seiten.
MAX_PAGES = 800
TARGET_PAGES = 600
RESERVED_PAGES = 12
BODY_TARGET = TARGET_PAGES - RESERVED_PAGES
BATCH_MAX_SEGMENTS = 12
BATCH_MAX_CHARS = 30000

# --- Teile und Abteilungen ---------------------------------------------------------
TEILE = ['Volume I', 'Volume II', 'Volume III', 'Volume IV']
ROEMISCH = {'Volume I': 'I', 'Volume II': 'II', 'Volume III': 'III', 'Volume IV': 'IV'}
VORSPANN = ('Introduction', 'Preface')
NICHT_GESETZT = ('Index',)

# --- Zeichen -----------------------------------------------------------------------
HEB_LETTER = 'א-ת'
MARKS = '֑-ׇ'
MAQAF = '־'
NIKUD_RE = re.compile('[֑-ׇ]')
TAG_RE = re.compile(r'<[^>]+>')
QUOTE_MAP = str.maketrans({'״': '"', '”': '"', '“': '"', '„': '"', '׳': "'", '’': "'", '‘': "'"})
WORD_RE = re.compile('[' + HEB_LETTER + MARKS + '"\'׳״“”‘’]+')
ERLAUBTE_TAGS = {'b', 'i', 'small', 'sup', 'br'}
TITEL_TRENNER = ' · '


def strip_tags(s):
    return TAG_RE.sub('', s or '')


def strip_nikud(s):
    return NIKUD_RE.sub('', s or '')


def visible_length(s):
    """visibleLength() des BIC-JSX: trim(stripTags(s)).length."""
    return len(strip_tags(s).strip())


def plan_length(s):
    """planLength() des RP-Buchmanagers: ohne Nikud/Teamim (U+0591–U+05C7)."""
    return len(re.sub('[֑-ׇ]', '', strip_tags(s)).strip())


def norm_quotes(s):
    return (s or '').translate(QUOTE_MAP)


def skeleton(word):
    w = norm_quotes(strip_nikud(unicodedata.normalize('NFC', word or '')))
    w = re.sub('[׃׀]', '', w)
    return w.strip('"\'')


def words(text):
    t = strip_tags(text or '').replace(MAQAF, ' ')
    return [m.group(0) for m in WORD_RE.finditer(t) if re.search('[' + HEB_LETTER + ']', skeleton(m.group(0)))]


def klartext(html):
    return re.sub(r'\s+', ' ', strip_tags((html or '').replace('<br>', ' '))).strip()


def normalisiere_html(html):
    """Sefaria-HTML -> Tags des Buchmanagers: <strong> -> <b>, <big> entfaellt,
    nur b/i/small/sup/br bleiben. Leere Tags werden entfernt."""
    s = html or ''
    s = re.sub(r'</?big\s*>', '', s)
    s = re.sub(r'<strong\s*>', '<b>', s)
    s = re.sub(r'</strong\s*>', '</b>', s)
    s = re.sub(r'<br\s*/?>', '<br>', s)

    def tag(m):
        name = m.group(2).lower()
        return m.group(0) if name in ERLAUBTE_TAGS else ''
    s = re.sub(r'<(/?)([A-Za-z]+)[^>]*>', tag, s)
    for _ in range(3):
        s = re.sub(r'<(b|i|small|sup)>(\s*)</\1>', r'\2', s)     # leeres Tag weg, Leerraum bleibt
    s = re.sub(r'</b>(\s*)<b>', r'\1', s)
    return s.strip()


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def git_blob_sha(path):
    data = Path(path).read_bytes()
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


# --- Hebraeische Zahlbuchstaben -------------------------------------------------------
GEMATRIA = dict(zip('אבגדהוזחטיכלמנסעפצקרשת', [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 20, 30, 40, 50, 60, 70,
                                              80, 90, 100, 200, 300, 400]))
GEMATRIA.update({'ך': 20, 'ם': 40, 'ן': 50, 'ף': 80, 'ץ': 90})


# Ausgeschriebene Buchstabennamen als Zahl, wie im Druck: וא"ו = 6, זיי"ן = 7, יו"ד = 10, למ"ד = 30, נו"ן = 50
BUCHSTABENNAME = {'ואו': 6, 'וו': 6, 'זין': 7, 'זיין': 7, 'יוד': 10, 'ויוד': 10, 'למד': 30, 'נון': 50}


def zahlwert(s):
    """Zahlwert einer Stellenzahl ('טו"ב' = 17 ergibt sich aus der Summe)."""
    t = re.sub('[^א-ת]', '', strip_nikud(norm_quotes(s or '')))
    if t in BUCHSTABENNAME:
        return BUCHSTABENNAME[t]
    return sum(GEMATRIA.get(c, 0) for c in t)


def hebr_zahl(n):
    """1 -> א, 15 -> טו, 16 -> טז, 77 -> עז (ohne Zeichen)."""
    if n == 15:
        return 'טו'
    if n == 16:
        return 'טז'
    out = ''
    for wert, z in ((400, 'ת'), (300, 'ש'), (200, 'ר'), (100, 'ק'), (90, 'צ'), (80, 'פ'), (70, 'ע'),
                    (60, 'ס'), (50, 'נ'), (40, 'מ'), (30, 'ל'), (20, 'כ'), (10, 'י'), (9, 'ט'), (8, 'ח'),
                    (7, 'ז'), (6, 'ו'), (5, 'ה'), (4, 'ד'), (3, 'ג'), (2, 'ב'), (1, 'א')):
        while n >= wert:
            if n in (15, 16):
                return out + hebr_zahl(n)
            out += z
            n -= wert
    return out


def hebr_zahl_g(n):
    """Mit Geresch/Gerschajim: 1 -> א׳, 18 -> י״ח, 64 -> ס״ד."""
    z = hebr_zahl(n)
    return z + '׳' if len(z) == 1 else z[:-1] + '״' + z[-1]


# --- Gliederung -------------------------------------------------------------------------
def lade_gliederung(path=None):
    path = Path(path or GLIEDERUNG)
    return json.loads(path.read_text(encoding='utf-8'))


# --- Werkmodell -------------------------------------------------------------------------
def load_werk(path=None):
    """Sefaria-JSON -> Werkmodell.

    {'meta': {...}, 'teile': [{'key': 'Volume I', 'nr': 1,
        'vorspann': {'Introduction': [abs], 'Preface': [abs]},
        'abteilungen': {'Orach Chayim': [{'nr', 'ref', 'leer', 'absaetze': [abs]}], …},
        'kuntres': {'Kuntres Beit Tefillah': [abs]},
        'index': [[html, …], …]}]}
    abs = {'ref', 'j', 'html'}
    """
    path = Path(path or SOURCE_JSON)
    d = json.loads(path.read_text(encoding='utf-8'))
    teile = []
    for nr, key in enumerate(TEILE, start=1):
        t = d['text'][key]
        e = {'key': key, 'nr': nr, 'vorspann': {}, 'abteilungen': {}, 'kuntres': {}, 'index': t.get('Index') or []}
        for name, inhalt in t.items():
            if name in NICHT_GESETZT:
                continue
            if inhalt and isinstance(inhalt[0], list):
                e['abteilungen'][name] = [
                    {'nr': i, 'ref': '{}, {} {}'.format(key, name, i), 'leer': not any(klartext(p) for p in sim),
                     'absaetze': [{'ref': '{}, {} {}:{}'.format(key, name, i, j), 'j': j, 'html': p}
                                  for j, p in enumerate(sim, start=1)]}
                    for i, sim in enumerate(inhalt, start=1)]
            else:
                ziel = e['vorspann'] if name in VORSPANN else e['kuntres']
                ziel[name] = [{'ref': '{}, {} {}'.format(key, name, j), 'j': j, 'html': p}
                              for j, p in enumerate(inhalt, start=1)]
        teile.append(e)
    meta = {k: d.get(k) for k in ('title', 'heTitle', 'versionTitle', 'versionTitleInHebrew', 'versionSource',
                                  'language', 'license', 'digitizedBySefaria', 'categories')}
    meta['datei'] = str(path)
    meta['sha256'] = sha256_file(path)
    return {'meta': meta, 'teile': teile}


def teil(werk, key):
    return next(t for t in werk['teile'] if t['key'] == key)


def iter_absaetze(werk, mit_index=False):
    """(teil, bereich, siman-nr|None, absatz) aller nicht leeren Absaetze in Quellreihenfolge."""
    for t in werk['teile']:
        for name, ps in t['vorspann'].items():
            for p in ps:
                if klartext(p['html']):
                    yield t, name, None, p
        for name, sims in t['abteilungen'].items():
            for s in sims:
                for p in s['absaetze']:
                    if klartext(p['html']):
                        yield t, name, s['nr'], p
        for name, ps in t['kuntres'].items():
            for p in ps:
                if klartext(p['html']):
                    yield t, name, None, p


def _segmente(absaetze):
    out, n = [], 0
    for p in absaetze:
        if not klartext(p['html']):
            continue
        n += 1
        he = normalisiere_html(p['html'])
        out.append({'ref': p['ref'], 'j': p['j'], 'n': n, 'he': he,
                    'he_chars': visible_length(he), 'plan_chars': plan_length(he)})
    return out


def abschnitt_titel(gl, reihe, teil_key, abteilung, nr, lauf):
    """(he_title, en_title, he_kurz, en_kurz) eines Siman."""
    t = gl['teile'][teil_key]
    a = gl['abteilungen'][abteilung]
    if reihe.get('durchnummerieren'):
        he = '{} סימן {} ({} סי׳ {})'.format(a['he'], hebr_zahl_g(lauf), t['kurz_he'], hebr_zahl_g(nr))
        en = '{}, Siman {} (Part {}, Siman {})'.format(a['en'], lauf, ROEMISCH[teil_key], nr)
        return he, en, '{} {}'.format(a['he'], hebr_zahl_g(lauf)), '{} {}'.format(a['en'], lauf)
    he = '{} {} סימן {}'.format(a['he'], t['kurz_he'], hebr_zahl_g(nr))
    en = '{}, Part {}, Siman {}'.format(a['en'], ROEMISCH[teil_key], nr)
    return he, en, '{} {} {}'.format(a['kurz_he'], t['kurz_he'], hebr_zahl_g(nr)), \
        '{} {}:{}'.format(a['en'], ROEMISCH[teil_key], nr)


def build_edition(werk, gl=None):
    """Abschnitte der Ausgabe in Bandfolge (Reihen aus gliederung.json).

    [{'nr': laufend, 'reihe', 'teil', 'bereich', 'siman' (orig) | None, 'lauf' (in der Reihe) | None,
      'he_title', 'en_title', 'he_kurz', 'en_kurz', 'gruppe', 'quelle_ref',
      'segmente': [{'ref', 'j', 'n', 'he', 'he_chars', 'plan_chars'}]}]
    """
    gl = gl if gl is not None else lade_gliederung()
    secs, leer = [], []
    for r in gl['reihen']:
        for v in r.get('vorspann', []):
            tk, name = v['quelle'].split(', ')
            ps = teil(werk, tk)['vorspann'][name] if name in VORSPANN else teil(werk, tk)['kuntres'][name]
            secs.append({'reihe': r['key'], 'teil': tk, 'bereich': name, 'siman': None, 'lauf': None,
                         'he_title': v['he'], 'en_title': v['en'], 'he_kurz': v['he_kurz'], 'en_kurz': v['en_kurz'],
                         'gruppe': v['gruppe'], 'quelle_ref': v['quelle'], 'segmente': _segmente(ps)})
        lauf = 0
        for tk in TEILE:
            sims = teil(werk, tk)['abteilungen'].get(r['abteilung'], [])
            for s in sims:
                if s['leer']:
                    leer.append(s['ref'])
                    continue
                lauf += 1
                he, en, hk, ek = abschnitt_titel(gl, r, tk, r['abteilung'], s['nr'], lauf)
                secs.append({'reihe': r['key'], 'teil': tk, 'bereich': r['abteilung'], 'siman': s['nr'],
                             'lauf': lauf, 'he_title': he, 'en_title': en, 'he_kurz': hk, 'en_kurz': ek,
                             'gruppe': '{}·{}'.format(r['key'], ROEMISCH[tk]), 'quelle_ref': s['ref'],
                             'segmente': _segmente(s['absaetze'])})
        for v in r.get('anhang', []):
            tk, name = v['quelle'].split(', ')
            secs.append({'reihe': r['key'], 'teil': tk, 'bereich': name, 'siman': None, 'lauf': None,
                         'he_title': v['he'], 'en_title': v['en'], 'he_kurz': v['he_kurz'], 'en_kurz': v['en_kurz'],
                         'gruppe': v['gruppe'], 'quelle_ref': v['quelle'],
                         'segmente': _segmente(teil(werk, tk)['kuntres'][name])})
    secs = [s for s in secs if s['segmente']]
    for i, s in enumerate(secs, start=1):
        s['nr'] = i
    return secs


def gruppen(gl):
    """Gruppen (Inhaltsverzeichnis, Kolumnentitel {GRUPPE}) in Bandfolge: key -> {'he', 'en', 'reihe'}."""
    out = {}
    for r in gl['reihen']:
        a = gl['abteilungen'][r['abteilung']]
        for v in r.get('vorspann', []):
            out.setdefault(v['gruppe'], {'he': v['gruppe_he'], 'en': v['gruppe_en'], 'reihe': r['key']})
        for tk in TEILE:
            t = gl['teile'][tk]
            out['{}·{}'.format(r['key'], ROEMISCH[tk])] = {
                'he': '{} · {}'.format(a['he'], t['he']), 'en': '{} · Part {}'.format(a['en'], ROEMISCH[tk]),
                'reihe': r['key']}
        for v in r.get('anhang', []):
            out.setdefault(v['gruppe'], {'he': v['gruppe_he'], 'en': v['gruppe_en'], 'reihe': r['key']})
    return out


# --- Dateiformen wie im Buchmanager ------------------------------------------------------
def xml_escape(s):
    return (str(s or '').replace('&', '&amp;').replace('<', '&lt;')
            .replace('>', '&gt;').replace('"', '&quot;'))


def protect_cdata(s):
    return '<![CDATA[' + str(s or '').replace(']]>', ']]]]><![CDATA[>') + ']]>'


def write_bic_text(path, text):
    """writeUTF8() des JSX: BOM + Windows-Zeilenenden."""
    text = str(text or '').replace('\r\n', '\n').replace('\r', '\n').replace('\n', '\r\n')
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8-sig', newline='') as fh:
        fh.write(text)


def write_tsv(path, header, rows):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8', newline='') as fh:
        fh.write('\t'.join(header) + '\r\n')
        for r in rows:
            fh.write('\t'.join(re.sub(r'[\t\r\n]+', ' ', str(x if x is not None else '')) for x in r) + '\r\n')


def read_tsv(path):
    lines = Path(path).read_text(encoding='utf-8-sig').splitlines()
    lines = [l for l in lines if l.strip() and not l.lstrip().startswith('#')]
    if not lines:
        return []
    head = lines[0].split('\t')
    out = []
    for l in lines[1:]:
        cells = l.split('\t')
        cells += [''] * (len(head) - len(cells))
        out.append({h: c.strip() for h, c in zip(head, cells)})
    return out


def write_json(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')


def import_pipeline(path=None):
    """by_parse/by_glossary der freigegebenen Pipeline v3.2.1 aus dem Repository-ZIP."""
    path = Path(path or PIPELINE_ZIP)
    if path.is_file():
        if git_blob_sha(path) != PIPELINE_ZIP_BLOB:
            raise SystemExit('Pipeline-ZIP weicht von v3.2.1 ab: ' + str(path))
        with zipfile.ZipFile(path) as z:
            root = sorted({n.split('/')[0] for n in z.namelist()})[0]
        entry = str(path) + '/' + root
    else:
        entry = str(path)
    if entry not in sys.path:
        sys.path.insert(0, entry)
    import by_parse      # noqa: F401
    import by_glossary   # noqa: F401
    return entry
