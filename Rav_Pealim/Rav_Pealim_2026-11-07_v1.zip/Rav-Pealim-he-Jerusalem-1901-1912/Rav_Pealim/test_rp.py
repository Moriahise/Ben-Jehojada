# -*- coding: utf-8 -*-
"""
Regressionstests Rav Pe'alim (offline).

    python3 test_rp.py

Die JSX-Tests fuehren Funktionen der erzeugten Rav-Pe'alim-Skripte (aus Ben Ish Chai
v1.0.17 / RH v1.0.3, Bausteine LC RH v1.0.4) unveraendert in Node aus – ohne die
ES5-Methoden, die ExtendScript nicht kennt; ohne Node werden sie uebersprungen.
"""
import collections
import json
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import rp_bandplan as B
import rp_common as C
import rp_glossar as G
import rp_konkordanz as K
import rp_struktur as ST
import rp_uebersetzung as U
import rp_validate as V
import rp_werke as W

sys.path.insert(0, str(C.HERE / 'indesign'))
import erzeuge_rp_jsx as E  # noqa: E402

NODE = shutil.which('node')
INDESIGN = C.HERE / 'indesign'
_PLAN = {}


def plan():
    if 'p' not in _PLAN:
        _PLAN['p'] = B.plan()
    return _PLAN['p']


def jsx_function(src, name):
    lines = src.splitlines()
    for i, l in enumerate(lines):
        if re.match(r'^ {4}function ' + re.escape(name) + r'\(', l):
            if l.rstrip().endswith('}') and l.count('{') == l.count('}'):
                return l
            for j in range(i + 1, len(lines)):
                if lines[j] == '    }':
                    return '\n'.join(lines[i:j + 1])
    raise KeyError(name)


# Was ExtendScript (ES3) nicht kennt, wird vor dem Testlauf entfernt (wie test_lc.py).
ES3_UMGEBUNG = """
process.stdout;
var __ES3 = {Array: ['indexOf', 'lastIndexOf', 'forEach', 'map', 'filter', 'some', 'every', 'reduce',
                     'reduceRight', 'find', 'findIndex', 'fill', 'includes', 'keys', 'values', 'entries'],
             String: ['trim', 'trimStart', 'trimEnd', 'trimLeft', 'trimRight', 'startsWith', 'endsWith',
                      'includes', 'repeat', 'padStart', 'padEnd']};
for (var __k in __ES3) for (var __i = 0; __i < __ES3[__k].length; __i++)
    delete global[__k].prototype[__ES3[__k][__i]];
delete Function.prototype.bind; delete Object.keys; delete Object.create; delete Array.isArray; delete Date.now;
"""


def run_js(src_path, namen, extra, body, payload, es3=True):
    src = Path(src_path).read_text(encoding='utf-8')
    prog = ('\n'.join(jsx_function(src, n) for n in namen) + '\n' + extra +
            '\nvar INPUT = JSON.parse(require("fs").readFileSync(0, "utf8"));\n' + (ES3_UMGEBUNG if es3 else '') + body)
    with tempfile.NamedTemporaryFile('w', suffix='.js', delete=False, encoding='utf-8') as fh:
        fh.write(prog)
    r = subprocess.run([NODE, fh.name], input=json.dumps(payload), capture_output=True, text=True, timeout=300)
    Path(fh.name).unlink()
    if r.returncode:
        raise AssertionError(r.stderr[-3000:])
    return json.loads(r.stdout)


ES3_RESERVIERT = set('abstract boolean byte char class const debugger double enum export extends '
                     'final float goto implements import int interface long native package private '
                     'protected public short static super synchronized throws transient volatile'.split())
ES3_SCHLUESSEL = set('break case catch continue default delete do else finally for function if in '
                     'instanceof new return switch this throw try typeof var void while with null '
                     'true false'.split())
_REGEX_NACH = ES3_SCHLUESSEL - {'this', 'null', 'true', 'false'}


def es3_tokens(src):
    """Grober JS-Tokenizer (wie test_lc.py): (zeile, art, text) ohne Strings, Kommentare, Regex, #target."""
    i, n, zeile, prev = 0, len(src), 1, None
    while i < n:
        c = src[i]
        if c == '\n':
            zeile += 1
            i += 1
        elif c.isspace():
            i += 1
        elif c == '#' and (i == 0 or src[i - 1] == '\n'):
            i = src.find('\n', i) if '\n' in src[i:] else n
        elif src.startswith('//', i):
            i = src.find('\n', i) if '\n' in src[i:] else n
        elif src.startswith('/*', i):
            j = src.index('*/', i + 2) + 2
            zeile += src.count('\n', i, j)
            i = j
        elif c in '"\'':
            j = i + 1
            while src[j] != c:
                j += 2 if src[j] == '\\' else 1
            prev = ('str', '')
            i = j + 1
        elif c == '/' and (prev is None or (prev[0] == 'punkt' and prev[1] not in ')]}')
                           or (prev[0] == 'name' and prev[1] in _REGEX_NACH)):
            j, klasse = i + 1, False
            while klasse or src[j] != '/':
                if src[j] == '\\':
                    j += 1
                elif src[j] == '[':
                    klasse = True
                elif src[j] == ']':
                    klasse = False
                j += 1
            j += 1
            while j < n and (src[j].isalnum() or src[j] in '_$'):
                j += 1
            prev = ('regex', '')
            i = j
        elif c.isalpha() or c in '_$':
            j = i + 1
            while j < n and (src[j].isalnum() or src[j] in '_$'):
                j += 1
            prev = ('name', src[i:j])
            yield zeile, 'name', src[i:j]
            i = j
        elif c.isdigit():
            j = i + 1
            while j < n and (src[j].isalnum() or src[j] == '.'):
                j += 1
            prev = ('zahl', '')
            i = j
        else:
            prev = ('punkt', c)
            yield zeile, 'punkt', c
            i += 1


def es3_verstoesse(src):
    out, vorher = [], None
    for zeile, art, text in es3_tokens(src):
        if art == 'name':
            if text in ES3_RESERVIERT:
                out.append('Zeile %d: %s' % (zeile, text))
            elif text in ES3_SCHLUESSEL and vorher == '.':
                out.append('Zeile %d: .%s' % (zeile, text))
        vorher = text if art == 'punkt' else None
    return out


class Werk(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.werk, cls.gl, cls.secs, cls.segs, cls.vols = plan()

    def test_quelle_unveraendert(self):
        self.assertEqual(C.sha256_file(C.SOURCE_JSON), C.SOURCE_JSON_SHA256)
        self.assertEqual(self.werk['meta']['license'], 'Public Domain')

    def test_simanim_wie_projektvorgabe(self):
        n = collections.Counter(s['bereich'] for s in self.secs if s['siman'])
        self.assertEqual(dict(n), {'Sod Yesharim': 64, 'Orach Chayim': 185, 'Yoreh Deah': 169, 'Even HaEzer': 72,
                                   'Choshen Mishpat': 31})
        leer = [s['ref'] for t in self.werk['teile'] for a in t['abteilungen'].values() for s in a if s['leer']]
        self.assertEqual(leer, ['Volume IV, Orach Chayim 36', 'Volume IV, Orach Chayim 37', 'Volume IV, Orach Chayim 38'])

    def test_text_vollstaendig_ohne_mafteach(self):
        gesetzt = [p['ref'] for s in self.secs for p in s['segmente']]
        quelle = [p['ref'] for _, _, _, p in C.iter_absaetze(self.werk)]
        self.assertEqual(sorted(gesetzt), sorted(quelle))
        self.assertEqual(len(gesetzt), len(set(gesetzt)))
        self.assertFalse([r for r in gesetzt if 'Index' in r])
        self.assertEqual(sum(s['plan_chars'] for s in self.segs), 4179080)

    def test_n_je_siman(self):
        for s in self.secs:
            self.assertEqual([p['n'] for p in s['segmente']], list(range(1, len(s['segmente']) + 1)))

    def test_sod_yesharim_durchnummeriert(self):
        sy = [s for s in self.secs if s['reihe'] == 'SY']
        self.assertEqual([s['lauf'] for s in sy], list(range(1, 65)))
        self.assertEqual([s['nr'] for s in sy], list(range(1, 65)))          # Pilot: Band 01 vorn
        teile = collections.Counter(s['teil'] for s in sy)
        self.assertEqual([teile[t] for t in C.TEILE], [17, 14, 13, 20])
        x = {s['quelle_ref']: s for s in sy}
        self.assertEqual(x['Volume II, Sod Yesharim 1']['lauf'], 18)
        self.assertEqual(x['Volume II, Sod Yesharim 1']['he_title'], 'סוד ישרים סימן י״ח (ח״ב סי׳ א׳)')
        self.assertEqual(x['Volume II, Sod Yesharim 1']['en_title'], 'Sod Yesharim, Siman 18 (Part II, Siman 1)')
        self.assertEqual(x['Volume IV, Sod Yesharim 20']['en_kurz'], 'Sod Yesharim 64')

    def test_titel_eindeutig(self):
        for k in ('he_title', 'en_title', 'he_kurz', 'en_kurz'):
            werte = [s[k] for s in self.secs]
            self.assertEqual(len(werte), len(set(werte)), k)
        for s in self.secs:
            self.assertFalse(re.search('[֐-׿]', s['en_title']))

    def test_reihenfolge_der_reihen(self):
        folge = list(dict.fromkeys(s['reihe'] for s in self.secs))
        self.assertEqual(folge, ['SY', 'OC', 'YD', 'EH', 'CM'])
        oc = [s for s in self.secs if s['reihe'] == 'OC']
        self.assertEqual([s['bereich'] for s in oc[:4]], ['Introduction', 'Preface', 'Introduction', 'Introduction'])
        self.assertEqual(oc[-1]['bereich'], 'Kuntres Beit Tefillah')

    def test_hebr_zahlen(self):
        self.assertEqual([C.hebr_zahl_g(n) for n in (1, 10, 15, 16, 18, 64, 185)],
                         ['א׳', 'י׳', 'ט״ו', 'ט״ז', 'י״ח', 'ס״ד', 'קפ״ה'])
        self.assertEqual([C.zahlwert(x) for x in ('וא"ו', 'זיי"ן', 'יו"ד', 'למ"ד', 'נו"ן', 'ט"ל', 'טו"ב', 'קפ"ה')],
                         [6, 7, 10, 30, 50, 39, 17, 185])


class Bandplan(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.werk, cls.gl, cls.secs, cls.segs, cls.vols = plan()

    def test_pilot_ein_band(self):
        v = self.vols[0]
        self.assertEqual(v['reihe'], 'SY')
        self.assertEqual({s['reihe'] for s in v['segments']}, {'SY'})
        self.assertEqual(len([v for v in self.vols if v['reihe'] == 'SY']), 1)
        self.assertTrue(560 <= v['estimated_pages'] <= C.TARGET_PAGES)

    def test_grenzen_und_reihen(self):
        self.assertEqual(len(self.vols), 10)
        for v in self.vols:
            self.assertLessEqual(v['estimated_pages'], C.TARGET_PAGES)
            self.assertEqual(len({s['reihe'] for s in v['segments']}), 1)
        for r in ('OC', 'YD', 'EH'):
            seiten = [v['estimated_pages'] for v in self.vols if v['reihe'] == r]
            self.assertLess(max(seiten) - min(seiten), 40, r)           # gleichmaessig geteilt

    def test_bandgrenzen_zwischen_simanim(self):
        for v in self.vols:
            erster, letzter = v['segments'][0], v['segments'][-1]
            self.assertEqual(erster['n'], 1)
            nach = next((s for s in self.segs if s['id'] > letzter['id']), None)
            if nach:
                self.assertEqual(nach['n'], 1)

    def test_ids_global_fortlaufend(self):
        ids = [s['id'] for v in self.vols for s in v['segments']]
        self.assertEqual(ids, ['RPL-{:07d}'.format(i) for i in range(1, len(ids) + 1)])

    def test_planwert_und_empfindlichkeit(self):
        self.assertEqual(C.EN_EXPANSION, 2.375)
        self.assertEqual(B.body_pages(476469), 566)
        self.assertEqual(len(B.plan_volumes(self.segs, self.gl, body_target=528)), 12)


class Abnahme(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.werk, cls.gl, cls.secs, cls.segs, cls.vols = plan()
        cls.tmp = Path(tempfile.mkdtemp())
        cls.master = cls.tmp / 'Rav_Pealim_Band_01_BILINGUAL.txt'
        C.write_bic_text(cls.master, B.serialize_volume(cls.vols[0], cls.gl))

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp)

    def kopie(self, name, ersetze):
        raw = self.master.read_text(encoding='utf-8-sig')
        for a, b in ersetze:
            self.assertIn(a, raw)
            raw = raw.replace(a, b, 1)
        f = self.tmp / name
        C.write_bic_text(f, raw)
        return f

    def test_frischer_master(self):
        r = V.pruefe(self.master, None, False)
        self.assertEqual(r['fehler'], [])
        self.assertEqual((r['segmente'], r['abschnitte'], r['reihe']), (698, 64, 'SY'))
        self.assertIn('max_pages="800" reihe="SY"', self.master.read_text(encoding='utf-8-sig')[:200])

    def test_versionierter_master_gleich(self):
        f = C.HERE / 'out' / 'band' / 'Rav_Pealim_Band_01_BILINGUAL.txt'
        if f.exists():
            self.assertEqual(f.read_bytes(), self.master.read_bytes())

    def test_he_veraendert(self):
        f = self.kopie('a_EN_FERTIG.txt', [('נשאלתי ממ"א', 'נשאלתי ממ"ב')])
        r = V.pruefe(f, self.master, False)
        self.assertTrue(any('<he> veraendert' in x for x in r['fehler']))

    def test_titel_der_ausgabe_geschuetzt(self):
        f = self.kopie('b.txt', [('<en_title>Sod Yesharim, Siman 2 (Part I, Siman 2)</en_title>',
                                  '<en_title>Sod Yesharim, Siman Two</en_title>')])
        r = V.pruefe(f, self.master, False)
        self.assertTrue(any('<en_title> des Abschnitts veraendert' in x for x in r['fehler']))

    def test_fertig_verlangt_englisch_und_regeln(self):
        f = self.kopie('c_EN_FERTIG.txt', [('<en><![CDATA[]]></en>', '<en><![CDATA[[1] Yahweh said]]></en>')])
        r = V.pruefe(f, self.master)
        self.assertTrue(any('<en> leer' in x for x in r['fehler']))
        self.assertTrue(any('Yahweh' in x for x in r['fehler']))
        self.assertTrue(any('beginnt mit "["' in x for x in r['fehler']))


class Struktur(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.werk = plan()[0]
        cls.maf = ST.lies_mafteach(cls.werk)
        cls.zu, cls.hinweise = ST.ordne_mafteach(cls.werk, cls.maf)

    def test_mafteach_zuordnung(self):
        self.assertGreaterEqual(len(self.zu), 480)
        self.assertIn(('Volume IV', 'Yoreh Deah'), self.maf)                  # Liste ohne Kopf in Orach Chayim IV
        self.assertTrue(self.maf[('Volume IV', 'Yoreh Deah')]['ohne_kopf'])
        self.assertEqual(self.zu['Volume I, Sod Yesharim 1']['inhalt'][:24], 'בביאור הפסוק נעשה אדם בצ')
        self.assertEqual(self.zu['Volume IV, Choshen Mishpat 7']['nummer_druck'], 'שאלה זיי"ן')
        self.assertEqual(self.zu['Volume IV, Choshen Mishpat 7']['zuordnung'], 'nummer')
        self.assertIsNotNone(self.maf[('Volume III', 'Sod Yesharim')]['zusammenfassung'])

    def test_bericht_ohne_fehler(self):
        with tempfile.TemporaryDirectory() as d:
            r = ST.run(d, quiet=True)
        self.assertEqual(r['fehler'], [])
        self.assertEqual(r['simanim']['Sod Yesharim'], 64)


class Konkordanz(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.gl = C.lade_gliederung()
        with tempfile.TemporaryDirectory() as d:
            cls.k = K.run(d, quiet=True, plan=plan())

    def test_verweis_lesen(self):
        f = lambda t: K.lies_verweis(t, self.gl)  # noqa: E731
        v = f(' ח"א באורח חיים סי\' ד\' שנשאלתי במי שלא')
        self.assertEqual((v['teil'], v['abteilung'], v['siman']), (1, 'Orach Chayim', 4))
        v = f(' ח"א בסוד ישרים ס"י חקירה בענין השבת')
        self.assertEqual((v['teil'], v['abteilung'], v['siman']), (1, 'Sod Yesharim', 10))
        v = f(' ח"א בא"ח סי\' ה\' עי"ש')
        self.assertEqual((v['abteilung'], v['siman']), ('Orach Chayim', 5))
        v = f(' ת"א באה"ע סי\' י"ב דף פ"ה')
        self.assertEqual((v['teil'], v['abteilung'], v['siman']), (None, 'Even HaEzer', 12))
        v = f(' הנז\' הבאתי מן המבי"ט ח"ג סי\' נ"ד משמע')
        self.assertEqual((v['teil'], v['siman']), (None, None))
        v = f(' ח"ב בתשובה סי\' ך\' שהשבתי')
        self.assertEqual((v['teil'], v['abteilung'], v['siman']), (2, None, 20))

    def test_konkordanz_vollstaendig(self):
        z = self.k['zeilen']
        self.assertEqual(len(z), 526)
        sy = [x for x in z if x['reihe'] == 'SY']
        self.assertEqual([x['lauf'] for x in sy], list(range(1, 65)))
        self.assertEqual({x['band'] for x in sy}, {'01'})
        self.assertEqual(self.k['ziele'][('Volume III', 'Sod Yesharim', 1)]['lauf'], 32)

    def test_querverweise(self):
        q = {(x['stelle'], x['status']): x for x in self.k['querverweise']}
        x = q[('Volume III, Sod Yesharim 3:1', 'AUFGELOEST')]
        self.assertEqual((x['band'], x['ziel_titel_en']), ('01', 'Sod Yesharim, Siman 10 (Part I, Siman 10)'))
        x = q[('Volume III, Sod Yesharim 13:3', 'AUFGELOEST')]
        self.assertEqual(x['ziel_titel_en'], 'Orach Chayim, Part I, Siman 5')
        self.assertIn(('Volume IV, Even HaEzer 4:9', 'OHNE_TEIL'), q)
        self.assertNotIn('ZIEL_FEHLT', self.k['status'])
        self.assertGreaterEqual(self.k['status'].get('AUFGELOEST', 0), 13)


class Glossar(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        C.import_pipeline()
        import by_glossary
        import by_parse
        cls.bp = by_parse
        cls.g = by_glossary.Glossary(str(C.GLOSSARY))
        cls.q = G.lade_quellen()

    def test_quellen(self):
        self.assertGreaterEqual(len(self.q['halacha']), 79)
        self.assertGreaterEqual(len(self.q['kabbala']['begriffe']), 60)
        self.assertIn('אב"ג', self.q['shem'])
        for k, v in json.loads(G.HALACHA.read_text(encoding='utf-8'))['eintraege'].items():
            self.assertIn(v['status'], ('RP', 'KONTEXT'), k)
            if v['status'] == 'KONTEXT':
                self.assertTrue('|' in v['he'] + v['en'] or v.get('grund'), k)

    def test_kabbala_vor_by_nur_in_sod_yesharim(self):
        sy = G.aufloesen('ת"ת', '', 'והנה', 'SY', self.g, self.q)
        oc = G.aufloesen('ת"ת', '', 'והנה', 'OC', self.g, self.q)
        self.assertEqual((sy[0], sy[1]['en']), ('kabbala', 'Tiferet'))
        self.assertEqual(oc[0], 'curated')
        self.assertEqual(G.aufloesen('או"א', '', '', 'SY', self.g, self.q)[1]['en'], 'Abba ve-Imma')

    def test_halacha_mit_praefix_und_reihenfolge(self):
        src, r = G.aufloesen('דקי"ל', '', '', 'YD', self.g, self.q)
        self.assertEqual((src, r['en']), ('rp', 'we hold (it is established)'))
        self.assertEqual(G.aufloesen('ט"ז', '', '', 'OC', self.g, self.q)[0], 'kontext')
        self.assertEqual(G.aufloesen('ש"ע', '', '', 'OC', self.g, self.q)[0], 'curated')     # BY zuerst
        self.assertEqual(G.aufloesen('אב"ג', '', '', 'SY', self.g, self.q)[0], 'shem')
        self.assertEqual(G.aufloesen('קפ"ט', '', 'בשו"ע סי\' ', 'OC', self.g, self.q)[0], 'stellenzahl')

    def test_lauf_sod_yesharim(self):
        secs = [s for s in plan()[2] if s['reihe'] == 'SY']
        with tempfile.TemporaryDirectory() as d:
            r = G.run(out=d, quiet=True, secs=secs)
            self.assertTrue((Path(d) / 'glossar' / 'Rav_Pealim_Glossar_Kabbala.tsv').exists())
            neu = json.loads((Path(d) / 'glossar' / 'Rav_Pealim_Glossar_NEU.json').read_text(encoding='utf-8'))
        self.assertGreater(r['aufgeloest'] / float(r['treffer']), 0.8)
        self.assertGreater(r['kabbala_treffer_sy'], 4000)
        self.assertTrue(all(v['he'] == '' and v['en'] == '' for v in neu['neu'].values()))

    def test_werke(self):
        secs = [s for s in plan()[2] if s['reihe'] == 'SY']
        with tempfile.TemporaryDirectory() as d:
            r = W.run(d, quiet=True, secs=secs, reihen=['SY'])
        self.assertGreater(r['treffer'], 900)
        self.assertGreaterEqual(r['zitatketten']['SY'], 30)


class Uebersetzung(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.werk, cls.gl, cls.secs, cls.segs, cls.vols = plan()
        for v in cls.vols:
            for s in v['segments']:
                s['band'] = v['number']

    def test_speicherzeilen(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / 'sy').mkdir()
            (Path(d) / 'sy' / '001.txt').write_text(
                '## Probe\n@Volume I, Sod Yesharim 1:2 = <b>Question.</b> I was asked from another place.\n'
                '!Volume I, Sod Yesharim 1:2 = ממ"א unsicher\n@Volume III, Kuntres Beit Tefillah 2 = It is our duty.\n'
                '@Volume I, Introduction 2 = <b>Blessed</b> be HaShem.\n', encoding='utf-8')
            sp = U.lade_speicher(d)
            (Path(d) / 'sy' / '002.txt').write_text('Volume I, Sod Yesharim 1:3 ohne Kennzeichen\n', encoding='utf-8')
            with self.assertRaises(SystemExit):
                U.lade_speicher(d)
        self.assertEqual(len(sp['seg']), 3)
        self.assertEqual(sp['hinweise']['Volume I, Sod Yesharim 1:2'], ['ממ"א unsicher'])

    def test_fuellen_und_pruefen(self):
        v = self.vols[0]
        raw = B.serialize_volume(v, self.gl)
        sp = {'seg': {v['segments'][0]['ref']: 'The young author says: I have seen fit to conclude …',
                      v['segments'][1]['ref']: '<b>Question.</b> I was asked from another place …'}}
        text, z = U.fuelle_master(raw, v['segments'], sp)
        self.assertEqual((z['seg'], z['offen']), (2, len(v['segments']) - 2))
        with tempfile.TemporaryDirectory() as d:
            m, f = Path(d) / 'm.txt', Path(d) / 'Rav_Pealim_Band_01_BILINGUAL_EN_STAND.txt'
            C.write_bic_text(m, raw)
            C.write_bic_text(f, text)
            r = V.pruefe(f, m, False)
        self.assertEqual(r['fehler'], [])
        self.assertEqual(r['en_gefuellt'], 2)

    def test_batch_bereiche(self):
        v = self.vols[0]
        b = U.batch_bereiche(v['segments'])
        self.assertEqual([s['id'] for x in b for s in x], [s['id'] for s in v['segments']])
        for x in b:
            self.assertLessEqual(len(x), C.BATCH_MAX_SEGMENTS)
            self.assertTrue(len(x) == 1 or sum(s['plan_chars'] for s in x) <= C.BATCH_MAX_CHARS)

    def test_anweisung_vorhanden(self):
        self.assertTrue((C.HERE.parent / E.ANWEISUNG).exists())
        self.assertTrue((C.HERE.parent / 'PROMPT_Uebersetzung_Rav_Pealim.txt').exists())


class InDesignRP(unittest.TestCase):
    def test_generator_reproduzierbar(self):
        secs = plan()[2]
        rh, n = E.rh_ersetzungen(secs)
        with tempfile.TemporaryDirectory() as d:
            for src, dst, kopf, ers in ((E.BM_SRC, E.BM_DST, E.BM_KOPF, E.BM_ERSETZUNGEN),
                                        (E.RH_SRC, E.RH_DST, E.RH_KOPF, rh)):
                neu, _ = E.baue(src, Path(d) / dst.name, kopf, ers)
                self.assertEqual(neu.read_bytes(), dst.read_bytes(), dst.name)
            neu, _, k = E.toc_bauen(Path(d) / E.TOC_DST.name, secs=secs)
            self.assertEqual(neu.read_bytes(), E.TOC_DST.read_bytes())
        self.assertEqual((n, k), (21, 526))

    def test_buchmanager_werte(self):
        t = E.BM_DST.read_text(encoding='utf-8')
        for z in ('var MAX_PAGES = 800;', 'var TARGET_PAGES = 600;', 'var EN_EXPANSION = 2.375;',
                  '#targetengine "RavPealimBilingualBookManager_v100"', 'project=\\"Rav Pealim\\"', 'Rav_Pealim_Band_',
                  'RPL · Abschnitt · Hebräisch', E.ANWEISUNG):
            self.assertIn(z, t)
        for rest in ('BIH_', 'BIH ·', 'BIH-', '"BIH'):
            self.assertNotIn(rest, t)
        self.assertNotIn('BEN ISH CHAI ·', t)

    def test_keine_reservierten_woerter(self):
        probe = 'var a = {short:1}; x = a.long; y = /short/g; switch (q) { default: break; }\n'
        self.assertEqual(es3_verstoesse(probe), ['Zeile 1: short', 'Zeile 1: long'])
        dateien = sorted(INDESIGN.glob('Rav_Pealim_*.jsx')) + [INDESIGN / 'rh_abschnitte_bausteine.js',
                                                              INDESIGN / 'vorlage_Inhaltsverzeichnis.jsx']
        self.assertEqual(len(dateien), 5)
        for f in dateien:
            with self.subTest(datei=f.name):
                self.assertEqual(es3_verstoesse(f.read_text(encoding='utf-8')), [])

    @unittest.skipUnless(NODE, 'node fehlt')
    def test_kolumnentitel_simanim(self):
        namen = ['trim', 'xmlUnescape', 'restoreCdata', 'cleanHeadingText', 'stripHebrewMarks', 'normalizeHebrewWords',
                 'normalizeEnglishWords', 'containsHebrew', 'replaceAllLiteral', 'cleanTemplateSeparators',
                 'buildParashahCatalogue', 'buildSectionCatalogue', 'groupByKey', 'sectionKeyMatches', 'matchSection',
                 'parseSourceSections', 'buildSectionStarts', 'headerTitle', 'renderHeaderText', 'shortenWords',
                 'normalizeSectionEn',
                 'headerMatchesTitle']
        extra = 'var PARASHOT = buildParashahCatalogue();\nvar SECTIONS = buildSectionCatalogue();'
        body = """
var out = [];
for (var b = 0; b < INPUT.raws.length; b++) {
  var src = parseSourceSections(INPUT.raws[b]), he = [], en = [], i;
  for (i = 0; i < src.length; i++) {
    he.push({text: src[i].he, pageIndex: i, pageName: String(i + 1), textIndex: 0, atTop: true});
    en.push({text: src[i].en, pageIndex: i, pageName: String(i + 1), textIndex: 0, atTop: true});
  }
  var hs = buildSectionStarts(he, true), es = buildSectionStarts(en, false), r = {n: src.length, ok: 0, kurz: 0};
  for (i = 0; i < hs.length; i++) {
    if (hs[i].matched && es[i].matched && hs[i].otherTitle === es[i].title && es[i].otherTitle === hs[i].title) r.ok++;
    if (es[i].kurzTitel && hs[i].kurzTitel) r.kurz++;
  }
  out.push(r);
}
var s = SECTIONS[17];
var info = {enTitle: s.en, enShort: s.enShort, heTitle: s.he, heShort: s.heShort, enGroup: "Sod Yesharim · Part II",
            heGroup: "סוד ישרים · חלק ב׳"};
var cfg = {enTemplate: "RAV PE’ALIM · {ABSCHNITT}", heTemplate: "רב פעלים · {ABSCHNITT_HE}"};
process.stdout.write(JSON.stringify({baende: out, n: SECTIONS.length, gruppen: PARASHOT.length,
  en: renderHeaderText(info, cfg, "en", false).text, enKurz: renderHeaderText(info, cfg, "en", true).text,
  he: renderHeaderText(info, cfg, "he", false).text,
  m: headerMatchesTitle("RAV PE’ALIM · Sod Yesharim 18", info, "en")}));
"""
        raws = [B.band_datei(C.HERE / 'out', v['number']).read_text(encoding='utf-8-sig') for v in plan()[4]]
        res = run_js(E.RH_DST, namen, extra, body, {'raws': raws})
        self.assertEqual(sum(b['n'] for b in res['baende']), 526)
        for b in res['baende']:
            self.assertEqual((b['ok'], b['kurz']), (b['n'], b['n']))
        self.assertEqual((res['n'], res['gruppen']), (526, 21))
        self.assertEqual(res['en'], 'RAV PE’ALIM · Sod Yesharim, Siman 18 (Part II, Siman 1)')
        self.assertEqual(res['enKurz'], 'RAV PE’ALIM · Sod Yesharim 18')
        self.assertEqual(res['he'], 'רב פעלים · סוד ישרים סימן י״ח (ח״ב סי׳ א׳)')
        self.assertTrue(res['m'])

    @unittest.skipUnless(NODE, 'node fehlt')
    def test_inhaltsverzeichnis(self):
        src = E.TOC_DST.read_text(encoding='utf-8')
        gruppen = re.search(r'\n    var GRUPPEN = (\{.*\});\n', src).group(1)
        abschnitte = re.search(r'\n    var ABSCHNITTE = (\[[\s\S]*?\n    \]);\n', src).group(1)
        extra = 'var RIGHT_INDENT_TAB = "\\u0008";\nvar GRUPPEN = {};\nvar ABSCHNITTE = {};'.format(gruppen, abschnitte)
        body = """
var he = [{text: "סוד ישרים סימן א׳ (ח״א סי׳ א׳)", seite: "1"}, {text: "סוד ישרים סימן י״ח (ח״ב סי׳ א׳)", seite: "201"}];
var en = [{text: "Sod Yesharim, Siman 1 (Part I, Siman 1)", seite: "1"}, {text: "Sod Yesharim, Siman 18 (Part II, Siman 1)", seite: "201"}];
var z = zuordnen(he, en), eh = eintraege(he, "he"), ee = eintraege(en, "en");
var arten = []; for (var i = 0; i < eh.length; i++) arten.push(eh[i].art);
process.stdout.write(JSON.stringify({z: z, arten: arten, zeilen: zeilen(eh), en: zeilen(ee)}));
"""
        res = run_js(E.TOC_DST, ['trim', 'normalizeHebrewWords', 'katalogEintrag', 'zuordnen', 'eintraege', 'zeilen'],
                     extra, body, {})
        self.assertEqual(res['z'], {'fehlend': [], 'paarweise': True})
        self.assertEqual(res['arten'], ['gruppe', 'eintrag', 'angabe', 'gruppe', 'eintrag', 'angabe'])
        self.assertEqual(res['zeilen'][0], 'סוד ישרים · חלק א׳')
        self.assertTrue(res['zeilen'][2].startswith('בביאור הפסוק נעשה אדם'))
        self.assertEqual(res['en'][0], 'Sod Yesharim · Part I')
        self.assertEqual(res['en'][1], 'Sod Yesharim, Siman 1 (Part I, Siman 1)\u00081')


if __name__ == '__main__':
    unittest.main(verbosity=1)
