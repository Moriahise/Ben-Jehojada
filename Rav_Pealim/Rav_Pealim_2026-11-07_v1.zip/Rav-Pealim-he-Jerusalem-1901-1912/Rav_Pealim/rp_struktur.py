# -*- coding: utf-8 -*-
"""
Struktur der Quelle (Teil › Abteilung › Siman › Absatz), Mafteach-Abgleich, Abschnittsliste.

Prueft
  - Zaehlung der nicht leeren Simanim je Abteilung gegen gliederung.json "erwartet"
    (FEHLER bei Abweichung); leere Simanim der Quelle werden genannt
  - Mafteachot des Drucks (text[Teil]["Index"]) gegen die Simanim:
    jede Liste beginnt mit dem Namen der Abteilung ("אורח חיים<br>שאלה א'"); beginnt die
    Zaehlung ohne Kopf neu bei א', gehoert der Rest zur naechsten Abteilung des Teils
    (Teil IV: Yoreh Deah steht in der Liste von Orach Chayim). Eintraege ohne Nummer
    ("עוד שאלה", "א"ה") ergaenzen den vorigen. Zuordnung nach der gedruckten Nummer,
    wenn sie in die Folge passt, sonst nach der Folge (Druckfehler wie "שאלה ה'" nach ז').
    Abweichungen sind HINWEISE, keine Fehler.
  - Absaetze ueber dem Batch-Kontingent (30.000 Zeichen ohne Nikud)

Ausgaben (out/struktur/)
    Rav_Pealim_Struktur_Bericht.txt
    Rav_Pealim_Abschnittsliste.tsv      Abschnitte der Ausgabe in Bandfolge mit Titeln HE/EN
    Rav_Pealim_Mafteach.tsv             Inhaltsangabe des Drucks je Siman
"""
import argparse
import collections
import re
import sys
from pathlib import Path

import rp_common as C

KOPF_ABTEILUNG = [('אורח חיים', 'Orach Chayim'), ('יורה דעה', 'Yoreh Deah'), ('אבן העזר', 'Even HaEzer'),
                  ('חושן משפט', 'Choshen Mishpat'), ('חשן משפט', 'Choshen Mishpat'), ('סוד ישרים', 'Sod Yesharim')]
EINTRAG_RE = re.compile(r'^\s*<b>\s*(?:([^<]*?)<br>)?\s*([^<]*?)\s*</b>\s*([\s\S]*)$')
NUMMER_RE = re.compile(r'^(?:שאלה|סי[\'׳"]|סימן)\s*([א-ת"״\'׳]+)[\s,.]*$')


def _abteilung_aus_kopf(kopf):
    for he, en in KOPF_ABTEILUNG:
        if he in (kopf or ''):
            return en
    return None


def lies_mafteach(werk):
    """-> {(teil, abteilung): {'eintraege': [...], 'zusammenfassung': text|None}}

    eintraege: [{'nummer_druck', 'nummer' (int|None), 'inhalt'}] in Druckfolge."""
    out = collections.OrderedDict()
    for t in werk['teile']:
        reihenfolge = [a for a in t['abteilungen']]
        for liste in t['index']:
            block = None
            for e in liste:
                m = EINTRAG_RE.match(e)
                kopf, marke, rest = (m.group(1), m.group(2), m.group(3)) if m else (None, '', e)
                inhalt = C.klartext(rest)
                abt = _abteilung_aus_kopf(kopf)
                nm = NUMMER_RE.match(C.klartext(marke))
                nummer = C.zahlwert(nm.group(1)) if nm else None
                neu_ohne_kopf = (abt is None and block is not None and nummer == 1 and block['eintraege']
                                 and (block['eintraege'][-1]['nummer'] or 0) > 1)
                if abt or block is None or neu_ohne_kopf:
                    if not abt:
                        frei = [a for a in reihenfolge if (t['key'], a) not in out]
                        abt = frei[0] if frei else 'unbekannt'
                    block = out.setdefault((t['key'], abt), {'eintraege': [], 'zusammenfassung': None,
                                                             'ohne_kopf': bool(neu_ohne_kopf)})
                if nummer is None and block['eintraege']:
                    block['eintraege'][-1]['inhalt'] += ' ' + C.klartext(marke + ' ' + rest)
                    block['eintraege'][-1]['zusatz'] = True
                    continue
                if nummer is None:
                    block['zusammenfassung'] = C.klartext(marke + ' ' + rest)
                    continue
                block['eintraege'].append({'nummer_druck': C.klartext(marke), 'nummer': nummer, 'inhalt': inhalt,
                                           'zusatz': False})
    return out


def ordne_mafteach(werk, maf):
    """Inhaltsangabe je Siman. -> ({siman_ref: zeile}, hinweise)"""
    zuordnung, hinweise = {}, []
    for t in werk['teile']:
        for abt, sims in t['abteilungen'].items():
            block = maf.get((t['key'], abt))
            n_sim = len(sims)
            if not block:
                hinweise.append('{} {}: keine Mafteach-Liste'.format(t['key'], abt))
                continue
            if not block['eintraege']:
                hinweise.append('{} {}: Mafteach nur Sammelangabe ("{}")'.format(t['key'], abt, block['zusammenfassung']))
                continue
            if block.get('ohne_kopf'):
                hinweise.append('{} {}: Mafteach-Liste ohne eigene Ueberschrift (Zaehlung beginnt neu in der '
                                'vorigen Liste)'.format(t['key'], abt))
            vorher, belegt = 0, set()
            for e in block['eintraege']:
                n = e['nummer']
                art = 'nummer'
                # gedruckte Nummer gilt, wenn sie die Folge fortsetzt (Luecken bis 4 fuer fehlende Eintraege
                # oder leere Simanim); sonst Druckfehler -> naechste Nummer der Folge
                if n is None or n in belegt or not 1 <= n <= n_sim or not vorher < n <= vorher + 5:
                    n, art = vorher + 1, 'folge'
                    hinweise.append('{} {}: Eintrag "{}" nach der Folge als Siman {} gezaehlt'.format(
                        t['key'], abt, e['nummer_druck'], n))
                vorher = n
                belegt.add(n)
                if n > n_sim:
                    hinweise.append('{} {}: Eintrag "{}" ohne Siman (nur {} Simanim)'.format(
                        t['key'], abt, e['nummer_druck'], n_sim))
                    continue
                ref = '{}, {} {}'.format(t['key'], abt, n)
                zuordnung[ref] = {'teil': t['key'], 'abteilung': abt, 'siman': n, 'nummer_druck': e['nummer_druck'],
                                  'inhalt': e['inhalt'], 'zuordnung': art, 'zusatz': e['zusatz']}
            fehlend = [i for i in range(1, n_sim + 1) if i not in belegt and not sims[i - 1]['leer']]
            if fehlend:
                hinweise.append('{} {}: {} Simanim ohne Mafteach-Eintrag ({})'.format(
                    t['key'], abt, len(fehlend), ', '.join(str(i) for i in fehlend[:12])))
            if len(block['eintraege']) != n_sim:
                hinweise.append('{} {}: {} Mafteach-Eintraege fuer {} Simanim'.format(
                    t['key'], abt, len(block['eintraege']), n_sim))
    return zuordnung, hinweise


def run(out='out', quiet=False):
    werk = C.load_werk()
    gl = C.lade_gliederung()
    secs = C.build_edition(werk, gl)
    maf = lies_mafteach(werk)
    zuordnung, hinweise = ordne_mafteach(werk, maf)
    o = Path(out) / 'struktur'
    fehler = []

    zaehlung, leer = collections.Counter(), []
    tabelle = []
    for t in werk['teile']:
        for abt, sims in t['abteilungen'].items():
            nicht_leer = [s for s in sims if not s['leer']]
            leer += [s['ref'] for s in sims if s['leer']]
            zaehlung[abt] += len(nicht_leer)
            absaetze = [p for s in nicht_leer for p in s['absaetze'] if C.klartext(p['html'])]
            tabelle.append((t['key'], abt, len(sims), len(sims) - len(nicht_leer), len(absaetze),
                            sum(C.plan_length(C.normalisiere_html(p['html'])) for p in absaetze)))
        for name, ps in list(t['vorspann'].items()) + list(t['kuntres'].items()):
            absaetze = [p for p in ps if C.klartext(p['html'])]
            tabelle.append((t['key'], name, '-', '-', len(absaetze),
                            sum(C.plan_length(C.normalisiere_html(p['html'])) for p in absaetze)))
    for abt, soll in gl.get('erwartet', {}).items():
        if abt.startswith('_'):
            continue
        if zaehlung.get(abt) != soll:
            fehler.append('{}: {} nicht leere Simanim statt {} (gliederung.json erwartet)'.format(abt, zaehlung.get(abt), soll))

    gesetzt = {p['ref'] for s in secs for p in s['segmente']}
    alle = {p['ref'] for _, _, _, p in C.iter_absaetze(werk)}
    fehlt = sorted(alle - gesetzt)
    if fehlt:
        fehler.append('{} Absaetze der Quelle nicht in der Ausgabe, z. B. {}'.format(len(fehlt), fehlt[:5]))
    gross = [(p['ref'], p['plan_chars']) for s in secs for p in s['segmente'] if p['plan_chars'] > C.BATCH_MAX_CHARS]
    index_eintraege = sum(len(l) for t in werk['teile'] for l in t['index'])

    rows = []
    for s in secs:
        z = zuordnung.get(s['quelle_ref'], {})
        rows.append([s['nr'], s['reihe'], s['gruppe'], s['quelle_ref'], s['lauf'] or '', s['he_title'], s['en_title'],
                     s['he_kurz'], s['en_kurz'], len(s['segmente']), sum(p['plan_chars'] for p in s['segmente']),
                     z.get('inhalt', '')])
    C.write_tsv(o / (C.WERK_TAG + '_Abschnittsliste.tsv'),
                ['nr', 'reihe', 'gruppe', 'quelle_ref', 'lauf', 'he_title', 'en_title', 'he_kurz', 'en_kurz',
                 'segmente', 'he_konsonanten', 'mafteach'], rows)
    mrows = []
    for t in werk['teile']:
        for abt, sims in t['abteilungen'].items():
            for s in sims:
                z = zuordnung.get(s['ref'])
                mrows.append([t['key'], abt, s['nr'], s['ref'], 'leer' if s['leer'] else '',
                              z['nummer_druck'] if z else '', z['zuordnung'] if z else 'fehlt',
                              z['inhalt'] if z else ''])
    C.write_tsv(o / (C.WERK_TAG + '_Mafteach.tsv'),
                ['teil', 'abteilung', 'siman', 'ref', 'quelle', 'nummer_druck', 'zuordnung', 'inhalt'], mrows)

    L = ['RAV PE’ALIM · STRUKTUR (TEIL › ABTEILUNG › SIMAN › ABSATZ)', '',
         'Quelle: {} · {} · {}'.format(werk['meta']['title'], werk['meta']['versionTitle'], werk['meta']['license']),
         '        sha256 {}'.format(werk['meta']['sha256']), '',
         '{:<11} {:<22} {:>8} {:>5} {:>8} {:>10}'.format('Teil', 'Bereich', 'Simanim', 'leer', 'Absaetze', 'HE-Zeichen')]
    for r in tabelle:
        L.append('{:<11} {:<22} {:>8} {:>5} {:>8} {:>10}'.format(*r))
    L += ['', 'Simanim (nicht leer) je Abteilung: ' + ' · '.join('{} {}'.format(k, v) for k, v in zaehlung.items()),
          'Leere Simanim der Quelle (nicht gesetzt): ' + (', '.join(leer) or 'keine'),
          'HE-Zeichen gesamt (ohne Nikud): {}'.format(sum(r[5] for r in tabelle)),
          'Ausgabe: {} Abschnitte · {} Segmente (Absaetze) · Reihen {}'.format(
              len(secs), sum(len(s['segmente']) for s in secs),
              ', '.join('{} {}'.format(k, v) for k, v in collections.Counter(s['reihe'] for s in secs).items())),
          'Nicht gesetzt: Mafteachot ({} Eintraege, Inhaltsangaben in {}_Mafteach.tsv / Konkordanz)'.format(
              index_eintraege, C.WERK_TAG),
          'Absaetze ueber {} Zeichen: {}'.format(C.BATCH_MAX_CHARS, ', '.join('{} ({})'.format(*g) for g in gross) or 'keine'),
          '', 'MAFTEACH-ABGLEICH: {} Simanim mit Inhaltsangabe, {} Hinweise'.format(len(zuordnung), len(hinweise))]
    L += ['  ' + h for h in hinweise]
    L += ['', 'FEHLER: {}'.format(len(fehler))] + ['  ' + f for f in fehler]
    txt = '\n'.join(L) + '\n'
    o.mkdir(parents=True, exist_ok=True)
    (o / (C.WERK_TAG + '_Struktur_Bericht.txt')).write_text(txt, encoding='utf-8')
    if not quiet:
        print(txt)
    return {'abschnitte': len(secs), 'segmente': sum(len(s['segmente']) for s in secs), 'simanim': dict(zaehlung),
            'leer': leer, 'mafteach': zuordnung, 'mafteach_hinweise': hinweise, 'fehler': fehler,
            'index_eintraege': index_eintraege, 'bericht': txt}


def main(argv=None):
    ap = argparse.ArgumentParser(description='Rav Pe’alim – Struktur und Mafteach-Abgleich')
    ap.add_argument('--out', default=str(C.HERE / 'out'))
    a = ap.parse_args(argv)
    r = run(a.out)
    return 1 if r['fehler'] else 0


if __name__ == '__main__':
    sys.exit(main())
