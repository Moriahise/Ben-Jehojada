# -*- coding: utf-8 -*-
import os, re, tempfile, unittest

import by_glossary
import by_indesign
import by_validate


class PipelineRegressionTests(unittest.TestCase):
    def setUp(self):
        self.g = by_glossary.Glossary()

    def test_lexical_abbreviations_are_not_gematria(self):
        self.assertIn('נְבִיאִים', self.g.resolve('תנ"ך', context='מפרשי התנ"ך')['he'])
        self.assertIn('מֵאִיר', self.g.resolve('ר"מ', context='אמר ר"מ')['he'])
        self.assertIn('פָּפָא', self.g.resolve('ר"פ', context='ר"פ אמר')['he'])

    def test_inline_numeric_beats_lexical_default(self):
        r = self.g.resolve('ת"ל', context='שעולה מספרם ת"ל', inline_expansion='430')
        self.assertEqual(r['he'], 'מִסְפָּר 430')

    def test_strong_gematria_context_beats_talmud_lomar(self):
        r = self.g.resolve('ת"ל', context='חמשה שמות אלהים שעולה מספרם ת"ל והם רמוזים')
        self.assertEqual(r['he'], 'מִסְפָּר 430')

    def test_yod_and_ab_context(self):
        self.assertIn('הָאוֹת', self.g.resolve('יו"ד', context='קוצו של יו"ד והיו"ד עצמה')['he'])
        self.assertIn('ע"ב', self.g.resolve('ע"ב', context='שם הוי"ה במילוי יודי"ן ע"ב')['he'])
        self.assertIn('עַמּוּד', self.g.resolve('ע"ב', context='סנהדרין דף ע"ב')['he'])

    def test_unmapped_entry_keeps_lemma(self):
        doc = {'entries': [{
            'seq': 1, 'daf': '30b', 'lemma_he': 'לֶמָּה',
            'commentary_html': 'פירוש', 'abbreviations': [], 'scripture_refs': [],
            'talmud': None, 'sefaria_ref': None,
        }]}
        seg = by_indesign.build_segments(doc, 'Berakhot', band_en_mode='empty')[0]
        self.assertIn('<lemma>לֶמָּה</lemma>', seg['he'])
        self.assertEqual(seg['band_he'], 'לֶמָּה')

    def test_longest_token_footnote_does_not_nest(self):
        text = 'בס"ד דבר ראשון; אחר כך ס"ד.'
        entry = {'abbreviations': [
            {'abbr': 'בס"ד', 'expansion': 'בְּסִיַּעְתָּא דִּשְׁמַיָּא'},
            {'abbr': 'ס"ד', 'expansion': 'סָלְקָא דַּעְתָּךְ'},
        ], 'scripture_refs': []}
        out, n = by_indesign.insert_footnotes(text, entry)
        self.assertEqual(n, 2)
        self.assertRegex(out, r'בס"ד<fn>בס"ד = .*?</fn>')
        self.assertRegex(out, r' ס"ד<fn>ס"ד = .*?</fn>')

    # --- Korrektur 2026-10-05 (Yoma) -------------------------------------
    def test_loose_small_bracket_keeps_commentary(self):
        import by_parse
        src = 'שם <small>[27] </small>כמנין הוי"ה ועוד <small>[342]</small> סוף'
        out = by_indesign.clean_body(src)
        self.assertIn('כמנין הוי"ה ועוד', out)
        self.assertNotIn('27', out)
        self.assertNotIn('342', out)
        self.assertEqual(by_parse.drop_small_brackets('צדיקים <small>[101].</small><br>'), 'צדיקים.<br>')

    def test_inline_expansion_does_not_span_brackets(self):
        import by_parse
        a = by_parse.find_abbrs('כ"ז <small>[27] </small>כמנין שם <small>[342]</small>')
        self.assertEqual(a[0]['inline_expansion'], '27')
        a = by_parse.find_abbrs('מוהרי"ש <small>[יוסף שאול נתנזון] </small>ז"ל')
        self.assertEqual(a[0]['inline_expansion'], 'יוסף שאול נתנזון')

    def test_multi_chunk_lemma_and_stray_close(self):
        import by_parse
        lem, body = by_parse.split_lemma(
            '<b>שָׁאֲלוּ אֶת רַבִּי אֶלְעָזָר</b>:<b> רִאשׁוֹנִים גְּדוֹלִים</b>, '
            '<b>אוֹ אַחֲרוֹנִים?.</b> יש להקשות')
        self.assertEqual(by_parse.strip_tags(lem), 'שָׁאֲלוּ אֶת רַבִּי אֶלְעָזָר: רִאשׁוֹנִים גְּדוֹלִים, אוֹ אַחֲרוֹנִים?.')
        self.assertTrue(body.startswith('יש להקשות'))
        lem, body = by_parse.split_lemma("<b>בָּנָה עֲנָת</b> וְכוּ'.</b> קשה")
        self.assertEqual(by_parse.strip_tags(lem), "בָּנָה עֲנָת וְכוּ'.")
        self.assertNotIn('</b>', body)

    def test_unvocalized_bold_commentary_is_not_lemma(self):
        import by_parse
        lem, body = by_parse.split_lemma("<b>בָּרוּךְ ה' וְגוֹ'.</b> <b>הקשא המהרש\"א</b> ז\"ל")
        self.assertEqual(by_parse.strip_tags(lem), "בָּרוּךְ ה' וְגוֹ'.")
        self.assertTrue(body.startswith('<b>הקשא'))

    def test_scripture_small_tags_removed_from_lemma(self):
        import by_parse
        lem, _ = by_parse.split_lemma('<b>שֶׁנֶּאֱמַר: <small>(דברי הימים א\' כט, יט)</small> "הַבִּירָה".</b> נראה')
        self.assertNotIn('small', by_parse.strip_tags(lem))
        self.assertIn('(דברי הימים א\' כט, יט)', by_parse.strip_tags(lem))

    def test_bracket_inside_bold_lemma_stays_in_lemma(self):
        # Bava Batra 10b: Senlake-Erklaerung mitten im fetten Talmudzitat
        import by_parse
        lem, body = by_parse.split_lemma(
            '<b>אָמַר לָהֶם: <small>[צְאוּ]</small> בֹּאוּ וּרְאוּ <small>(תהלים קיב, ט)</small>.</b> כך הגרסא')
        self.assertEqual(by_parse.strip_tags(lem), 'אָמַר לָהֶם: בֹּאוּ וּרְאוּ (תהלים קיב, ט).')
        self.assertNotIn('</b>', body)

    def test_opening_bracket_before_commentary_is_not_lemma(self):
        # Beitzah 2b, Rosh Hashanah 31b
        import by_parse
        lem, body = by_parse.split_lemma("<b>וְהָא תַּנְיָא וכו'.</b> [ואי תימא הויא]")
        self.assertEqual(by_parse.strip_tags(lem), "וְהָא תַּנְיָא וכו'.")
        self.assertTrue(body.startswith(' [ואי'))
        lem, _ = by_parse.split_lemma("<b>קוּמִי שְׁבִי יְרוּשָׁלָיִם\".</b> 'קוּמִי שְׁבִי' כלומר")
        self.assertEqual(by_parse.strip_tags(lem), 'קוּמִי שְׁבִי יְרוּשָׁלָיִם".')

    def test_source_fix_lemma_end(self):
        import json, by_parse
        d = tempfile.mkdtemp()
        sen, fx = os.path.join(d, 's.txt'), os.path.join(d, 'k.json')
        with open(sen, 'w', encoding='utf-8') as fh:
            fh.write('Titel\n\nDaf 54a\n\n<b>פְּתַח פּוּמָךְ קָרִי.</b> <b>קָרִי</b> המקרא\n')
        with open(fx, 'w', encoding='utf-8') as fh:
            json.dump([{'daf': '54a', 'n': 1, 'lemma_ende': 'קָרִי.</b>', 'grund': 't'}], fh, ensure_ascii=False)
        e = by_parse.parse(sen, 'Test')['entries'][0]
        self.assertEqual(e['lemma_he'], 'פְּתַח פּוּמָךְ קָרִי. קָרִי')
        e = by_parse.parse(sen, 'Test', fixes=by_parse.load_source_fixes(fx))['entries'][0]
        self.assertEqual(e['lemma_he'], 'פְּתַח פּוּמָךְ קָרִי.')
        self.assertEqual(e['commentary_html'], '<b>קָרִי</b> המקרא')

    def test_escaped_markup_is_removed(self):
        # Bava Kamma 3b, Chullin 139b: maskierte Tag-Reste der Quelle
        import by_parse
        self.assertEqual(by_parse.drop_escaped_markup('של&lt;<small>b</small>&gt; אַתָּה חוֹנֵןb&gt; גם'),
                         'של אַתָּה חוֹנֵן גם')
        self.assertEqual(by_parse.drop_escaped_markup('[י&lt;<small>b</small>&gt;וb&gt;"&lt;<small>b</small>&gt;דb&gt;]'),
                         '[יו"ד]')

    def test_source_fix_may_move_tags_only(self):
        import json, by_parse
        d = tempfile.mkdtemp()
        sen, fx = os.path.join(d, 's.txt'), os.path.join(d, 'k.json')
        with open(sen, 'w', encoding='utf-8') as fh:
            fh.write('Titel\n\nDaf 2a\n\n<b>אָמַר רַבִּי, שַׁפִּיר. נראה לי הטעם.</b>\n')
        ok = [{'daf': '2a', 'n': 1, 'alt': 'שַׁפִּיר. נראה', 'neu': 'שַׁפִּיר.</b> נראה', 'grund': 't'},
              {'daf': '2a', 'n': 1, 'alt': 'הטעם.</b>', 'neu': 'הטעם.', 'grund': 't'}]
        with open(fx, 'w', encoding='utf-8') as fh:
            json.dump({'korrekturen': ok}, fh, ensure_ascii=False)
        e = by_parse.parse(sen, 'Test', fixes=by_parse.load_source_fixes(fx))['entries'][0]
        self.assertEqual(e['lemma_he'], 'אָמַר רַבִּי, שַׁפִּיר.')
        self.assertEqual(e['commentary_html'], 'נראה לי הטעם.')
        with open(fx, 'w', encoding='utf-8') as fh:
            json.dump({'korrekturen': [dict(ok[0], neu='שַׁפִּיר.</b> נראה בעיני')]}, fh, ensure_ascii=False)
        with self.assertRaises(SystemExit):
            by_parse.load_source_fixes(fx)

    def test_spaced_small_bracket_is_senlake_explanation(self):
        # v3.2.1: '<small> [' (Rosh Hashanah 16b, Yoma, Sanhedrin ...)
        import by_parse
        self.assertEqual(by_parse.drop_small_brackets('הרב אה"י<small> [אהל יעקב]</small> ז"ל'), 'הרב אה"י  ז"ל')
        self.assertEqual(by_parse.drop_small_brackets('חָכָם<small> [68]</small>שהוא'), 'חָכָם שהוא')
        a = by_parse.find_abbrs('הרב אה"י<small> [אהל יעקב]</small> ז"ל')
        self.assertEqual(a[0]['inline_expansion'], 'אהל יעקב')
        self.assertEqual(by_indesign.clean_body('פרד"ס<small> [פשט, רמז, דרש, סוד] </small>נמצא'), 'פרד"ס נמצא')

    def test_gegenpruefung_applies_source_fixes(self):
        import contextlib, io, json, by_parse, by_gegenpruefung
        d = tempfile.mkdtemp()
        sen, tal, fx = (os.path.join(d, n) for n in ('s.txt', 't.txt', 'k.json'))
        with open(sen, 'w', encoding='utf-8') as fh:
            fh.write('Titel\n\nDaf 2a\n\n<b>אָמַר רַבִּי</b> מספר <small>[74×3=22</small> <small>שהם]</small> סוף\n')
        with open(tal, 'w', encoding='utf-8') as fh:
            fh.write(' *** דף ב. *** \n\nאָמַר רַבִּי יוֹחָנָן\n')
        ok = [{'daf': '2a', 'n': 1, 'alt': '<small>[74×3=22</small> <small>שהם]</small>',
               'neu': '<small>[74×3=22 שהם]</small>', 'grund': 't'}]
        with open(fx, 'w', encoding='utf-8') as fh:
            json.dump({'korrekturen': ok}, fh, ensure_ascii=False)
        segs = by_indesign.build_segments(by_parse.parse(sen, 'Test', fixes=by_parse.load_source_fixes(fx)),
                                          'Test', band_en_mode='empty')
        band = os.path.join(d, 'Band_01.txt')
        by_indesign.write_volume(band, 1, segs, 'Test')
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(by_gegenpruefung.main(band, sen, tal), 1)          # Rohdatei: B
            self.assertEqual(by_gegenpruefung.main(band, sen, tal, quellkorrektur=fx), 0)
        with open(fx, 'w', encoding='utf-8') as fh:
            json.dump({'korrekturen': [dict(ok[0], neu='<small>[74×3=222 שהם]</small>')]}, fh, ensure_ascii=False)
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(by_gegenpruefung.main(band, sen, tal, os.path.join(d, 'g.json'), quellkorrektur=fx), 1)
        with open(os.path.join(d, 'g.json'), encoding='utf-8') as fh:
            self.assertTrue(any('aendert Text' in x for x in json.load(fh)['befunde']['A']))

    def test_honorific_is_not_explained_by_following_quote(self):
        r = self.g.resolve('ז"ל', inline_expansion='אלא כל אחד ואחד מתפלל על עצמו')
        self.assertEqual(r['source'], 'curated')
        self.assertIn('לִבְרָכָה', r['he'])

    def test_broken_tag_does_not_swallow_text(self):
        # Pesachim (Senlake): '<b>מַר<, וזה סוד <small>(...)' — kaputtes '<' statt '</b>'
        out = by_indesign.clean_body('הוא מספר <b>מַר<, וזה סוד <small>(בראשית כז, לה)</small> בָּא')
        self.assertIn('וזה סוד', out)
        self.assertIn('(בראשית כז, לה)', out)

    def test_gegenpruefung_second_volume_uses_segment_number(self):
        # Band 02 beginnt mitten in der Senlake-Datei: BYH-000n gehoert zum n-ten Absatz.
        import contextlib, io, json, by_parse, by_gegenpruefung
        d = tempfile.mkdtemp()
        sen, tal = os.path.join(d, 's.txt'), os.path.join(d, 't.txt')
        with open(sen, 'w', encoding='utf-8') as fh:
            fh.write(
                'Titel\n\nDaf 2a\n\n<b>אָמַר רַבִּי</b> פירוש ראשון\n\n<b>תָּנוּ רַבָּנָן</b> פירוש שני'
                '\n\nDaf 2b\n\n<b>מַאי טַעְמָא</b> פירוש שלישי\n')
        with open(tal, 'w', encoding='utf-8') as fh:
            fh.write(
                ' *** דף ב. *** \n\nאָמַר רַבִּי יוֹחָנָן\nתָּנוּ רַבָּנָן הָכִי\n *** דף ב: *** \n\nמַאי טַעְמָא\n')
        segs = by_indesign.build_segments(by_parse.parse(sen, 'Test'), 'Test', band_en_mode='empty')
        band = os.path.join(d, 'Band_02.txt')
        by_indesign.write_volume(band, 2, segs[1:], 'Test')
        with contextlib.redirect_stdout(io.StringIO()):
            rc = by_gegenpruefung.main(band, sen, tal, os.path.join(d, 'g.json'))
        with open(os.path.join(d, 'g.json'), encoding='utf-8') as fh:
            g = json.load(fh)
        self.assertEqual(rc, 0, g['befunde'])
        self.assertEqual(g['stats']['he_wortgleich'], 2)

    def test_glossary_path_option(self):
        import json
        d = tempfile.mkdtemp()
        p = os.path.join(d, 'g.json')
        with open(p, 'w', encoding='utf-8') as fh:
            json.dump({'abbreviations': {'ק"ק': {'he': 'x', 'en': 'y'}}, 'letter_names': {}},
                      fh, ensure_ascii=False)
        g = by_glossary.Glossary(p)
        self.assertEqual(g.resolve('ק"ק')['en'], 'y')

    def test_validator_accepts_bare_fields_and_blocks_missing_lemma(self):
        raw = '''<book>\n<section>\n<he_title>דף א</he_title>\n<en_title>Daf 1a</en_title>\n</section>\n<segment id="BYH-0000001" n="1" daf="1a">\n<band_he>טקסט</band_he>\n<band_en></band_en>\n<he>פירוש</he>\n<en></en>\n</segment>\n</book>\n'''
        with tempfile.NamedTemporaryFile('w', suffix='.txt', encoding='utf-8', delete=False) as f:
            f.write(raw); path=f.name
        try:
            findings, stats, n = by_validate.validate(path, expect=1)
            self.assertEqual(n, 1)
            self.assertTrue(any(x['code'] == 'band_ohne_lemma' and x['level'] == 'FEHLER' for x in findings))
        finally:
            os.unlink(path)


if __name__ == '__main__':
    unittest.main()
