# -*- coding: utf-8 -*-
import os, re, tempfile, unittest

import by_glossary
import by_indesign
import by_validate


class PipelineRegressionTests(unittest.TestCase):
    def setUp(self):
        self.g = by_glossary.Glossary()

    def test_lexical_abbreviations_are_not_gematria(self):
        self.assertIn('נְבִיאִים', self.g.resolve('תנ"ך', context='מפרשי התנ"ך')['he'])
        self.assertIn('מֵאִיר', self.g.resolve('ר"מ', context='אמר ר"מ')['he'])
        self.assertIn('פָּפָא', self.g.resolve('ר"פ', context='ר"פ אמר')['he'])

    def test_inline_numeric_beats_lexical_default(self):
        r = self.g.resolve('ת"ל', context='שעולה מספרם ת"ל', inline_expansion='430')
        self.assertEqual(r['he'], 'מִסְפָּר 430')

    def test_strong_gematria_context_beats_talmud_lomar(self):
        r = self.g.resolve('ת"ל', context='חמשה שמות אלהים שעולה מספרם ת"ל והם רמוזים')
        self.assertEqual(r['he'], 'מִסְפָּר 430')

    def test_yod_and_ab_context(self):
        self.assertIn('הָאוֹת', self.g.resolve('יו"ד', context='קוצו של יו"ד והיו"ד עצמה')['he'])
        self.assertIn('ע"ב', self.g.resolve('ע"ב', context='שם הוי"ה במילוי יודי"ן ע"ב')['he'])
        self.assertIn('עַמּוּד', self.g.resolve('ע"ב', context='סנהדרין דף ע"ב')['he'])

    def test_unmapped_entry_keeps_lemma(self):
        doc = {'entries': [{
            'seq': 1, 'daf': '30b', 'lemma_he': 'לֶמָּה',
            'commentary_html': 'פירוש', 'abbreviations': [], 'scripture_refs': [],
            'talmud': None, 'sefaria_ref': None,
        }]}
        seg = by_indesign.build_segments(doc, 'Berakhot', band_en_mode='empty')[0]
        self.assertIn('<lemma>לֶמָּה</lemma>', seg['he'])
        self.assertEqual(seg['band_he'], 'לֶמָּה')

    def test_longest_token_footnote_does_not_nest(self):
        text = 'בס"ד דבר ראשון; אחר כך ס"ד.'
        entry = {'abbreviations': [
            {'abbr': 'בס"ד', 'expansion': 'בְּסִיַּעְתָּא דִּשְׁמַיָּא'},
            {'abbr': 'ס"ד', 'expansion': 'סָלְקָא דַּעְתָּךְ'},
        ], 'scripture_refs': []}
        out, n = by_indesign.insert_footnotes(text, entry)
        self.assertEqual(n, 2)
        self.assertRegex(out, r'בס"ד<fn>בס"ד = .*?</fn>')
        self.assertRegex(out, r' ס"ד<fn>ס"ד = .*?</fn>')

    def test_validator_accepts_bare_fields_and_blocks_missing_lemma(self):
        raw = '''<book>\n<section>\n<he_title>דף א</he_title>\n<en_title>Daf 1a</en_title>\n</section>\n<segment id="BYH-0000001" n="1" daf="1a">\n<band_he>טקסט</band_he>\n<band_en></band_en>\n<he>פירוש</he>\n<en></en>\n</segment>\n</book>\n'''
        with tempfile.NamedTemporaryFile('w', suffix='.txt', encoding='utf-8', delete=False) as f:
            f.write(raw); path=f.name
        try:
            findings, stats, n = by_validate.validate(path, expect=1)
            self.assertEqual(n, 1)
            self.assertTrue(any(x['code'] == 'band_ohne_lemma' and x['level'] == 'FEHLER' for x in findings))
        finally:
            os.unlink(path)


if __name__ == '__main__':
    unittest.main()
