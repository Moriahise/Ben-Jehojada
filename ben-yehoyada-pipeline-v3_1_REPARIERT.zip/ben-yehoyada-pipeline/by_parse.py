# -*- coding: utf-8 -*-
"""
Schritt 1 — Parsen.

Zerlegt eine Senlake-/Sefaria-Textdatei des Ben Jehojada in strukturierte
Eintraege. Funktioniert fuer jeden Traktat, solange die Datei dem Muster folgt:

    Daf 4b                     <- Blattmarke, eigene Zeile
    <b>LEMMA</b> Kommentar...  <- ein Absatz = ein Eintrag
    ...<br><b>ודע</b>...       <- Unterabschnitt innerhalb eines Eintrags
    ABK <small>[Aufloesung]</small>   <- von der Ausgabe mitgelieferte Erklaerung

Aufruf:
    python3 by_parse.py --in ben_yehoyada_berakhot.txt --tractate Berakhot \
                        --out out/berakhot.parsed.json
"""
import re, json, os, argparse, collections

NIKUD = re.compile(r'[֑-ׇ]')
ABBR_TOK = re.compile(r'[א-ת֑-ׇ]+["״][א-ת֑-ׇ]+(?:["״][א-ת֑-ׇ]+)*')
SCRIPT_RE = re.compile(r'\(([^)]{2,40}?,[^)]{1,20}?)\)')
PAIR_RE = re.compile(r'(\S+?)\s*<small>\[(.*?)\]</small>')
LEMMA_RE = re.compile(r'^\s*<b>(.*?)</b>(.*)$', re.S)
DAF_RE = re.compile(r'^Daf\s+(\S+)\s*$')

BOOKS = set("""בראשית שמות ויקרא במדבר דברים יהושע שופטים שמואל מלכים ישעיה ישעיהו
ירמיה ירמיהו יחזקאל הושע יואל עמוס עובדיה יונה מיכה נחום חבקוק צפניה חגי זכריה מלאכי
תהלים תהילים משלי איוב רות איכה קהלת אסתר דניאל עזרא נחמיה""".split())


def strip_tags(s):
    s = re.sub(r'<small>\[.*?\]</small>', '', s or '')
    s = re.sub(r'</?b>', '', s)
    s = s.replace('<br>', ' ')
    return re.sub(r'\s+', ' ', s).strip()


def find_abbrs(text):
    """
    Erkennt echte hebraeische Abkuerzungstoken und merkt sich den Kontext.

    Wichtig: Ein blosses oeffnendes/schliessendes Anfuehrungszeichen ist keine
    Abkuerzung. Deshalb verlangt ABBR_TOK jetzt hebraeische Buchstaben auf
    beiden Seiten der Gershajim. Das verhindert Fehlklassifikationen wie
    ``"כי`` oder ``משה"``.

    Steht unmittelbar nach dem Kuerzel eine Senlake-Erklaerung
    ``<small>[...]</small>``, wird sie am konkreten Treffer gespeichert. Diese
    quelleneigene Erklaerung hat in Schritt 3 Vorrang vor Heuristiken.
    """
    seen, out = {}, []
    for m in ABBR_TOK.finditer(text or ''):
        t = m.group(0).strip('.:,;')
        if len(re.sub(r'[^א-ת]', '', t)) < 2:
            continue
        tail = (text or '')[m.end():]
        sm = re.match(r'\s*<small>\[(.*?)\]</small>', tail, re.S)
        inline = sm.group(1).strip() if sm else None
        a = max(0, m.start() - 120)
        b = min(len(text or ''), m.end() + 120)
        context = strip_tags((text or '')[a:b])
        if t in seen:
            rec = seen[t]
            if inline and not rec.get('inline_expansion'):
                rec['inline_expansion'] = inline
            continue
        rec = {
            'abbr': t,
            'expansion': None,
            'inline_expansion': inline,
            'context': context,
        }
        seen[t] = rec
        out.append(rec)
    return out


def find_scripture(text):
    refs = []
    for inner in SCRIPT_RE.findall(text):
        parts = inner.strip().split()
        if parts and parts[0].strip('.:,;') in BOOKS:
            refs.append('(' + inner.strip() + ')')
    return refs


def parse(path, tractate, edition=''):
    raw = open(path, encoding='utf-8').read()
    lines = raw.split('\n')

    # von der Ausgabe mitgelieferte Erklaerungen einsammeln (nur Statistik;
    # die massgebliche Aufloesung macht Schritt 3 ueber glossary_he.json)
    inline_expl, gematria = 0, 0
    for _tok, expa in PAIR_RE.findall(raw):
        if expa.strip().isdigit():
            gematria += 1
        else:
            inline_expl += 1

    try:
        first = next(i for i, l in enumerate(lines) if DAF_RE.match(l))
    except StopIteration:
        raise SystemExit('Keine "Daf X"-Marken gefunden — Dateiformat pruefen.')
    front = [l for l in lines[:first] if l.strip()]
    preface = '\n'.join(front[5:]) if len(front) > 5 else ''

    entries, cur, seq = [], None, 0
    for l in lines[first:]:
        m = DAF_RE.match(l)
        if m:
            cur, seq = m.group(1), 0
            continue
        if not l.strip() or cur is None:
            continue
        seq += 1
        para = l.strip()
        lm = LEMMA_RE.match(para)
        lemma = strip_tags(lm.group(1)) if lm else None
        body = lm.group(2).strip() if lm else para
        combined = (lemma or '') + ' ' + body
        entries.append({
            'id': '{}.{}.{}'.format(tractate.lower(), cur, seq),
            'daf': cur, 'seq': seq,
            'lemma_he': lemma,
            'commentary_html': body,
            'commentary_plain': strip_tags(body),
            'has_subnotes': '<br>' in body,
            'abbreviations': find_abbrs(combined),
            'scripture_refs': find_scripture(combined),
            'sefaria_ref': None,
            'commentary_en': None,
        })

    dafim = sorted({e['daf'] for e in entries},
                   key=lambda d: (int(re.sub(r'\D', '', d) or 0), d[-1]))
    return {
        'meta': {
            'work': 'Ben Yehoyada', 'tractate': tractate,
            'source_file': os.path.basename(path), 'source_edition': edition,
            'counts': {
                'dafim': len(dafim), 'entries': len(entries),
                'entries_with_lemma': sum(1 for e in entries if e['lemma_he']),
                'entries_freeform': sum(1 for e in entries if not e['lemma_he']),
                'inline_explanations': inline_expl, 'gematria_annotations': gematria,
            },
            'daf_range': '{} - {}'.format(dafim[0], dafim[-1]) if dafim else '',
        },
        'preface_he': preface,
        'entries': entries,
    }


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--in', dest='src', required=True)
    ap.add_argument('--tractate', required=True)
    ap.add_argument('--edition', default='Senlake 2019, based on Jerusalem 1897')
    ap.add_argument('--out', dest='dst', required=True)
    a = ap.parse_args()
    doc = parse(a.src, a.tractate, a.edition)
    os.makedirs(os.path.dirname(a.dst) or '.', exist_ok=True)
    json.dump(doc, open(a.dst, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    c = doc['meta']['counts']
    print('== PARSEN ==')
    for k, v in c.items():
        print('{:22s}: {}'.format(k, v))
    print('{:22s}: {}'.format('daf_range', doc['meta']['daf_range']))
    print('->', a.dst)
