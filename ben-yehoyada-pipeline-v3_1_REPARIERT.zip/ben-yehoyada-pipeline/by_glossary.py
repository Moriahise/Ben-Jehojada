# -*- coding: utf-8 -*-
"""
Schritt 3 — Abkuerzungen kontextsensitiv aufloesen.

Prioritaet:
  1. quelleneigene Senlake-Erklaerung <small>[...]</small>
  2. kuratierte Tabelle (glossary_he.json)
  3. Praefix + kuratierter/Buchstaben-Stamm
  4. Buchstabenname
  5. Gematria nur bei ausdruecklichem Zahlen-/Gematria-Kontext

Die entscheidende Sicherheitsregel: Bei Mehrdeutigkeit lieber KEINE Fussnote
als eine sachlich falsche. Gematria ist kein allgemeiner Auffangmechanismus.
"""
import json, re, os, unicodedata, collections

HERE = os.path.dirname(os.path.abspath(__file__))
NIKUD = re.compile(r'[֑-ׇ]')
GERSH = '״'
PREFIXES = ['ו', 'ש', 'ל', 'ב', 'כ', 'מ', 'ה', 'ד',
            'וש', 'ול', 'וב', 'וכ', 'ומ', 'וה', 'שה', 'לה', 'בה', 'כה', 'שב', 'של']
GEM = {'א':1,'ב':2,'ג':3,'ד':4,'ה':5,'ו':6,'ז':7,'ח':8,'ט':9,
       'י':10,'כ':20,'ל':30,'מ':40,'נ':50,'ס':60,'ע':70,'פ':80,'צ':90,
       'ק':100,'ר':200,'ש':300,'ת':400,
       'ך':20,'ם':40,'ן':50,'ף':80,'ץ':90}

LETTER_EN = {'א':'alef','ב':'bet','ג':'gimel','ד':'dalet','ה':'he','ו':'vav','ז':'zayin',
             'ח':'het','ט':'tet','י':'yod','כ':'kaf','ל':'lamed','מ':'mem','נ':'nun',
             'ס':'samekh','ע':'ayin','פ':'pe','צ':'tsadi','ק':'qof','ר':'resh',
             'ש':'shin','ת':'tav'}

# Nur in solchem Kontext darf ein unbekanntes Kuerzel automatisch als Zahlwert
# gedeutet werden. Das faengt echte Gematria ab, ohne z.B. תנ"ך oder ר"מ in
# Zahlen zu verwandeln.
GEMATRIA_HINT = re.compile(
    r'(?:גימטר(?:יא|ייה)?|מספר(?:ם|ו|ה)?|עולה|עולים|מנין|כמנין|חשבון|'
    r'אותיות|ערך|סך|כנגד|רומז|רמז)', re.I)

# Hinweise fuer die beiden haeufigsten mehrdeutigen Kuerzel.
YOD_LETTER_HINT = re.compile(r'(?:אות|קוצו|עצמה|מבטא|יודי|יודין|יוּד|יו"ד)')
AB_NAME_HINT = re.compile(r'(?:שם|הוי|יודי|יודין|קבלה|אר"י|ספיר|יסוד|חסד|גבורה|חכמה|בינה)')
FOLIO_HINT = re.compile(r'(?:דף|מסכת|גמרא|סנהדרין|ברכות|שבת|פסחים|עירובין|בבא|עמוד)')

LEXICAL_LOCK = {'תנ"ך','ר"מ','ר"פ','נ"ל','הו"א','ס"ל','רמ"א','רמ"ז',
                'צל"ח','כנ"ז','לפ"ז','בד"א','רשב"ם','רמב"ם','רא"ש'}


def norm(s):
    """Nikud weg, Gershayim vereinheitlichen — fuer den Schluesselvergleich."""
    s = unicodedata.normalize('NFC', s or '')
    s = NIKUD.sub('', s)
    s = s.replace(GERSH, '"').replace('׳', "'").replace('’', "'")
    return s.strip().strip('.,:;')


class Glossary:
    def __init__(self, path=None):
        path = path or os.path.join(HERE, 'glossary_he.json')
        with open(path, encoding='utf-8') as fh:
            data = json.load(fh)
        self.raw = data['abbreviations']
        self.letters = {norm(k): v for k, v in data.get('letter_names', {}).items()}
        self.idx = {norm(k): v for k, v in self.raw.items()}
        self.stats = collections.Counter()

    def _gematria(self, n):
        letters = [c for c in n if c in GEM]
        if len(letters) < 2 or len(letters) != len(re.sub(r'[^א-ת]', '', n)):
            return None
        vals = [GEM[c] for c in letters]
        if vals != sorted(vals, reverse=True):
            return None
        if any(v == vals[0] for v in vals[1:]) and len(set(vals)) == 1:
            return None
        return sum(vals)

    def _letter(self, n):
        return self.letters.get(n)

    def _inline(self, inline):
        if inline is None:
            return None
        x = re.sub(r'\s+', ' ', str(inline)).strip()
        if not x:
            return None
        if re.fullmatch(r'\d+', x):
            return {'he': 'מִסְפָּר {}'.format(x),
                    'en': 'numerical value {}'.format(x),
                    'source': 'inline_numeric'}
        return {'he': x, 'en': None, 'source': 'inline'}

    def _strong_gematria_context(self, n, context):
        """Nur unmittelbare sprachliche Zahlwert-Signale rund um das Token."""
        if n in LEXICAL_LOCK:
            return False
        ctx = norm(context or '')
        pos = ctx.find(n)
        if pos < 0:
            return False
        local = ctx[max(0, pos - 45):pos + len(n) + 45]
        escn = re.escape(n)
        hint = r'(?:גימטר(?:יא|ייה)?|מספר(?:ם|ו|ה)?|עולה|עולים|מנין|כמנין|חשבון|ערך|סך)'
        return bool(re.search(hint + r'.{0,28}' + escn, local) or
                    re.search(escn + r'.{0,28}' + hint, local))

    def _curated(self, n, context=''):
        v = self.idx.get(n)
        if not v:
            return None
        # Mehrdeutige Spezialfaelle nur dann automatisch entscheiden, wenn der
        # lokale Kontext die Lesart traegt.
        if n == 'יו"ד' and v.get('alt'):
            if YOD_LETTER_HINT.search(context or ''):
                return {'he': 'הָאוֹת יוֹ"ד', 'en': 'the letter yod', 'source': 'context'}
            if re.search(r'(?:יורה|דעה|שו"ע|שולחן)', context or ''):
                out = dict(v); out['source'] = 'curated'; return out
            return None
        if n == 'ע"ב' and v.get('alt'):
            if AB_NAME_HINT.search(context or '') or GEMATRIA_HINT.search(context or ''):
                return {'he': 'שֵׁם ע"ב (72)', 'en': 'the 72-name', 'source': 'context'}
            if FOLIO_HINT.search(context or ''):
                out = dict(v); out['source'] = 'curated'; return out
            return None
        out = dict(v)
        out['source'] = 'curated'
        return out

    def _stem_without_gematria(self, n, context=''):
        r = self._curated(n, context)
        if r:
            return r
        L = self._letter(n)
        if L:
            return {'he': 'הָאוֹת ' + L,
                    'en': 'the letter ' + LETTER_EN.get(L, L),
                    'source': 'letter'}
        return None

    def resolve(self, abbr, context='', inline_expansion=None, _depth=0):
        """-> dict(he, en, source) oder None."""
        n = norm(abbr)
        if not n:
            return None

        # 1 Quelle selbst: staerkste Evidenz pro Vorkommen.
        r = self._inline(inline_expansion)
        if r:
            return r

        # Expliziter unmittelbarer Gematria-Kontext darf eine sonst moegliche
        # lexikalische Lesung ueberstimmen (z.B. ת"ל in "מספר ת"ל").
        if self._strong_gematria_context(n, context):
            g = self._gematria(n)
            if g:
                return {'he': 'מִסְפָּר {}'.format(g),
                        'en': 'numerical value {}'.format(g),
                        'source': 'gematria_context'}

        # 2 kuratiert, einschliesslich kontextsensitiver Mehrdeutigkeiten.
        r = self._curated(n, context)
        if r:
            return r

        # 3 Praefix abtrennen — aber NICHT in Gematria hineinfallen. Nur ein
        # bekannter Stamm oder Buchstabenname darf so erweitert werden.
        if _depth == 0:
            for p in sorted(PREFIXES, key=len, reverse=True):
                if n.startswith(p) and len(n) > len(p) + 2:
                    inner = self._stem_without_gematria(n[len(p):], context)
                    if inner:
                        out = dict(inner)
                        out['he'] = p + ' + ' + inner['he']
                        out['source'] = 'prefix'
                        return out

        # 4 Buchstabenname.
        L = self._letter(n)
        if L:
            return {'he': 'הָאוֹת ' + L,
                    'en': 'the letter ' + LETTER_EN.get(L, L),
                    'source': 'letter'}

        # 5 Gematria nur mit positiver Kontext-Evidenz.
        if self._strong_gematria_context(n, context):
            g = self._gematria(n)
            if g:
                return {'he': 'מִסְפָּר {}'.format(g),
                        'en': 'numerical value {}'.format(g),
                        'source': 'gematria_context'}
        return None

    def annotate(self, doc):
        """Fuellt expansion/en/source in allen entries. Gibt Statistik zurueck."""
        total = resolved = 0
        unresolved = collections.Counter()
        self.stats.clear()
        for e in doc['entries']:
            for a in e['abbreviations']:
                total += 1
                r = self.resolve(a['abbr'],
                                 context=a.get('context') or e.get('commentary_plain') or '',
                                 inline_expansion=a.get('inline_expansion'))
                if r:
                    a['expansion'] = r['he']
                    a['expansion_en'] = r.get('en')
                    a['source'] = r['source']
                    self.stats[r['source']] += 1
                    resolved += 1
                else:
                    a['expansion'] = None
                    a['expansion_en'] = None
                    a['source'] = 'unresolved'
                    unresolved[a['abbr']] += 1
        doc.setdefault('meta', {})['glossary_coverage'] = {
            'hits_total': total,
            'hits_resolved': resolved,
            'percent': round(100.0 * resolved / total, 1) if total else 0,
            'by_source': dict(self.stats),
            'unresolved_distinct': len(unresolved),
            'unresolved_top': dict(unresolved.most_common(25)),
        }
        return doc['meta']['glossary_coverage']


if __name__ == '__main__':
    import sys
    src = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/ben_yehoyada_berakhot.json'
    dst = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, 'out', 'berakhot.glossed.json')
    g = Glossary()
    doc = json.load(open(src, encoding='utf-8'))
    cov = g.annotate(doc)
    doc['glossary_curated'] = g.raw
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    json.dump(doc, open(dst, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('== GLOSSAR-ABDECKUNG ==')
    print('Treffer gesamt      :', cov['hits_total'])
    print('aufgeloest          : {} ({}%)'.format(cov['hits_resolved'], cov['percent']))
    print('nach Mechanismus    :', cov['by_source'])
    print('offen (distinct)    :', cov['unresolved_distinct'])
    print('haeufigste offene   :')
    for k, v in list(cov['unresolved_top'].items())[:15]:
        print('   {:>4d}  {}'.format(v, k))
    print('\n->', dst)
