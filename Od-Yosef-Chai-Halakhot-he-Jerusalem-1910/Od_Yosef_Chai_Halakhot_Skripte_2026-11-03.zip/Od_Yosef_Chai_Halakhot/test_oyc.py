# -*- coding: utf-8 -*-
"""
Regressionstests Od Yosef Chai · Halakhot (offline).

    python3 -m unittest test_oyc -v

Die JSX-Tests fuehren Funktionen aus Ben_Ish_Chai_Bilingual_Book_Manager_v1_0_17
unveraendert in Node aus (parseBilingualFile, composeDisplayTexts, planVolumes);
ohne Node werden sie uebersprungen.
"""
import json
import re
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

import oyc_common as C
import oyc_abschnitte as A
import oyc_bandplan as B
import oyc_glossar as G
import oyc_kollation as K
import oyc_nakdan as N

NODE = shutil.which('node')
JSX_FUNCS = ['trim', 'normalizeNewlines', 'stripBom', 'stripTags', 'visibleLength', 'xmlUnescape',
             'restoreCdata', 'parseBilingualFile', 'composeDisplayTexts', 'planVolumes',
             'splitOversizeSection', 'newVolume', 'addGroupToVolume', 'finalizeVolume',
             'estimatedBodyPages', 'pad2']


def jsx_function(src, name):
    lines = src.splitlines()
    for i, l in enumerate(lines):
        if re.match(r'^ {4}function ' + re.escape(name) + r'\(', l):
            if l.rstrip().endswith('}') and l.count('{') == l.count('}'):
                return l
            for j in range(i + 1, len(lines)):
                if lines[j] == '    }':
                    return '\n'.join(lines[i:j + 1])
    raise KeyError(name)


def run_jsx(js_body, payload):
    src = C.BIC_JSX.read_text(encoding='utf-8')
    consts = '\n'.join(l for l in src.splitlines() if re.match(
        r'^ {4}var (MAX_PAGES|TARGET_PAGES|RESERVED_PAGES|BODY_TARGET|HE_CHARS_PER_PAGE|'
        r'EN_CHARS_PER_PAGE|EN_EXPANSION) =', l))
    funcs = '\n'.join(jsx_function(src, n) for n in JSX_FUNCS)
    prog = consts + '\n' + funcs + '\nvar INPUT = JSON.parse(require("fs").readFileSync(0, "utf8"));\n' + js_body
    with tempfile.NamedTemporaryFile('w', suffix='.js', delete=False, encoding='utf-8') as fh:
        fh.write(prog)
    r = subprocess.run([NODE, fh.name], input=json.dumps(payload), capture_output=True, text=True, timeout=120)
    Path(fh.name).unlink()
    if r.returncode:
        raise AssertionError(r.stderr)
    return json.loads(r.stdout)


class Werk(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.werk = C.load_werk()
        cls.segs = C.build_segments(cls.werk)

    def test_quelle_unveraendert(self):
        self.assertEqual(C.sha256_file(C.SOURCE_JSON), C.SOURCE_JSON_SHA256)

    def test_struktur(self):
        keys = [a['key'] for a in self.werk['abschnitte']]
        self.assertEqual(len(keys), 29)
        self.assertEqual(keys[9], 'Kuntres Chut HaMeshulash')
        self.assertEqual(self.werk['abschnitte'][9]['tiefe'], 1)
        self.assertEqual(len(self.segs), 506)
        vaera = next(a for a in self.werk['abschnitte'] if a['key'] == 'Vaera')
        self.assertTrue(vaera['halachot'][2]['leer'])

    def test_ids_und_n(self):
        self.assertEqual([s['id'] for s in self.segs], ['OYH-{:07d}'.format(i) for i in range(1, 507)])
        vaera = [s['n'] for s in self.segs if s['abschnitt'] == 'Vaera']
        self.assertEqual(vaera[:3], [1, 2, 4])          # Sefaria-Zaehlung bleibt
        self.assertEqual(self.segs[0]['ref'], 'Od Yosef Chai; Halakhot, Bereshit 1')

    def test_text_vollstaendig(self):
        joined = ''.join(C.strip_tags(s['he']).replace('\n', '') for s in self.segs)
        quelle = ''.join(C.strip_tags(p['html']).strip() for _, _, p in C.iter_absaetze(self.werk))
        self.assertEqual(joined, quelle)


class Kalibrierung(unittest.TestCase):
    def test_werte_wie_jsx(self):
        src = C.BIC_JSX.read_text(encoding='utf-8')
        def v(name):
            return float(re.search(r'var ' + name + r' = ([0-9.]+);', src).group(1))
        self.assertEqual(v('MAX_PAGES'), C.MAX_PAGES)
        self.assertEqual(v('TARGET_PAGES'), C.TARGET_PAGES)
        self.assertEqual(v('RESERVED_PAGES'), C.RESERVED_PAGES)
        self.assertEqual(v('HE_CHARS_PER_PAGE'), C.HE_CHARS_PER_PAGE)
        self.assertEqual(v('EN_CHARS_PER_PAGE'), C.EN_CHARS_PER_PAGE)
        self.assertEqual(v('EN_EXPANSION'), C.EN_EXPANSION)
        self.assertEqual(v('PAGE_W_MM'), C.PAGE_W_MM)
        self.assertEqual(v('PAGE_H_MM'), C.PAGE_H_MM)
        self.assertEqual(v('HE_LEADING'), C.HE_LEADING_PT)

    def test_ein_band_mit_reserve(self):
        with tempfile.TemporaryDirectory() as d:
            r = B.run(out=d, quiet=True)
        self.assertEqual(r['baende'], 1)
        self.assertLessEqual(r['band_seiten'][0], C.TARGET_PAGES)
        self.assertGreater(C.TARGET_PAGES - r['band_seiten'][0], 30)


@unittest.skipUnless(NODE, 'node fehlt')
class JSX(unittest.TestCase):
    def test_banddatei_vom_buchmanager_lesbar(self):
        with tempfile.TemporaryDirectory() as d:
            r = B.run(out=d, quiet=True)
            raw = Path(r['dateien'][0]).read_text(encoding='utf-8-sig')
            res = run_jsx('''
var p = parseBilingualFile(INPUT.raw);
var t = composeDisplayTexts(p);
process.stdout.write(JSON.stringify({volume:p.volume, n:p.segments.length, sections:p.sections.length,
  ids:p.segments.map(function(s){return s.id;}), nums:p.segments.map(function(s){return s.number;}),
  he:p.segments.map(function(s){return s.he;}), heVisible:t.heVisible}));''', {'raw': raw})
        segs = r['segs']
        self.assertEqual(res['volume'], 1)
        self.assertEqual(res['n'], len(segs))
        self.assertEqual(res['sections'], 29)
        self.assertEqual(res['ids'], [s['id'] for s in segs])
        self.assertEqual(res['nums'], [s['n'] for s in segs])
        self.assertEqual(res['he'], [s['he'] for s in segs])

    def test_planer_wie_jsx(self):
        werk = C.load_werk()
        segs = C.build_segments(werk)
        for s in segs:
            s['plan_chars'] = C.visible_length(s['he'])
        # kuenstlich vergroessert, damit der Planer mehrere Baende schneiden muss
        for faktor in (1, 3):
            sections = []
            for s in segs:
                if not sections or sections[-1]['title'] != s['section_he']:
                    sections.append({'title': s['section_he'], 'segments': []})
                sections[-1]['segments'].append({'id': s['id'], 'he': s['he'] * faktor})
            res = run_jsx('''
var v = planVolumes({sections: INPUT.sections});
process.stdout.write(JSON.stringify(v.map(function(x){return [x.segments[0].id, x.segments[x.segments.length-1].id, x.estimatedPages];})));''',
                          {'sections': sections})
            big = [dict(s, he=s['he'] * faktor, plan_chars=C.visible_length(s['he'] * faktor)) for s in segs]
            py = [[v['segments'][0]['id'], v['segments'][-1]['id'], v['estimated_pages']]
                  for v in B.plan_volumes(big)]
            self.assertEqual(py, res, 'Faktor {}'.format(faktor))


class Vokalisierung(unittest.TestCase):
    BASIS = '<b>כתב</b> רבינו הרש"ש ז"ל בנהר שלום דף ב"ן, בענין'
    VOK = 'כָּתַב רַבֵּינוּ הָרַשַׁ"שׁ זַ"ל בִּנְהַר שָׁלוֹם דַּף ב"ן בְּעִנְיַן'

    def test_transfer(self):
        self.assertEqual(K.transfer('בסה"ק', 'בְּסֵהַ״ק'), 'בְּסֵהַ"ק')
        self.assertIsNone(K.transfer('רבינו', 'רַבֵּנוּ'))

    def test_vokalisiere_html_behaelt_tags_und_konsonanten(self):
        out, ok, offen = K.vokalisiere_html(self.BASIS, self.VOK)
        self.assertTrue(out.startswith('<b>כָּתַב</b> '))
        self.assertEqual(C.strip_nikud(out), self.BASIS)
        self.assertEqual(offen, 0)
        out2, _, offen2 = K.vokalisiere_html(self.BASIS, self.VOK.replace('רַבֵּינוּ', 'רַבֵּנוּ'))
        self.assertIn(' רבינו ', out2)                 # Abweichung: Basiswort bleibt
        self.assertEqual(offen2, 1)

    def test_kollation_arten(self):
        meine = self.VOK.replace('שָׁלוֹם', 'שלום').replace('דַּף', 'דָּף')
        rows, _ = K.kollationiere_absatz('X 1:1', self.BASIS, {'nakdan': self.VOK.replace('רַבֵּינוּ', 'רַבֵּנוּ'),
                                                               'meine': meine})
        arten = {(r[2], r[3]) for r in rows}
        self.assertIn(('TEXT_N', 'רבינו'), arten)
        self.assertIn(('UNVOK_M', 'שלום'), arten)
        self.assertIn(('VOK', 'דף'), arten)
        self.assertFalse(any(r[2].endswith('_M') and r[2] != 'UNVOK_M' for r in rows))

    def test_marker_rundlauf(self):
        werk = C.load_werk()
        teile = N.export_teile(werk, 15000)
        with tempfile.TemporaryDirectory() as d:
            for name, e in teile:
                N.schreibe_marker(Path(d) / name, e, 'Test')
            texte = N.lese_zeuge(d)
        self.assertEqual(len(texte), 1024)
        b = N.pruefe_zeuge(werk, texte)
        self.assertEqual(b['konsonanten_abweichend'], [])
        self.assertTrue(all(sum(len(t) for _, t in e) <= 15000 or len(e) == 1 for _, e in teile))

    def test_nakdan_antwortformen(self):
        a = [{'word': 'שלום', 'sep': False, 'options': [['שָׁ|לוֹם', []]]}, {'word': ' ', 'sep': True}]
        b = {'data': [{'word': 'שלום', 'sep': False, 'nakdan': {'options': [{'w': 'שָׁלוֹם'}]}}]}
        c = [{'word': 'שלום', 'sep': False, 'options': ['שָׁלוֹם']}]
        self.assertEqual(N.nakdan_text(a), 'שָׁלוֹם ')
        self.assertEqual(N.nakdan_text(b), 'שָׁלוֹם')
        self.assertEqual(N.nakdan_text(c), 'שָׁלוֹם')

    def test_teile_text(self):
        t = ('אבג דהו, ' * 900).strip()
        teile = N.teile_text(t, 4000)
        self.assertEqual(''.join(teile), t)
        self.assertTrue(all(len(x) <= 4000 for x in teile))


class Glossar(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.res = G.run(out=cls.tmp, quiet=True)
        cls.neu = json.loads((Path(cls.tmp) / 'glossar' / (C.WERK_TAG + '_Glossar_NEU.json')).read_text(encoding='utf-8'))
        cls.rows = C.read_tsv(Path(cls.tmp) / 'glossar' / (C.WERK_TAG + '_GLOSSAR.tsv'))

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp)

    def test_by_glossar_uebernommen(self):
        st = {r['abbr']: r['status'] for r in self.rows}
        self.assertTrue(st['ק"ש'].startswith('UEBERNOMMEN'))
        self.assertTrue(st['הרש"ש'].startswith('UEBERNOMMEN'))
        self.assertIn('NEU', st['ש"ץ'])

    def test_neue_termini_markiert(self):
        self.assertIn('ש"ץ', self.neu['neu'])
        self.assertTrue(all(v['neu'] and v['he'] == '' for v in self.neu['neu'].values()))
        self.assertEqual(self.neu['neu']['בש"ץ']['stamm'], 'ש"ץ')
        self.assertEqual(self.neu['_meta']['basis_eintraege'],
                         len(json.loads(C.GLOSSARY.read_text(encoding='utf-8'))['abbreviations']))

    def test_glossar_unveraendert(self):
        self.assertEqual(self.res['glossar_sha256'], C.sha256_file(C.GLOSSARY))

    def test_stellenzahl(self):
        C.import_pipeline()
        import by_glossary
        g = by_glossary.Glossary(str(C.GLOSSARY))
        self.assertEqual(G.stellenzahl(g, 'י"ג', "כתב מרן ז\"ל סי' "), 13)
        self.assertIsNone(G.stellenzahl(g, 'י"ג', 'כתב מרן ז"ל '))


class Scan(unittest.TestCase):
    def test_konkordanz_und_belege(self):
        werk = C.load_werk()
        _, summary = A.abschnittsliste(werk)
        konk = A.lade_konkordanz(C.HERE / 'scan_konkordanz.tsv')
        ab = A.scanabgleich(werk, summary, None, konk, None, A.lade_belege(C.HERE / 'scan_belege.json'))
        self.assertEqual(ab['befunde']['FEHLER'], [])
        st = {a['key']: a['status'] for a in ab['abschnitte']}
        self.assertEqual(st['Bereshit'], 'NOCH NICHT IM SCANBEREICH')
        self.assertEqual(st['Shoftim'], 'AUSSERHALB DES ANGEGEBENEN UMFANGS')
        self.assertEqual(st['Kuntres Chut HaMeshulash'], 'NOCH NICHT IM SCANBEREICH')
        self.assertTrue(any('Vaera: Ot 3' in b for b in ab['befunde']['PRUEFEN']))

    def test_ot_zahl_und_reihenfolge(self):
        werk = C.load_werk()
        _, summary = A.abschnittsliste(werk)
        konk = [{'seq': 100, 'fl_id': '', 'art': 'Halakhot', 'abschnitt': 'Noach', 'ot_von': 1, 'ot_bis': 19},
                {'seq': 90, 'fl_id': '', 'art': 'Halakhot', 'abschnitt': 'Bereshit', 'ot_von': 1, 'ot_bis': 10},
                {'seq': 95, 'fl_id': '', 'art': 'Halakhot', 'abschnitt': 'Lech Lecha', 'ot_von': 1, 'ot_bis': 5},
                {'seq': 96, 'fl_id': '', 'art': 'Halakhot', 'abschnitt': 'Bechukotai', 'ot_von': 1, 'ot_bis': 2}]
        ab = A.scanabgleich(werk, summary, None, konk, 400, [])
        st = {a['key']: a['status'] for a in ab['abschnitte']}
        self.assertEqual(st['Bereshit'], 'ANZAHL ABWEICHEND')
        self.assertEqual(st['Lech Lecha'], 'REIHENFOLGE ABWEICHEND')
        self.assertTrue(any('NUR IM SCAN' in b for b in ab['befunde']['PRUEFEN']))

    def test_kopfzeile_deuten(self):
        werk = C.load_werk()
        self.assertEqual(A.deute_kopfzeile('הלכות  עוד יוסף חי  חיי שרה', werk), ('Halakhot', 'Chayei Sara'))
        self.assertEqual(A.deute_kopfzeile('פתיחה עוד יוסף חי ראשנה', werk), ('Derashot', ''))

    def test_iiif(self):
        v2 = {'sequences': [{'canvases': [{'images': [{'resource': {
            '@id': 'x', 'service': {'@id': 'https://iiif.example/IIIFv21/FL244210892'}}}]}]}]}
        v3 = {'items': [{'items': [{'items': [{'body': {
            'id': 'y', 'service': [{'id': 'https://iiif.example/iiif/3/FL1'}]}}]}]}]}
        self.assertEqual(A.iiif_seiten(v2), [(1, 'FL244210892', 'https://iiif.example/IIIFv21/FL244210892/full/full/0/default.jpg')])
        self.assertEqual(A.iiif_seiten(v3)[0][1], 'FL1')

    def test_kurzliste(self):
        self.assertEqual(A.kurzliste([1, 2, 3, 5, 7, 8]), '1-3,5,7-8')


class Schutz(unittest.TestCase):
    def test_kein_ueberschreiben_mit_englisch(self):
        with tempfile.TemporaryDirectory() as d:
            r = B.run(out=d, quiet=True)
            f = Path(r['dateien'][0])
            raw = f.read_text(encoding='utf-8-sig').replace('<en></en>', '<en><![CDATA[Translated.]]></en>', 1)
            C.write_bic_text(f, raw)
            with self.assertRaises(SystemExit):
                B.run(out=d, quiet=True)

    def test_textkorrektur_nur_mit_beleg(self):
        werk = C.load_werk()
        with self.assertRaises(SystemExit):
            C.wende_textkorrekturen(werk, [{'ref': 'Nicht 1:1', 'alt': 'x', 'neu': 'y', 'scan_seq': 1, 'grund': 'g'}])
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / 'tk.json'
            f.write_text(json.dumps({'korrekturen': [{'ref': 'Bereshit 2:1', 'alt': 'a', 'neu': 'b'}]}), encoding='utf-8')
            with self.assertRaises(SystemExit):
                C.lade_textkorrekturen(f)
        log = C.wende_textkorrekturen(werk, [{'ref': 'Bereshit 2:1', 'alt': 'שעדיין', 'neu': 'שעדין',
                                              'scan_seq': 99, 'grund': 'Test'}])
        self.assertEqual(len(log), 1)


if __name__ == '__main__':
    unittest.main()
