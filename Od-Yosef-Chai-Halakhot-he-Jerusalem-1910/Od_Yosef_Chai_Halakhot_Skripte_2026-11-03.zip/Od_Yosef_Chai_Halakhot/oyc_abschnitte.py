# -*- coding: utf-8 -*-
"""
Schritt 1 — Abschnittsliste aus dem Sefaria-JSON und Abgleich mit dem NLI-Scan.

Quellen
    JSON  Sefaria "Od Yosef Chai; Halakhot - he - Jerusalem, 1910"
          (versionSource = NLI NNL_ALEPH990019337340205171)
    Scan  NLI-Digitalisat derselben Ausgabe, Seitenbilder NNNN_FLxxxxxxxxx.jpg
          (ZIP oder Ordner; mehrere Angaben moeglich, z. B. 1-25 und 26-400)

Der Abgleich laeuft ueber die Scan-Konkordanz (scan_konkordanz.tsv): je
Scanseite Art (Halakhot, Derashot, Titelblatt ...), Abschnitt (JSON-Schluessel
wie "Bereshit"), erste und letzte Ot auf der Seite und die Kolumnentitel.
Die Konkordanz ist Lektoratsarbeit; das Skript prueft sie gegen JSON und
Scaninventar und erzeugt dafuer einen Pruefbogen mit den Kopfzeilen jeder Seite.
Optional schlaegt Tesseract (-l heb) Kolumnentitel vor; die Konkordanz selbst
wird nie automatisch ueberschrieben.

Aufrufe
    python3 oyc_abschnitte.py --scan scan.zip --out out
    python3 oyc_abschnitte.py --scan scan.zip --scan-gesamt 412 --ocr --out out
    python3 oyc_abschnitte.py --laden-sefaria --vergleiche-sefaria --out out
    python3 oyc_abschnitte.py --iiif-manifest <URL> --seiten 26-120 --laden-nach scan_pages/
"""
import argparse
import collections
import html
import io
import json
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import oyc_common as C

SCAN_NAME_RE = re.compile(r'(?:^|/)(\d{3,5})_(FL\d+)\.(?:jpe?g|png|tiff?)$', re.I)
ARTEN = ['Einband', 'Vorsatz', 'Kontrollaufnahme', 'Titelblatt', 'Titelrueckseite',
         'Vorspann', 'Derashot', 'Halakhot', 'Kuntres', 'Register', 'Leer', 'Unklar']
HALACHA_ARTEN = {'Halakhot', 'Kuntres'}
KONK_HEADER = ['seq', 'fl_id', 'art', 'abschnitt', 'ot_von', 'ot_bis',
               'kopf_rechts', 'kopf_mitte', 'kopf_links', 'bemerkung']


# --- Abschnittsliste ---------------------------------------------------------
def incipit(html_text, n_words=8):
    t = re.sub(r'\s+', ' ', C.strip_tags(html_text)).strip()
    return ' '.join(t.split(' ')[:n_words])


def stichwort(html_text):
    m = re.match(r'\s*<b>(.*?)</b>', html_text or '', re.S)
    return C.strip_tags(m.group(1)).strip() if m else ''


def abschnittsliste(werk):
    rows, summary = [], []
    for a in werk['abschnitte']:
        n_hal = sum(1 for h in a['halachot'] if not h['leer'])
        leer = [h['n'] for h in a['halachot'] if h['leer']]
        chars = 0
        n_abs = 0
        for h in a['halachot']:
            first = next((p for p in h['absaetze'] if C.strip_tags(p['html']).strip()), None)
            seg_chars = C.visible_length(C.segment_he(h)) if not h['leer'] else 0
            nabs = sum(1 for p in h['absaetze'] if C.strip_tags(p['html']).strip())
            chars += seg_chars
            n_abs += nabs
            hinweis = []
            if h['leer']:
                hinweis.append('LEER in Sefaria – im Scan pruefen')
            if seg_chars > C.BATCH_MAX_CHARS:
                hinweis.append('Segment > {} Zeichen (Batch-Kontingent)'.format(C.BATCH_MAX_CHARS))
            if first and not stichwort(first['html']) and a['tiefe'] == 2:
                hinweis.append('kein fettes Stichwort')
            rows.append([a['ord'], a['key'], a['he_title'], h['n'], h['ref'], nabs, seg_chars,
                         stichwort(first['html']) if first else '',
                         incipit(first['html']) if first else '', '; '.join(hinweis)])
        summary.append({'ord': a['ord'], 'key': a['key'], 'he': a['he'],
                        'he_title': a['he_title'], 'tiefe': a['tiefe'],
                        'parascha': a['parascha'], 'halachot': n_hal,
                        'hoechste_ot': max((h['n'] for h in a['halachot']), default=0),
                        'leer': leer, 'absaetze': n_abs, 'zeichen': chars})
    return rows, summary


def schema_pruefung(werk):
    m = werk['meta']
    befunde = []
    if m['schema_reihenfolge'] and m['schema_reihenfolge'] != m['text_reihenfolge']:
        befunde.append('Schema-Reihenfolge weicht von der Textreihenfolge ab.')
    bekannt = [a['key'] for a in werk['abschnitte'] if a['parascha']]
    pos = [C.PARASHOT.index(k) for k in bekannt]
    if pos != sorted(pos):
        befunde.append('Paraschot nicht in Tora-Reihenfolge: ' + ', '.join(bekannt))
    sonder = [a['key'] for a in werk['abschnitte'] if not a['parascha']]
    if sonder:
        befunde.append('Sonderabschnitte (keine Parascha): ' + ', '.join(sonder))
    for a in werk['abschnitte']:
        if a['tiefe'] == 1:
            befunde.append('{}: Tiefe 1 (Absaetze ohne Ot-Gliederung, {} Absaetze)'.format(
                a['key'], len(a['halachot'])))
    for p in (p for _, _, p in C.iter_absaetze(werk)):
        if re.match(r'\s*\[\d+\]', C.strip_tags(p['html'])):
            befunde.append('{}: Absatz beginnt mit [Zahl] – stoert die [n]-Zuordnung im '
                           'Buchmanager'.format(p['ref']))
    return befunde


# --- Sefaria-Fassungen vergleichen -------------------------------------------
def vergleiche_werke(a, b):
    """Strukturvergleich zweier JSON-Fassungen (z. B. Upload gegen aktuelle
    Sefaria-Fassung). Liefert Liste von Befundzeilen."""
    out = []
    ka = [x['key'] for x in a['abschnitte']]
    kb = [x['key'] for x in b['abschnitte']]
    for k in ka:
        if k not in kb:
            out.append('nur in A: Abschnitt ' + k)
    for k in kb:
        if k not in ka:
            out.append('nur in B: Abschnitt ' + k)
    ia, ib = C.absatz_index(a), C.absatz_index(b)
    changed = [r for r in ia if r in ib and ia[r][2]['html'] != ib[r][2]['html']]
    only_a = [r for r in ia if r not in ib]
    only_b = [r for r in ib if r not in ia]
    for r in changed[:40]:
        out.append('Absatz geaendert: ' + r)
    if len(changed) > 40:
        out.append('… {} weitere geaenderte Absaetze'.format(len(changed) - 40))
    for r in only_a[:20]:
        out.append('Absatz nur in A: ' + r)
    for r in only_b[:20]:
        out.append('Absatz nur in B: ' + r)
    out.insert(0, 'Absaetze: A {} · B {} · geaendert {} · nur A {} · nur B {}'.format(
        len(ia), len(ib), len(changed), len(only_a), len(only_b)))
    return out


# --- Scaninventar -------------------------------------------------------------
class ScanQuelle:
    """Seitenbilder aus ZIP-Dateien oder Ordnern, Schluessel = Sequenznummer."""

    def __init__(self, pfade):
        self.seiten = {}
        for p in pfade or []:
            p = Path(p)
            if p.is_file() and zipfile.is_zipfile(p):
                z = zipfile.ZipFile(p)
                for info in z.infolist():
                    m = SCAN_NAME_RE.search(info.filename)
                    if m:
                        self._add(int(m.group(1)), m.group(2), info.filename, info.file_size,
                                  ('zip', p, info.filename))
            elif p.is_dir():
                for f in sorted(p.rglob('*')):
                    m = SCAN_NAME_RE.search(f.name)
                    if m and f.is_file():
                        self._add(int(m.group(1)), m.group(2), f.name, f.stat().st_size,
                                  ('file', f, None))
            else:
                raise SystemExit('Scanquelle nicht gefunden oder kein ZIP/Ordner: ' + str(p))

    def _add(self, seq, fl, name, size, ref):
        if seq in self.seiten and self.seiten[seq]['fl_id'] != fl:
            raise SystemExit('Scanseite {} doppelt mit verschiedenen FL-IDs'.format(seq))
        self.seiten[seq] = {'seq': seq, 'fl_id': fl, 'datei': name, 'bytes': size, '_ref': ref}

    def bytes_of(self, seq):
        kind, path, member = self.seiten[seq]['_ref']
        if kind == 'zip':
            with zipfile.ZipFile(path) as z:
                return z.read(member)
        return Path(path).read_bytes()

    def image(self, seq):
        from PIL import Image
        return Image.open(io.BytesIO(self.bytes_of(seq)))


def scaninventar(scan):
    import hashlib
    rows = []
    for seq in sorted(scan.seiten):
        s = scan.seiten[seq]
        data = scan.bytes_of(seq)
        w = h = ''
        try:
            im = scan.image(seq)
            w, h = im.size
        except Exception:
            pass
        rows.append([seq, s['fl_id'], s['datei'], s['bytes'], hashlib.sha256(data).hexdigest(), w, h])
    return rows


def kopfzeile(scan, seq, anteil=0.12, breite=1000):
    im = scan.image(seq).convert('L')
    w, h = im.size
    c = im.crop((0, 0, w, int(h * anteil)))
    return c.resize((breite, max(1, int(breite * c.size[1] / w))))


# --- OCR-Vorschlag (optional) ------------------------------------------------
def tesseract_vorhanden():
    return shutil.which('tesseract') is not None


def ocr_kopfzeile(scan, seq, tmpdir):
    im = scan.image(seq).convert('L')
    w, h = im.size
    crop = im.crop((0, 0, w, int(h * 0.12)))
    f = Path(tmpdir) / '{:04d}_kopf.png'.format(seq)
    crop.save(f)
    r = subprocess.run(['tesseract', str(f), 'stdout', '-l', 'heb', '--psm', '6'],
                       capture_output=True, text=True, timeout=120)
    return re.sub(r'\s+', ' ', r.stdout).strip()


def deute_kopfzeile(text, werk):
    """Ordnet einen (OCR-)Kolumnentitel einem JSON-Abschnitt zu.
    Liefert (art, abschnitt) oder ('', '')."""
    t = ' ' + re.sub(r'[^א-ת ]', ' ', C.strip_nikud(text or '')) + ' '
    t = re.sub(r'\s+', ' ', t)
    treffer = []
    for a in werk['abschnitte']:
        he = ' ' + re.sub(r'[^א-ת ]', ' ', a['he']).strip() + ' '
        if he.strip() and he in t:
            treffer.append(a)
    if not treffer:
        if 'פתיחה' in t or 'פתיח' in t:
            return 'Derashot', ''
        return '', ''
    best = max(treffer, key=lambda a: len(a['he']))
    art = 'Kuntres' if best['tiefe'] == 1 else ('Halakhot' if 'הלכות' in t else 'Unklar')
    return art, best['key']


# --- Belege des Buches ueber seinen Umfang -------------------------------------
BUECHER = [('Bereshit', 0, 11), ('Shemot', 12, 22), ('Vayikra', 23, 32),
           ('Bamidbar', 33, 42), ('Devarim', 43, 53)]


def buch_der_parascha(key):
    i = C.PARASHOT.index(key)
    return next(b for b, lo, hi in BUECHER if lo <= i <= hi)


def buecher_der_abschnitte(werk):
    """Buch je Abschnitt; Sonderabschnitte (Purim, Kuntres) gehoeren zum Buch
    der folgenden Parascha (Kuntres: 'קודם שאכתוב הלכות ... לפרשת מקץ')."""
    keys = [a['key'] for a in werk['abschnitte']]
    out = {}
    for i, a in enumerate(werk['abschnitte']):
        if a['parascha']:
            out[a['key']] = buch_der_parascha(a['key'])
            continue
        nxt = next((k for k in keys[i + 1:] if k in C.PARASHOT), None)
        prv = next((k for k in reversed(keys[:i]) if k in C.PARASHOT), None)
        out[a['key']] = buch_der_parascha(nxt or prv) if (nxt or prv) else ''
    return out


def lade_belege(path):
    if not path or not Path(path).exists():
        return []
    return json.loads(Path(path).read_text(encoding='utf-8')).get('belege', [])


def pruefe_belege(werk, summary, belege):
    """-> {key: hinweis} und Befundzeilen fuer Abschnitte ausserhalb des
    vom Buch selbst angegebenen Umfangs."""
    buch = buecher_der_abschnitte(werk)
    hinweise, befunde = {}, []
    for b in belege:
        if b.get('art') != 'umfang':
            continue
        erlaubt = set(b.get('buecher') or [])
        aus = [s for s in summary if buch.get(s['key']) and buch[s['key']] not in erlaubt]
        for s in aus:
            hinweise[s['key']] = 'laut Scan S. {} nur {} – Abschnitt gehoert zu {}'.format(
                b['seq'], '/'.join(sorted(erlaubt)), buch[s['key']])
        if aus:
            befunde.append('Umfang laut Buch (Scan S. {}, {}): nur Halakhot zu {}. Im JSON ausserhalb: '
                           '{} ({} Halachot, {} Zeichen) – Herkunft im Scan pruefen'.format(
                               b['seq'], b.get('stelle', ''), ' und '.join(b.get('buecher') or []),
                               ', '.join(s['key'] for s in aus), sum(s['halachot'] for s in aus),
                               sum(s['zeichen'] for s in aus)))
    return hinweise, befunde, buch


# --- Konkordanz ---------------------------------------------------------------
def lade_konkordanz(path):
    if not path or not Path(path).exists():
        return []
    rows = C.read_tsv(path)
    for r in rows:
        r['seq'] = int(r['seq'])
        for k in ('ot_von', 'ot_bis'):
            r[k] = int(r[k]) if (r.get(k) or '').strip().isdigit() else None
    return rows


def scanabgleich(werk, summary, scan, konk, scan_gesamt=None, belege=None):
    befunde = collections.OrderedDict((k, []) for k in
                                      ('FEHLER', 'PRUEFEN', 'HINWEIS'))
    umfang_hinweis, umfang_befunde, buch = pruefe_belege(werk, summary, belege or [])
    befunde['PRUEFEN'].extend(umfang_befunde)
    inv = scan.seiten if scan else {}
    keys = {s['key']: s for s in summary}
    erfasst = set()
    for r in konk:
        erfasst.add(r['seq'])
        if r['art'] and r['art'] not in ARTEN:
            befunde['FEHLER'].append('Konkordanz Seite {}: unbekannte Art "{}"'.format(r['seq'], r['art']))
        if inv:
            if r['seq'] not in inv:
                befunde['PRUEFEN'].append('Konkordanz Seite {}: Bild nicht im Scaninventar'.format(r['seq']))
            elif r['fl_id'] and r['fl_id'] != inv[r['seq']]['fl_id']:
                befunde['FEHLER'].append('Konkordanz Seite {}: FL-ID {} ≠ Inventar {}'.format(
                    r['seq'], r['fl_id'], inv[r['seq']]['fl_id']))
        if r['art'] in HALACHA_ARTEN:
            if not r['abschnitt']:
                befunde['FEHLER'].append('Konkordanz Seite {}: Halakhot-Seite ohne Abschnitt'.format(r['seq']))
            elif r['abschnitt'] not in keys:
                befunde['PRUEFEN'].append('NUR IM SCAN: Seite {} Abschnitt "{}" fehlt im JSON'.format(
                    r['seq'], r['abschnitt']))
        if r['ot_von'] and r['ot_bis'] and r['ot_von'] > r['ot_bis']:
            befunde['FEHLER'].append('Konkordanz Seite {}: ot_von > ot_bis'.format(r['seq']))
    nicht_erfasst = sorted(set(inv) - erfasst)

    vorhanden = len(inv)
    vollstaendig = bool(scan_gesamt) and vorhanden >= scan_gesamt and not nicht_erfasst
    abschnitte = []
    letzte_seite = 0
    for s in summary:
        seiten = sorted(r['seq'] for r in konk if r['art'] in HALACHA_ARTEN and r['abschnitt'] == s['key'])
        ots = [r['ot_bis'] for r in konk if r['abschnitt'] == s['key'] and r['ot_bis']]
        ots += [r['ot_von'] for r in konk if r['abschnitt'] == s['key'] and r['ot_von']]
        status, notiz = '', []
        if seiten:
            status = 'IM SCAN'
            if seiten[0] < letzte_seite:
                status = 'REIHENFOLGE ABWEICHEND'
                befunde['PRUEFEN'].append('{}: beginnt im Scan (S. {}) vor dem Ende des vorigen '
                                          'JSON-Abschnitts (S. {})'.format(s['key'], seiten[0], letzte_seite))
            letzte_seite = max(letzte_seite, seiten[-1])
            luecken = [x for x in range(seiten[0], seiten[-1] + 1) if x not in seiten
                       and x in {r['seq'] for r in konk if r['art'] in HALACHA_ARTEN}]
            if luecken:
                notiz.append('unterbrochen durch Seiten anderer Abschnitte: ' + ','.join(map(str, luecken)))
            if ots and s['tiefe'] == 2:
                scan_max = max(ots)
                if scan_max != s['hoechste_ot']:
                    status = 'ANZAHL ABWEICHEND'
                    befunde['PRUEFEN'].append('{}: hoechste Ot im Scan {} · im JSON {}'.format(
                        s['key'], scan_max, s['hoechste_ot']))
                else:
                    notiz.append('Ot-Zahl stimmt ({})'.format(scan_max))
            elif s['tiefe'] == 2:
                notiz.append('Ot-Zahl im Scan noch nicht erfasst (ot_von/ot_bis)')
        else:
            status = 'FEHLT IM SCAN' if vollstaendig else 'NOCH NICHT IM SCANBEREICH'
            if vollstaendig:
                befunde['FEHLER'].append('{}: im vollstaendigen Scan nicht gefunden'.format(s['key']))
        if s['key'] in umfang_hinweis:
            if status == 'IM SCAN':
                notiz.append('im Scan vorhanden, obwohl ausserhalb des angegebenen Umfangs')
            else:
                status = 'AUSSERHALB DES ANGEGEBENEN UMFANGS'
            notiz.append(umfang_hinweis[s['key']])
        if s['leer']:
            befunde['PRUEFEN'].append('{}: Ot {} ist in Sefaria leer – Text im Scan suchen'.format(
                s['key'], ','.join(map(str, s['leer']))))
            notiz.append('leere Ot im JSON: ' + ','.join(map(str, s['leer'])))
        abschnitte.append({'ord': s['ord'], 'key': s['key'], 'he_title': s['he_title'],
                           'buch': buch.get(s['key'], ''), 'status': status, 'scanseiten': seiten,
                           'erste_seite': seiten[0] if seiten else None,
                           'halachot_json': s['halachot'], 'hoechste_ot_json': s['hoechste_ot'],
                           'notiz': '; '.join(notiz)})
    if nicht_erfasst:
        befunde['HINWEIS'].append('Scanseiten ohne Konkordanzeintrag: ' + kurzliste(nicht_erfasst))
    if not scan_gesamt:
        befunde['HINWEIS'].append('Gesamtseitenzahl des Digitalisats nicht angegeben (--scan-gesamt); '
                                  '"fehlt" wird deshalb nicht festgestellt.')
    arten = collections.Counter(r['art'] for r in konk)
    hal_seiten = sum(1 for r in konk if r['art'] in HALACHA_ARTEN)
    return {'scanseiten_vorhanden': vorhanden, 'scan_gesamt': scan_gesamt,
            'scanseiten_von_bis': [min(inv), max(inv)] if inv else None,
            'konkordanz_seiten': len(konk), 'arten': dict(arten),
            'halakhot_seiten': hal_seiten, 'vollstaendig': vollstaendig,
            'nicht_erfasst': nicht_erfasst, 'abschnitte': abschnitte,
            'befunde': befunde}


def kurzliste(nums):
    nums = sorted(nums)
    out, start, prev = [], None, None
    for n in nums + [None]:
        if start is None:
            start = prev = n
        elif n is not None and n == prev + 1:
            prev = n
        else:
            out.append(str(start) if start == prev else '{}-{}'.format(start, prev))
            start = prev = n
    return ','.join(out)


# --- Ausgabe ------------------------------------------------------------------
def bericht_text(werk, summary, schema, abgl, vergleich=None):
    m = werk['meta']
    L = ['OD YOSEF CHAI · HALAKHOT · ABSCHNITTSLISTE UND SCANABGLEICH', '',
         'JSON:  {} · {}'.format(m['title'], m['versionTitle']),
         '       {} · sha256 {}'.format(Path(m['datei']).name, m['sha256']),
         'Quelle laut JSON: {}'.format(m['versionSource']),
         'Lizenz laut JSON: {}'.format(m['license']), '',
         'ABSCHNITTE (JSON-Reihenfolge)',
         '{:>3}  {:<26} {:<20} {:<9} {:>5} {:>6} {:>8}  {}'.format('Nr', 'Schluessel', 'Titel', 'Buch', 'Ot', 'Abs.', 'Zeichen', 'Scan')]
    st = {a['key']: a for a in abgl['abschnitte']}
    for s in summary:
        a = st[s['key']]
        scan = a['status'] + (' S.{}–{}'.format(a['scanseiten'][0], a['scanseiten'][-1]) if a['scanseiten'] else '')
        L.append('{:>3}  {:<26} {:<20} {:<9} {:>5} {:>6} {:>8}  {}'.format(
            s['ord'], s['key'], s['he_title'], a['buch'], s['halachot'], s['absaetze'], s['zeichen'], scan))
    L += ['', 'Summe: {} Abschnitte · {} Halachot/Segmente · {} Absaetze · {} Zeichen'.format(
        len(summary), sum(s['halachot'] for s in summary), sum(s['absaetze'] for s in summary),
        sum(s['zeichen'] for s in summary)), '', 'STRUKTUR DES JSON']
    L += ['  - ' + b for b in schema] or ['  ohne Befund']
    L += ['', 'SCAN',
          '  Seiten im Inventar: {}{}'.format(abgl['scanseiten_vorhanden'],
                                              ' (Seq. {}–{})'.format(*abgl['scanseiten_von_bis']) if abgl['scanseiten_von_bis'] else ''),
          '  Gesamtseiten Digitalisat: {}'.format(abgl['scan_gesamt'] or 'nicht angegeben'),
          '  Konkordanz: {} Seiten erfasst · Arten: {}'.format(
              abgl['konkordanz_seiten'], ', '.join('{} {}'.format(k, v) for k, v in sorted(abgl['arten'].items()))),
          '  Halakhot-/Kuntres-Seiten im erfassten Bereich: {}'.format(abgl['halakhot_seiten']),
          '  Abgleich vollstaendig: {}'.format('ja' if abgl['vollstaendig'] else 'nein')]
    for k, v in abgl['befunde'].items():
        L += ['', '{} ({})'.format(k, len(v))] + ['  - ' + x for x in v]
    if vergleich is not None:
        L += ['', 'VERGLEICH MIT AKTUELLER SEFARIA-FASSUNG'] + ['  - ' + x for x in vergleich]
    return '\n'.join(L) + '\n'


def pruefbogen_html(path, werk, summary, abgl, konk, scan, bilder_dir):
    konk_by = {r['seq']: r for r in konk}
    st = {a['key']: a for a in abgl['abschnitte']}
    first_ot = {}
    for a in werk['abschnitte']:
        h = next((h for h in a['halachot'] if not h['leer']), None)
        if h:
            p = next(p for p in h['absaetze'] if C.strip_tags(p['html']).strip())
            first_ot[a['key']] = (h['n'], incipit(p['html'], 14))
    e = html.escape
    out = ['<!doctype html><html lang="de"><head><meta charset="utf-8">',
           '<title>OYC Scanabgleich</title><style>',
           'body{font-family:system-ui,sans-serif;margin:16px;color:#222;background:#fff}',
           'table{border-collapse:collapse;width:100%;margin:12px 0}td,th{border:1px solid #ccc;padding:4px 6px;vertical-align:top;font-size:13px}',
           '.he{direction:rtl;font-family:"Frank Ruhl Libre","Times New Roman",serif;font-size:15px}',
           '.ok{background:#e8f5e9}.warn{background:#fff8e1}.bad{background:#ffebee}.todo{background:#f3f3f3}',
           'img{max-width:100%;height:auto;display:block}h2{margin-top:28px}',
           '</style></head><body>',
           '<h1>Od Yosef Chai · Halakhot · Scanabgleich</h1>',
           '<p>JSON {} · {} Abschnitte · Scan {} Seiten im Inventar · Konkordanz {} Seiten</p>'.format(
               e(werk['meta']['versionTitle']), len(summary), abgl['scanseiten_vorhanden'], len(konk)),
           '<h2>Abschnitte</h2><table><tr><th>Nr</th><th>Abschnitt</th><th>Titel</th><th>Ot (JSON)</th>'
           '<th>Status</th><th>Scanseiten</th><th>Beginn Ot 1 (JSON)</th><th>Notiz</th></tr>']
    for s in summary:
        a = st[s['key']]
        cls = {'IM SCAN': 'ok', 'NOCH NICHT IM SCANBEREICH': 'todo', 'FEHLT IM SCAN': 'bad'}.get(a['status'], 'warn')
        fo = first_ot.get(s['key'], ('', ''))
        out.append('<tr class="{}"><td>{}</td><td>{}</td><td class="he">{}</td><td>{}</td><td>{}</td><td>{}</td>'
                   '<td class="he">[{}] {}</td><td>{}</td></tr>'.format(
                       cls, s['ord'], e(s['key']), e(s['he_title']), s['halachot'], e(a['status']),
                       e(kurzliste(a['scanseiten'])), fo[0], e(fo[1]), e(a['notiz'])))
    out.append('</table><h2>Scanseiten · Kolumnentitel</h2><table><tr><th>Seq</th><th>FL</th>'
               '<th>Konkordanz</th><th>Kopfzeile (Ausschnitt)</th></tr>')
    for seq in sorted(scan.seiten if scan else konk_by):
        r = konk_by.get(seq, {})
        kopf = ' · '.join(r.get(k, '') for k in ('kopf_rechts', 'kopf_mitte', 'kopf_links') if r.get(k))
        info = '<b>{}</b> {}{}<br><span dir="auto">{}</span>'.format(
            e(r.get('art', '–')), e(r.get('abschnitt', '')),
            '<br><span class="he">{}</span>'.format(e(kopf)) if kopf else '', e(r.get('bemerkung', '')))
        if r.get('ot_von') or r.get('ot_bis'):
            info += '<br>Ot {}–{}'.format(r.get('ot_von') or '?', r.get('ot_bis') or '?')
        img = ''
        if bilder_dir and (Path(bilder_dir) / '{:04d}_kopf.jpg'.format(seq)).exists():
            rel = Path(bilder_dir).name + '/{:04d}_kopf.jpg'.format(seq)
            img = '<img src="{}" alt="Kopfzeile Seite {}">'.format(e(rel), seq)
        fl = scan.seiten[seq]['fl_id'] if scan and seq in scan.seiten else r.get('fl_id', '')
        out.append('<tr class="{}"><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>'.format(
            'todo' if not r else '', seq, e(fl), info, img))
    out.append('</table></body></html>')
    Path(path).write_text('\n'.join(out), encoding='utf-8')


# --- IIIF-Download ----------------------------------------------------------
def iiif_seiten(manifest):
    """[(seq, fl_id, bild_url)] aus einem IIIF-Manifest v2 oder v3."""
    out = []
    if 'sequences' in manifest:
        canvases = manifest['sequences'][0].get('canvases', [])
        for i, c in enumerate(canvases, start=1):
            res = c['images'][0]['resource']
            svc = res.get('service') or {}
            if isinstance(svc, list):
                svc = svc[0]
            sid = (svc.get('@id') or svc.get('id') or '').rstrip('/')
            url = sid + '/full/full/0/default.jpg' if sid else res.get('@id')
            out.append((i, (sid or res.get('@id', '')).rstrip('/').split('/')[-1], url))
    else:
        for i, c in enumerate(manifest.get('items', []), start=1):
            body = c['items'][0]['items'][0]['body']
            svc = body.get('service') or []
            svc = svc[0] if isinstance(svc, list) and svc else (svc or {})
            sid = (svc.get('id') or svc.get('@id') or '').rstrip('/')
            url = sid + '/full/max/0/default.jpg' if sid else body.get('id')
            out.append((i, (sid or body.get('id', '')).rstrip('/').split('/')[-1], url))
    return out


def iiif_laden(manifest_url, ziel, seiten=None):
    manifest = json.loads(C.http_get(manifest_url).decode('utf-8'))
    liste = iiif_seiten(manifest)
    wahl = set(C.parse_range(seiten, len(liste))) if seiten else None
    Path(ziel).mkdir(parents=True, exist_ok=True)
    n = 0
    for seq, fl, url in liste:
        if wahl and seq not in wahl:
            continue
        f = Path(ziel) / '{:04d}_{}.jpg'.format(seq, re.sub(r'[^A-Za-z0-9_-]', '_', fl))
        if f.exists() and f.stat().st_size > 0:
            continue
        f.write_bytes(C.http_get(url, timeout=180))
        n += 1
    return len(liste), n


# --- Hauptablauf ---------------------------------------------------------------
def run(json_path=None, scan_pfade=None, konkordanz=None, out='out', scan_gesamt=None,
        ocr=False, kopfbilder=True, vergleich_json=None, quiet=False, belege=None):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    werk = C.load_werk(json_path)
    rows, summary = abschnittsliste(werk)
    C.write_tsv(out / (C.WERK_TAG + '_Abschnittsliste.tsv'),
                ['abschnitt_nr', 'abschnitt', 'he_title', 'ot', 'sefaria_ref', 'absaetze',
                 'he_zeichen', 'stichwort', 'incipit', 'hinweis'], rows)
    schema = schema_pruefung(werk)
    scan = ScanQuelle(scan_pfade) if scan_pfade else None
    konk_path = Path(konkordanz) if konkordanz else C.HERE / 'scan_konkordanz.tsv'
    konk = lade_konkordanz(konk_path)
    if scan:
        C.write_tsv(out / 'scan' / (C.WERK_TAG + '_Scaninventar.tsv'),
                    ['seq', 'fl_id', 'datei', 'bytes', 'sha256', 'breite', 'hoehe'], scaninventar(scan))
    bilder_dir = None
    if scan and kopfbilder:
        bilder_dir = out / 'scan' / 'kopfzeilen'
        bilder_dir.mkdir(parents=True, exist_ok=True)
        for seq in sorted(scan.seiten):
            f = bilder_dir / '{:04d}_kopf.jpg'.format(seq)
            if not f.exists():
                kopfzeile(scan, seq).save(f, quality=60)
    if scan and ocr:
        if not tesseract_vorhanden():
            print('HINWEIS: tesseract nicht gefunden – OCR-Vorschlag uebersprungen.')
        else:
            import tempfile
            vorschlag = []
            with tempfile.TemporaryDirectory() as tmp:
                for seq in sorted(scan.seiten):
                    t = ocr_kopfzeile(scan, seq, tmp)
                    art, ab = deute_kopfzeile(t, werk)
                    vorschlag.append([seq, scan.seiten[seq]['fl_id'], art, ab, '', '', '', t, '', 'OCR-Vorschlag'])
            C.write_tsv(out / 'scan' / 'scan_konkordanz_vorschlag.tsv', KONK_HEADER, vorschlag)
    belege_path = Path(belege) if belege else C.HERE / 'scan_belege.json'
    abgl = scanabgleich(werk, summary, scan, konk, scan_gesamt, lade_belege(belege_path))
    vergleich = None
    if vergleich_json:
        vergleich = vergleiche_werke(werk, C.load_werk(vergleich_json))
    txt = bericht_text(werk, summary, schema, abgl, vergleich)
    (out / (C.WERK_TAG + '_Scanabgleich.txt')).write_text(txt, encoding='utf-8')
    C.write_json(out / (C.WERK_TAG + '_Scanabgleich.json'),
                 {'meta': werk['meta'], 'konkordanz': str(konk_path), 'abschnitte': summary,
                  'schema': schema, 'abgleich': abgl, 'vergleich_sefaria': vergleich})
    pruefbogen_html(out / 'scan' / (C.WERK_TAG + '_Scan_Pruefbogen.html'), werk, summary, abgl,
                    konk, scan, bilder_dir)
    if not quiet:
        print(txt)
    return {'werk': werk, 'summary': summary, 'abgleich': abgl, 'schema': schema,
            'vergleich': vergleich}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split('\n')[1])
    ap.add_argument('--json', default=str(C.SOURCE_JSON), help='Sefaria-JSON (Vorgabe: source/)')
    ap.add_argument('--scan', nargs='*', default=[], help='Scan-ZIP(s) oder -Ordner')
    ap.add_argument('--konkordanz', default=str(C.HERE / 'scan_konkordanz.tsv'))
    ap.add_argument('--belege', default=str(C.HERE / 'scan_belege.json'))
    ap.add_argument('--scan-gesamt', type=int, help='Gesamtseitenzahl des NLI-Digitalisats')
    ap.add_argument('--ocr', action='store_true', help='Kolumnentitel per tesseract vorschlagen')
    ap.add_argument('--ohne-kopfbilder', action='store_true')
    ap.add_argument('--out', default=str(C.HERE / 'out'))
    ap.add_argument('--laden-sefaria', action='store_true',
                    help='aktuelle Sefaria-Fassung laden (nach out/sefaria_aktuell.json)')
    ap.add_argument('--vergleiche-sefaria', action='store_true',
                    help='geladene aktuelle Fassung mit --json vergleichen')
    ap.add_argument('--sefaria-url', default=C.SEFARIA_URL)
    ap.add_argument('--iiif-manifest', help='IIIF-Manifest des NLI-Digitalisats')
    ap.add_argument('--seiten', help='Seitenauswahl fuer den IIIF-Download, z. B. 26-200')
    ap.add_argument('--laden-nach', help='Zielordner fuer IIIF-Seitenbilder')
    a = ap.parse_args(argv)

    if a.iiif_manifest:
        if not a.laden_nach:
            ap.error('--laden-nach fehlt')
        total, neu = iiif_laden(a.iiif_manifest, a.laden_nach, a.seiten)
        print('IIIF: {} Seiten im Manifest, {} neu geladen nach {}'.format(total, neu, a.laden_nach))
        return 0
    aktuell = None
    if a.laden_sefaria:
        aktuell = Path(a.out) / 'sefaria_aktuell.json'
        C.download_sefaria(a.sefaria_url, aktuell)
        print('Sefaria geladen: {} · sha256 {}'.format(aktuell, C.sha256_file(aktuell)))
    if a.vergleiche_sefaria and not aktuell:
        aktuell = Path(a.out) / 'sefaria_aktuell.json'
        if not aktuell.exists():
            ap.error('keine aktuelle Fassung vorhanden – zuerst --laden-sefaria')
    run(a.json, a.scan, a.konkordanz, a.out, a.scan_gesamt, a.ocr, not a.ohne_kopfbilder,
        aktuell if a.vergleiche_sefaria else None, belege=a.belege)
    return 0


if __name__ == '__main__':
    sys.exit(main())
