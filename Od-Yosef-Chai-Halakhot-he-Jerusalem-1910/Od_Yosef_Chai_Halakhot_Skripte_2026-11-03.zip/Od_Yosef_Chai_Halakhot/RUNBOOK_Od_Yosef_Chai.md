# Od Yosef Chai · Halakhot — Runbook

Zweisprachige Ausgabe (Hebräisch → Englisch) der Halachot aus *Od Yosef Chai*
(R. Yosef Chaim, Jerusalem 1910), gesetzt im **Format und in der Bandgröße
von Ben Ish Chai Halakha**. Grundlage sind die bestehenden Werkzeuge des
Projekts:

| Baustein | verwendet für |
|---|---|
| `ben-yehoyada-pipeline-v3_2_1_2026-10-05.zip` | `by_parse.find_abbrs`, `by_glossary.Glossary` (unverändert, direkt aus dem ZIP importiert) |
| `glossary_he.json` (Repository) | Glossarbasis; wird **nicht** automatisch verändert |
| `Ben_Ish_Chai_Bilingual_Book_Manager_v1_0_17-Milestone.jsx` | Bandgröße, Kalibrierung, Planer, Dateiform der Banddatei |
| `Ben_Ish_Chai_Running_Header_Manager_v1_0_3.jsx` | Kolumnentitel (erkennt `פרשת …` in `<he_title>`) |
| Arbeitsanleitung 1.5 | Regeln 45 (Quelle unverändert), 48 (600 Seiten), Glossarpflege Schritt 5 |

## Gesamtlauf

```bash
python3 produzieren.py --scan <Scan-ZIP oder -Ordner> [weitere …] [--scan-gesamt N] [--ocr]
```

Ergebnisse unter `out/`, Prüfbericht `out/Od_Yosef_Chai_Halakhot_Pruefbericht.md`,
Quellenmanifest mit Prüfsummen `out/Quellenmanifest.json`. Selbsttest:

```bash
python3 -m unittest test_oyc -v
```

(25 Tests; die JSX-Tests führen `parseBilingualFile`, `composeDisplayTexts` und
`planVolumes` aus dem Ben-Ish-Chai-Buchmanager in Node aus.)

## Schritt 1 — Abschnittsliste mit dem Scan abgleichen (`oyc_abschnitte.py`)

**Quellen.** Sefaria-JSON *Od Yosef Chai; Halakhot – he – Jerusalem, 1910*
(`source/`, sha256 `c5c83996…`), `versionSource` = NLI
`NNL_ALEPH990019337340205171`. Scan: NLI-Seitenbilder `NNNN_FLxxxxxxxxx.jpg`.

**Abschnittsliste.** `out/Od_Yosef_Chai_Halakhot_Abschnittsliste.tsv`: eine
Zeile je Halacha (Ot) mit Sefaria-Ref, Absätzen, Zeichen, fettem Stichwort und
Incipit. Struktur des JSON: 29 Abschnitte (27 Paraschot, *Purim*,
*Kuntres Chut HaMeshulash*), 507 Halachot, davon **Vaera 3 leer**.
Der Kuntres hat keine Ot-Gliederung (107 Absätze, je Absatz ein Segment).

**Scan-Konkordanz** (`scan_konkordanz.tsv`, Lektoratsdatei): eine Zeile je
Scanseite – Art, Abschnitt (JSON-Schlüssel), erste/letzte Ot, Kolumnentitel.
Seiten 1–25 sind erfasst (Einband, Titelblatt, מודעה רבא, הקדמה, Petichot
1–4 der Derashot) – **noch keine Halakhot-Seite**. Für den vollständigen
Abgleich:

1. weitere Seiten laden (NLI-Viewer, oder IIIF):
   ```bash
   python3 oyc_abschnitte.py --iiif-manifest <Manifest-URL des NLI-Datensatzes> --seiten 26-500 --laden-nach scan_seiten/
   ```
   Die Manifest-URL im NLI-Viewer nachsehen (IIIF-Symbol); das Skript liest
   IIIF v2 und v3 und benennt die Dateien wie der bisherige Download.
2. Lauf mit allen Seiten und `--ocr` (Tesseract mit `heb`): erzeugt
   `out/scan/scan_konkordanz_vorschlag.tsv` aus den Kolumnentiteln
   (Kolumnentitel sind Quadratschrift, der Fließtext Raschi-Schrift).
3. Vorschlag prüfen und in `scan_konkordanz.tsv` übernehmen; je
   Halakhot-Seite `abschnitt`, `ot_von`, `ot_bis` eintragen.
4. Lauf mit `--scan-gesamt <Seitenzahl>`: erst dann meldet der Abgleich
   „FEHLT IM SCAN“.

Prüfbogen zum Durchblättern: `out/scan/Od_Yosef_Chai_Halakhot_Scan_Pruefbogen.html`
(Abschnitte mit Status, Kopfzeilen-Ausschnitt jeder Scanseite).

**Status je Abschnitt:** `IM SCAN` · `ANZAHL ABWEICHEND` (höchste Ot im Scan ≠
JSON) · `REIHENFOLGE ABWEICHEND` · `NOCH NICHT IM SCANBEREICH` · `FEHLT IM SCAN`
(nur bei vollständigem Scan) · `AUSSERHALB DES ANGEGEBENEN UMFANGS`.

**Belege des Buches** (`scan_belege.json`): Die Vorrede des Autors (Scan S. 8)
sagt, das Buch enthalte von den Halachot „nur die des ersten Jahres zu
Bereschit und Schemot“. Das JSON enthält zusätzlich **Vayikra, Tzav, Bamidbar,
Shoftim** (90 Halachot, ≈ 53.000 Zeichen). Diese Abschnitte sind deshalb
`AUSSERHALB DES ANGEGEBENEN UMFANGS`, bis der Scan zeigt, ob und wo sie im
Druck von 1910 stehen (Anhang, Nachtrag, andere Ausgabe). Erst dann über ihre
Aufnahme in den Band entscheiden.

**Aktuelle Sefaria-Fassung vergleichen** (Netz nötig):
```bash
python3 oyc_abschnitte.py --laden-sefaria --vergleiche-sefaria
```

**Textkorrekturen nach Scan** (`textkorrekturen.json`, optional):
`{"korrekturen": [{"ref": "Vaera 2:4", "alt": "…", "neu": "…", "scan_seq": 312, "grund": "…"}]}`.
Pflicht sind Scanseite und Grund; `alt` muss im Absatz genau einmal vorkommen.
Die JSON-Quelle bleibt unverändert (Regel 45); alle Schritte lesen den
korrigierten Stand, das Quellenmanifest führt die Korrekturen.

## Schritt 2 — Vokalisierung und Kollation (`oyc_nakdan.py`, `oyc_kollation.py`)

Zwei getrennte Zeugen, nie vermischt:

| Zeuge | Ordner | Inhalt |
|---|---|---|
| Nakdan | `vokalisierung/nakdan/` | automatische Vokalisierung, unbearbeitet |
| Meine Fassung | `vokalisierung/meine/` | eigene, von Hand vokalisierte/korrigierte Fassung |

Format beider: Markerdateien `@@Ref@@` + Absatztext (Nakdan lässt lateinische
Zeichen unverändert).

```bash
python3 oyc_nakdan.py export                 # vokalisierung/export/*.txt (≤ 15.000 Zeichen je Datei)
#   → in https://nakdanpro.dicta.org.il vokalisieren, Ergebnis als TXT sichern
python3 oyc_nakdan.py import --zeuge nakdan ~/Downloads/OYC_*.txt
#   oder automatisch (Netz zu Dicta nötig):  python3 oyc_nakdan.py api --genre rabbinic
python3 oyc_nakdan.py vorlage                # legt meine/ einmalig aus nakdan/ an, überschreibt nie
#   → vokalisierung/meine/*.txt bearbeiten
python3 oyc_kollation.py                     # out/kollation/…
```

Die Kollation richtet jeden Zeugen wortweise am Konsonantenskelett der Basis
aus und meldet: `VOK` (Meine ≠ Nakdan bei gleichen Konsonanten – die
eigentliche Kollation), `UNVOK_M` (noch ohne Vokale), `TEXT_/PLUS_/MINUS_`
(Konsonanten weichen ab → gegen Scan prüfen), `FEHLT_`. Spalte `entscheidung`
in der TSV ist für das Lektorat.

In die Banddatei übernimmt `--he-quelle meine` **nur Vokalzeichen** auf die
Konsonanten der Basis; `<b>`, Satzzeichen und Gershajim der Basis bleiben.
Konsonantische Verbesserungen kommen ausschließlich über `textkorrekturen.json`.

## Schritt 3 — Glossar aus Ben Jehojada (`oyc_glossar.py`)

Kürzelerkennung und -auflösung exakt wie in der BY-Pipeline v3.2.1, mit der
neuesten `glossary_he.json` des Repositorys. Ergebnis `out/glossar/`:

- `…_GLOSSAR.tsv` — Übersetzerhilfe; Spalte `status`:
  `UEBERNOMMEN` (kuratierter BY-Eintrag) · `ABGELEITET` (Präfix/Buchstabe) ·
  `ZAHLWERT` · `STELLENZAHL` (Zahl hinter סי'/דף/ס"ק …, OYC-Erweiterung, keine Fußnote) ·
  **`NEU`** (neuer Terminus); Spalte `neu_stamm` fasst Präfixformen zusammen
  (בש"ץ → ש"ץ); Spalte `hinweis` aus `kontextregeln.json`
  (z. B. רז"ל vor שער הכוונות = רבינו ז"ל, der Ari).
- `…_Glossar_NEU.json` — alle neuen Termini mit Stellen und Kontexten, `he`/`en` leer.
- `…_Geresch_Kuerzel.tsv` — Kürzel mit einfachem Geresch (סי', הנז'), die der
  BY-Mechanismus nicht erfasst.

Neue Termini werden nach Prüfung **mit Beleg** in die `glossary_he.json` des
Repositorys übernommen (Arbeitsanleitung 1.5, Schritt 5; `_meta.stand`:
„Od Yosef Chai Halakhot“). Halachische Werktitel (ש"ץ = שלמי צבור, כנה"ג,
ברכ"י, מג"א …) und Zahlen sind hier häufiger als im Ben Jehojada.

## Schritt 4 — Bandplan mit der Bandgröße von Ben Ish Chai Halakha (`oyc_bandplan.py`)

Kalibrierung und Planer 1:1 aus dem Ben-Ish-Chai-Buchmanager v1.0.17
(Test vergleicht mit dem JSX): 148 × 210 mm, HE 1050 Z./S., EN 2000 Z./S.,
Expansion 1,95, Ziel 540 Seiten inkl. 12 Reserve, Sperre 600.

```bash
python3 oyc_bandplan.py                       # Planungsstand (unvokalisiert)
python3 oyc_bandplan.py --he-quelle meine     # Produktionsmaster nach abgeschlossener Kollation
```

Banddatei `out/band/Od_Yosef_Chai_Halakhot_Band_01_BILINGUAL.txt` in der
Dateiform des BIC-Buchmanagers (`<section><he_title>פרשת …</he_title><en_title></en_title>`,
`<segment id="OYH-0000001" n="1"><he>…</he><en></en>`); Segment = eine Halacha,
Absätze durch Zeilenwechsel getrennt wie die Chapter-Blöcke des Ben Ish Chai,
`n` = Sefaria-Ot. Dazu `…_Bandplan.txt` und `…_Segmentkontrolle.tsv`.

Im Buchmanager v1.0.17 die Banddatei direkt in Reiter 2/3 wählen, **nicht**
in Reiter 1 neu planen: das JSX zählt Vokalzeichen als Zeichen. Im
Kolumnentitel-Manager die Vorlage auf `עוד יוסף חי · פרשת {PARASHAH_HE}` ändern.

Ein bereits übersetzter Master wird nie überschrieben (Abbruch).

## Offene Punkte für das Lektorat

1. Restliche Scanseiten laden, Konkordanz vervollständigen, Ot-Zahlen je Parascha bestätigen.
2. Herkunft von Vayikra, Tzav, Bamidbar, Shoftim klären (Vorrede: nur Bereschit/Schemot).
3. Vaera 3 im Scan suchen (in Sefaria leer).
4. Bereshit 1: einleitender Absatz „אלו הם ההלכות …“ steht in Sefaria in Ot 1 – im Scan prüfen, ob er Ot 1 ist.
5. Nakdan-Lauf und Meine Fassung; Kollation abschließen; dann Master mit `--he-quelle meine`.
6. Neue Glossar-Termini kuratieren.
7. Vayishlach 1 (32.475 Zeichen) liegt über dem Batch-Kontingent von 30.000 – wird als Einzelbatch exportiert.
